GB Puzzle Mode 2.6
Game author: DLB

Apply gbpuzzlemode-v2-6.bps to an original 32,768-byte Game Boy Tetris ROM with CRC32 46DF91AD.
The patch produces the supplied version 2.6 ROM. No base ROM is included.

Load the patched ROM with the matching .sym and .trep.json files in TREP. The .map file is optional.

8,461 distinct puzzles.
