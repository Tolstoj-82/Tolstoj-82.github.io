const fs=require('fs');const p=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio\app.js`;let s=fs.readFileSync(p,'utf8');s=s.slice(0,s.indexOf('function renderStackBrushes(){'))+String.raw`
function stackKind(c){return c==='$'?'mandatory':c===','?'counter':/[a-z]/.test(c)?'motif':c==='.'?'empty':'stack';}
function renderStackBrushes(){
 const tools=[['S','Stack'],['s','Motif'],['$','Mandatory'],[',','Counter-motif'],['.','Eraser']];
 for(const[id,items]of [['stackBrushes',tools],['stackMinoBrushes',['I','O','T','Z','J','L','X'].map(c=>[c,c])]]){
  const palette=$(id);palette.replaceChildren();for(const[value,label]of items){const b=document.createElement('button'),swatch=document.createElement('span');b.type='button';b.dataset.brush=value;b.setAttribute('aria-pressed',String($('stackBrush').value===value));swatch.className='stack-brush-swatch';swatch.dataset.kind=stackKind(value);swatch.textContent=value==='.'?'×':value;const text=document.createElement('span');text.textContent=label;b.append(swatch,text);b.onclick=()=>{$('stackBrush').value=value;renderStackBrushes();};palette.append(b);}
 }
}
function renderStackGrid(){
 const grid=$('stackPaintGrid');grid.replaceChildren();
 stackEditRows.forEach((row,y)=>row.forEach((cell,x)=>{
  const b=document.createElement('button');b.type='button';
  const update=()=>{const c=stackEditRows[y][x];b.textContent=c==='.'?'':c;b.dataset.kind=stackKind(c);b.setAttribute('aria-label','Row '+(y+1)+', column '+(x+1)+': '+c);};update();
  const paint=erase=>{stackEditRows[y][x]=erase?'.':($('stackBrush').value||'S');$('stackRows').value=stackEditRows.map(r=>r.join('')).join('\n');update();validateStackEdit();};
  b.onpointerdown=e=>{e.preventDefault();paint(e.button===2);};b.onpointerenter=e=>{if(e.buttons&3)paint(!!(e.buttons&2));};b.onclick=()=>paint(false);b.oncontextmenu=e=>{e.preventDefault();paint(true);};grid.append(b);
 }));
}
function openStackEditor(){
 stop();stackEditKey=situationKey(studies[selected]);const raw=globalThis.TetrisSituationFiles?.[stackEditKey];
 if(!raw){notice('No source situation file available.');return;}
 stackEditSource=C.clone(raw);const height=raw.height||18;stackEditRows=Array.from({length:height-(raw.stack||[]).length},()=>Array(10).fill('.')).concat((raw.stack||[]).map(r=>[...r]));
 $('stackEditorTitle').textContent='Edit stack · '+raw.title;$('stackEditor').hidden=false;$('stackBrush').value='S';renderStackBrushes();$('stackRows').value=stackEditRows.map(r=>r.join('')).join('\n');renderStackGrid();validateStackEdit();$('stackEditor').scrollIntoView?.({behavior:'smooth',block:'start'});
}
$('openStackEditor').onclick=openStackEditor;$('resetStack').onclick=openStackEditor;$('closeStackEditor').onclick=()=>{$('stackEditor').hidden=true;};
$('stackRows').oninput=()=>{
 const rows=$('stackRows').value.replace(/\r/g,'').split('\n');
 if(rows.length>(stackEditSource.height||18)||rows.some(r=>r.length!==10)){$('stackEditorError').textContent='Use up to '+(stackEditSource.height||18)+' rows, each exactly 10 cells.';$('downloadStack').disabled=true;return;}
 stackEditRows=Array.from({length:(stackEditSource.height||18)-rows.length},()=>Array(10).fill('.')).concat(rows.map(r=>[...r]));renderStackGrid();validateStackEdit();
};
$('downloadStack').onclick=()=>{
 if(!validateStackEdit())return;
 const raw=stackCandidate(),source='(function(root){\nconst situation = '+JSON.stringify(raw,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(stackEditKey)+']=situation;\n})(globalThis);\n';
 const url=URL.createObjectURL(new Blob([source],{type:'text/javascript'})),a=document.createElement('a');a.href=url;a.download=stackEditKey+'.js';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
};
`;s=s.replaceAll(String.raw`\\n`,String.raw`\n`).replaceAll(String.raw`\\r`,String.raw`\r`);fs.writeFileSync(p,s);
