const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
const s=structuredClone(require(path.join(root,'situations/adjustment-lj-koryan.js')));
s.title='S-Z Koryan Thing';s.description='Mirrored from the NES reference: Z first, S next on Game Boy. Adjust for the pair rather than the default flat placement.';
s.stack=['......SSSS','.S....SSSS','.Ss..sSSSS'];const a={type:'Z',x:4,y:15,rotation:1},b={type:'S',x:2,y:15,rotation:1},d={type:'Z',x:2,y:15,rotation:0};s.adjustment={default:d,adjusted:a,next:b};
const base=C.empty(15).concat(s.stack.map(r=>[...r.replaceAll('s','L').replaceAll('S','L')])),locked=C.compose({board:base,active:a},18),both=C.compose({board:locked,active:b},18);
const diff=(before,after)=>Object.fromEntries(after.map((r,y)=>[y,r.join('')]).filter(([y,r])=>r!==before[y].join('')));
const captions=[
 'The motif: the two stack corners that the Z and S will enclose.',
 'Default: Z would normally lie flat here. Compare this with the next-piece adjustment.',
 'Look ahead: S is next. The flat default Z would block its landing position.',
 'Adjusted: stand Z upright farther right, leaving room for S alongside it.',
 'Next: the upright S will fit here beside the adjusted Z. Compare the two ghosts.',
 'Turn Z upright and place it in the adjusted position.',
 'Bring in the next S. The adjacent landing space is still open.',
 'Turn S upright and lower it beside Z.',
 'The adjusted Z and next S form a unit around the stack corners.',
 'Notice the motif again: each corner is wrapped by one of the two pieces.'
];
s.frames.forEach((f,i)=>{f.next='S';f.caption=captions[i];if(f.active)f.active={type:i===6||i===7?'S':'Z',x:3,y:0,rotation:0};if(i===5)f.active={...a};if(i===7)f.active={...b};if(f.animate)f.buttons=['B'];if(f.ghost)f.ghost=i===1||i===2?{...d,label:'Default'}:i===3?{...a,label:'Adjusted'}:{...b,label:'Next'};if(f.referenceGhost)f.referenceGhost={...a,label:'Adjusted'};if(f.rows)f.rows=i===6?diff(base,locked):diff(locked,both);if(f.placementHighlights)f.placementHighlights=[a,b];});
const key='adjustment-sz-koryan';fs.writeFileSync(path.join(root,'situations',key+'.js'),'// NES S/Z Koryan reference mirrored horizontally to Game Boy Z/S.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
edit('situations.js',s=>s.replace('"adjustment-lj-koryan"\n','"adjustment-lj-koryan",\n  "adjustment-sz-koryan"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/adjustment-sz-koryan.js"></script><script src="situations.js">'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,30','C.parseCollection(demo).length,31'));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'30'","libraryCount.textContent,'31'").replace('h.cards().length,29','h.cards().length,30'));
fs.appendFileSync(path.join(root,'adjustments.test.cjs'),`
test('S-Z Koryan mirrors the NES stack and uses Z then S around two motif corners',()=>{
 const raw=require('./situations/adjustment-sz-koryan.js'),s=C.normalize(raw),a=s.adjustment;
 const original=['SSSS......','SSSS....S.','SSSSS..SS.'];assert.deepEqual(C.compose(s.frames[0],18).slice(15).map(r=>r.map(c=>c==='.'?'.':'S').join('')),original.map(r=>[...r].reverse().join('')));
 assert.equal(a.adjusted.type,'Z');assert.equal(a.next.type,'S');assert.deepEqual(s.frames[0].motif.cells,[[2,17],[5,17]]);
 const board=C.compose(s.frames[0],18);assert(fits(board,a.default));assert(!fits(C.compose({board,active:a.default},18),a.next));assert(fits(board,a.adjusted));assert(fits(C.compose({board,active:a.adjusted},18),a.next));
 for(const f of s.frames.filter(f=>f.animate)){const stack=C.compose({...f,active:undefined},18);for(let t=0;t<=f.ticks;t++)assert(fits(stack,C.frameAt(f,t).active));}
 const clean=global.TetrisCourse.clean(s);for(const f of clean.frames)if(f.active)assert(fits(C.compose({...f,active:undefined},18),f.active));
 assert.deepEqual(C.normalize(C.compact(s)),s);
 const attempt=new Attempt(s);attempt.active=C.clone(a.adjusted);attempt.lock();assert(!attempt.done);attempt.advance(2*1000/C.HZ);assert.equal(attempt.active.type,'S');attempt.active=C.clone(a.next);attempt.lock();assert(attempt.done&&attempt.correct);
});
`);
