const fs=require('fs'),file='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio/studio.css';
let css=fs.readFileSync(file,'utf8');
css=css.replace('/* Neutral colors for ordinary action buttons; preserve existing geometry and component styles. */','/* Blue colors for ordinary action buttons; preserve menu and tile styles. */');
css=css.replace('background:#e2e8f0!important;color:#263244!important;border-color:#64748b!important','background:#dbeafe!important;color:#1e3a8a!important;border-color:#3b82f6!important');
css=css.replace('background:#cbd5e1!important;border-color:#475569!important','background:#bfdbfe!important;border-color:#2563eb!important');
css+=`\n/* Keep standalone actions and playback controls sized to their labels. */
@media(min-width:1000px){
 .preview>.try-situation,.preview>.stack-editor-toggle{align-self:flex-end;flex:0 0 auto;width:fit-content;max-width:100%}
 .player-column .transport-buttons{display:flex;justify-content:center;gap:6px;width:100%}
 .player-column .transport-buttons button{flex:0 0 auto;width:auto;padding:6px 10px}
 .player-column .transport-buttons #previous,.player-column .transport-buttons #next{min-width:32px}
}
`;
fs.writeFileSync(file,css);
console.log('Normal actions now use blue fill/border/hover; standalone and playback buttons no longer stretch.');
