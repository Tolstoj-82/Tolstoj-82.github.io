const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const variant of ['well','center']){
 const x=variant==='well'?0:3,s=structuredClone(require(path.join(root,'situations/t-spuck-right.js')));s.title='S-Spuck ('+variant+')';s.piece='S';
 const rows=variant==='well'?['..SSSSSSSS','..SSSSSSSS','..sssSSSSS','....sSSSSS','...ssSSSSS']:['SSS..SSSSS','SSS..SSSSS','SSS..sssSS','SSS....sSS','SSS...ssSS'];
 const b=rows.map(r=>[...r]);for(const a of [{x,y:15,rotation:1},{x,y:15,rotation:0},{x:x+1,y:15,rotation:0}])for(const[dx,dy]of C.cells('S',a.rotation)){if(!['.',','].includes(b[a.y+dy-13][a.x+dx]))throw Error('overlap');b[a.y+dy-13][a.x+dx]=',';}
 s.stack=b.map(r=>r.join(''));for(const f of s.frames.slice(0,3)){f.caption=f.caption.replaceAll('T piece','S piece');}
 s.frames[1].caption='1a · The wide C-shaped stack motif leaves room for the sideways tuck.';
 s.frames[2].caption='1b · The empty pocket is the counter-motif: room for the rotation and one step right.';
 for(const f of s.frames.slice(3,6))f.active={x,y:15,rotation:1};
 s.frames[3].caption='2 · Turn the S upright and descend beside the wide motif.';s.frames[3].buttons=['B'];
 s.frames[4].trigger={hole:[x+2,16],button:'B'};
 s.frames[5].caption='4 · Press B or A to turn the S horizontally.';s.frames[5].buttons=['B'];s.frames[5].buttonOptions=['B','A'];s.frames[5].ticks=120;s.frames[5].blink=true;
 for(const f of s.frames.slice(6,8))f.active={x,y:15,rotation:0};
 s.frames[6].caption='5 · The S is horizontal. Move it one square right to tuck under the motif.';
 s.frames[7].caption='6 · Press right once to tuck the S into the pocket.';s.frames[7].buttons=[];
 s.frames[8].active={x:x+1,y:15,rotation:0};s.frames[8].buttons=['Right'];s.frames[8].ticks=48;delete s.frames[8].fallFirst;s.frames[8].caption='7 · One step right seats the S beneath the motif. No line clears here.';
 const key='s-spuck-'+variant;fs.writeFileSync(path.join(root,'situations',key+'.js'),'(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"t-spuck-suboptimal-left"\n','"t-spuck-suboptimal-left",\n  "s-spuck-well",\n  "s-spuck-center"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/s-spuck-well.js"></script><script src="situations/s-spuck-center.js"></script><script src="situations.js">'));
edit('app.js',s=>s.replace("label=isSpuck?'T-Spucks':","label=isSpuck?(s.piece==='S'?'S-Spucks':'T-Spucks'):").replace("stage=tuck?'fall':'done';","stage=tuck?(tuck.active.y>a.y?'fall':'tuck'):'done';"));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'23'","libraryCount.textContent,'25'").replace('h.cards().length,22','h.cards().length,24').replace('categories[1].children.length,2','categories[1].children.length,3'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,23','C.parseCollection(demo).length,25')+`
test('S-Spucks rotate with either button then tuck right once without collisions',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('S-Spuck'));assert.equal(variants.length,2);
 for(const s of variants){assert.deepEqual(s.frames[5].buttonOptions,['B','A']);assert.deepEqual(s.frames[8].buttons,['Right']);assert.equal(s.frames[8].active.x,s.frames[6].active.x+1);assert.equal(s.frames[8].active.y,s.frames[6].active.y);assert.equal(s.frames[1].motif.cells.length,6);
  for(const f of s.frames.filter(f=>f.animate)){const stack=C.compose({...f,active:undefined},18);for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells('S',a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}}
  assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
