const fs=require('node:fs'),path=require('node:path'),base=path.resolve('../tetris-studio');
fs.appendFileSync(path.join(base,'tests/autoplay.test.cjs'),`
// The provisional move must skim too, even when the worker has not replied.
for(const type of ['O','L','J']){
 const g=game(type,20);g.board=C.empty(13).concat(Array.from({length:5},()=>[... '..LLLLLLLL']));g.nextPiece='O';
 const h=harness(g);assert(h.auto.target);assert(H.apply(g.board,h.auto.target).cleared>0,type+' provisional route must skim the double well');
 let n=0;while(!g.pendingPiece&&!g.done&&n++<200)h.auto.advance(frameMs);
 assert(g.pendingPiece);assert(g.lines>0);assert.equal(g.done,false);h.auto.dispose();
}
console.log('PASS provisional autoplay performs early K skims without waiting for the advisor');
`);
