const fs=require('node:fs'),path=require('node:path'),base=path.resolve('../tetris-studio');
const file=path.join(base,'index.html');let s=fs.readFileSync(file,'utf8');
const start=s.indexOf('<div class="attempt-actions">'),end=s.indexOf('<div id="freePracticeOptions"',start);if(start<0||end<0)throw Error('Live controls not found');
const controls=s.slice(start,end),ids=['restartAttempt','pauseAttempt','leaveAttempt','freeHintLive','freeAutoplayLive','freePracticeLive','openMistakes'];
const buttons=Object.fromEntries(ids.map(id=>{const match=controls.match(new RegExp('<button[^>]*id="'+id+'"[^>]*>[\\s\\S]*?<\\/button>'));if(!match)throw Error('Missing '+id);return[id,match[0]];}));
s=s.slice(0,start)+'<div class="attempt-actions">'+buttons.restartAttempt+buttons.pauseAttempt+buttons.leaveAttempt+'</div>\n<div class="free-live-modes" role="group" aria-label="Free play options">'+buttons.freeHintLive+buttons.freeAutoplayLive+buttons.freePracticeLive+'<label id="freeCollectionControls" class="free-collection-controls" hidden><span>Collect mistakes</span><input id="freeCollectLive" class="free-checkbox-switch" role="switch" type="checkbox"></label></div>\n<div class="free-library-actions">'+buttons.openMistakes+'</div>'+s.slice(end);
s=s.replace('studio.css?hint-review-1','studio.css?live-controls-1');fs.writeFileSync(file,s);
const css=path.join(base,'assets/css/studio.css');fs.appendFileSync(css,`
/* Keep game actions separate from the aligned, single-column mode switches. */
.free-live-modes,.free-library-actions{display:none}
.free-play-mode .attempt-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;width:100%}
.free-play-mode .attempt-actions button{width:100%;min-width:0;min-height:34px;padding:6px 8px;font-size:12px}
.free-play-mode .free-live-modes{display:grid;grid-template-columns:minmax(0,1fr);gap:0;margin-top:10px;padding:4px 0;border-top:1px solid #d9e0e9;border-bottom:1px solid #d9e0e9}
.free-live-modes button.free-live-switch{width:100%;box-sizing:border-box;min-height:38px!important;margin:0;padding:7px 66px 7px 12px;font:500 12px/1.2 "Outfit",sans-serif;text-align:left;border-radius:5px}
.free-live-modes button.free-live-switch:hover{background:#e9eef5!important}
.free-live-modes .free-collection-controls{display:flex;justify-content:space-between;align-items:center;gap:12px;box-sizing:border-box;min-height:38px;margin:0;padding:7px 12px;border-radius:5px;font:500 12px/1.2 "Outfit",sans-serif;cursor:pointer;text-align:left}
.free-live-modes .free-collection-controls:hover{background:#e9eef5}
.free-live-modes .free-collection-controls input{margin:0}
.free-live-modes [hidden]{display:none!important}
.free-play-mode .free-library-actions{display:block;margin-top:8px}
.free-library-actions button{width:100%;min-height:32px;padding:5px 8px;font-size:12px}
`);console.log('Aligned live mode switches and separated game and collection actions.');
