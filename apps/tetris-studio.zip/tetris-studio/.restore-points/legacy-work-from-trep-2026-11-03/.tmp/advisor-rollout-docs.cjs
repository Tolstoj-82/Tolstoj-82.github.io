const fs=require('node:fs'),root='../tetris-studio/';const doc=root+'docs/FREE-PLAY.md';let s=fs.readFileSync(doc,'utf8');const at=s.indexOf('## Optional live placement hint');if(at<0)throw Error('Advisor docs not found');
s=s.slice(0,at)+`## Optional live placement hint

Enable Placement hint in the Free play start selector, or toggle Hint beside Restart during a game. It is off initially and remains a session preference only. A blue translucent ghost shows a recommended current-piece landing, considering the visible next piece. It does not move the piece or change the RNG, scoring, gravity or input handling.

### Search and strategy

The advisor in js/placement-hint.js now uses an independent Game Boy adaptation of the search structure reviewed in docs/STACKRABBIT-COMPARISON.md. It is not a port of StackRabbit, does not include its NES weights or learned surface tables, and does not claim equivalent playing strength.

The initial search explores current and next placements, including overhang entries, collapses cleared rows, and verifies native tapping routes. It retains up to two verified preview placements for each current move, then refines a diverse shortlist of up to five current moves. This prevents many preview variants of one current move from crowding out alternatives. Immediate reachable Tetrises remain the preferred action.

Evaluation balances the left Tetris well, readiness, surface steps, flat accommodation, dependencies, holes and burial, right-corner shape, height and line-clear rewards. Readiness no longer lexicographically overrides all height and surface terms. Tetris-building, digging and high-stack survival contexts change the balance: an avoidable burn is discouraged on a healthy low stack, while a useful tactical burn can be preferred when recovery is needed. These are locally calibrated heuristics, not learned surface values.

### Future-piece refinement

At ordinary speeds each shortlisted pair is evaluated using 14 common weighted scenarios, covering every possible first unknown piece and two conditional quantiles of the following piece. This extends the horizon to four pieces in total. Each future piece is placed greedily with native route verification; simple landings are checked first, with a geometric overhang search if no simple route works. Repeated rollout states are cached. The score combines expected future value, the known-pair evaluation and a bounded downside term.

At gravity below four frames per row, refinement uses up to four current moves and seven weighted scenarios for one extra future piece. This reduces work at the fastest levels without removing the known-next search or route checks. The search is bounded and its route construction conservative; it does not enumerate every legal input sequence or prove optimality.

The forecast is an explicit approximation: independent uniform candidates passed through the Game Boy selector's two-retry OR-rejection rule. The first unknown piece has exact conditional probabilities under that model; the second is approximated by two quantiles per branch. It is neither a bag nor an NES randomizer, and it does not assume the wiki's long-run percentages are independent draws. Tests enumerate all 343 three-candidate combinations for each of 49 current/next states through RomRandom to check those model probabilities. The real timer-driven process need not follow the model exactly.

The advisor sees the stack, current piece, visible next piece, level and timing. It never reads the actual hidden queue, LFSR seed or future RNG state. Simulated scenarios are common to all compared candidates and deterministic, so lucky private draws do not decide which candidate wins.

### Reachability, runtime and validation

Every accepted current and next landing has a tapping route with at least five native frames between presses and uninterrupted gravity. Preview and rollout verification accounts for level transitions and heart/training speeds. The live ghost is checked again from the actual falling position and phase, so a stale or unreachable target is hidden. No hint is not proof of game over: the bounded search or conservative route builder may have missed an alternative.

The same engine runs in a Blob worker without a server or imported worker files. A cooperative fallback yields between candidates and scenario evaluations. Leaving, restarting or switching hints off cancels the search and rejects stale results. Search duration depends on the device and stack; development checks measured roughly 100–230 ms for selected empty-board searches, with a cold initial search sometimes slower. Gameplay is not paused to wait for a result.

Run node tests/placement-hint.test.cjs for native replay at five speeds, authored tucks and spins, Tetris setup, recovery burns, beam diversity and forecast-model checks. The simulated DOM suite covers the optional ghost, cancellation and server-free fallback. Run node tools/audit-placement-hint.cjs for the same three local 60-piece stress cases used before the changes. The original results are preserved in fixtures/placement-hint-strategy-baseline.json and new results in fixtures/placement-hint-strategy-audit.json. This is a local before/after diagnostic, not a head-to-head StackRabbit benchmark or a statistical strength estimate.
`;
fs.writeFileSync(doc,s);
const comparison=root+'docs/STACKRABBIT-COMPARISON.md';let audit=fs.readFileSync(comparison,'utf8');audit=audit.replace('## Main conclusion','## Before-change findings');const heading=audit.indexOf('## Before-change findings');audit=audit.slice(0,heading)+`## Implementation following this review

The rollout-based revision replaces the rigid priority below with balanced, context-sensitive evaluation while retaining the column-1 Tetris goal and immediate Tetris preference. It adds distinct-current-move pruning, verified preview alternatives, deterministic GB future-piece scenarios, greedy multi-step rollouts and cached future states. At ordinary speeds, refinement sees two unknown future pieces; faster gravity uses one. See [the current implementation notes](FREE-PLAY.md#optional-live-placement-hint).

This applies the reviewed design ideas using independent GB-specific code. The learned surface values, exhaustive movement search and playing strength of StackRabbit have not been reproduced. The comparison table below describes the original advisor at review time and motivates the changes; it is not a description of the revised implementation.

`+audit.slice(heading);audit=audit.replace('These are findings and proposed implementation priorities. This review does not silently replace the user\'s requested Tetris strategy or change live gameplay.','These were the findings before the requested implementation. Items 1–4 now have bounded GB-specific implementations as described above; longer calibration and the playing-strength gap remain.');fs.writeFileSync(comparison,audit);
const html=root+'index.html';fs.writeFileSync(html,fs.readFileSync(html,'utf8').replace('js/playable.js?v=tetris-ready-2','js/playable.js?v=rollouts-3'));
const readme=root+'README.md';let r=fs.readFileSync(readme,'utf8');r=r.replace('## Checks','## Free-play placement hints\n\nEnable Placement hint before starting, or toggle Hint beside Restart. The local advisor uses GB-native route checks, current/next search and weighted future-piece scenarios; it recommends moves rather than guaranteeing optimal play. See docs/FREE-PLAY.md and docs/STACKRABBIT-COMPARISON.md for its model and limits.\n\n## Checks');fs.writeFileSync(readme,r);
console.log('Updated advisor documentation and preserved the historical source comparison.');
