const fs=require('node:fs'),path=require('node:path'),base=path.resolve('../tetris-studio');
function edit(file,fn){const p=path.join(base,file);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));}function swap(s,a,b){if(!s.includes(a))throw Error('Missing '+a.slice(0,90));return s.replace(a,b);}
edit('js/mistake-journal.js',s=>{
 const a=s.indexOf('function isOpenerPlacement('),b=s.indexOf('\nconst api=',a);if(a<0||b<0)throw Error('Opener helper missing');
 return s.slice(0,a)+`function isOpenerPlacement(situations,board,actual,nextType){
 if(!actual)return false;const mask=b=>b.map(r=>[...r].map(c=>c==='.'?'.':'#').join('')).join('/'),empty=board.every(r=>[...r].every(c=>c==='.'));
 return situations.some(s=>{const a=s.adjustment;if(!a)return false;const first=C.compose({board:C.empty(18),active:a.adjusted},18),rows=C.fullRows(first),afterFirst=rows.length?C.collapseRows(first,rows):first,combined=C.compose({board:afterFirst,active:a.next},18),clears=C.fullRows(combined),target=clears.length?C.collapseRows(combined,clears):combined;
  if(empty){if(actual.type!==a.adjusted.type||nextType!==a.next.type)return false;if(footprint(actual)===footprint(a.adjusted))return true;if(actual.type!==a.next.type)return false;
   const placed=C.compose({board,active:actual},18),missing=[];for(let y=0;y<18;y++)for(let x=0;x<10;x++){if(placed[y][x]!=='.'&&target[y][x]==='.')return false;if(placed[y][x]==='.'&&target[y][x]!=='.')missing.push(x+','+y);}if(missing.length!==4)return false;const wanted=missing.sort().join(';');return H.explore(placed,C.spawn(nextType)).some(p=>footprint(p)===wanted&&H.plan(placed,C.spawn(nextType),p,{gravityFrames:53,record:false}));
  }
  if(actual.type!==a.next.type)return false;const occupied=board.flatMap(row=>[...row].filter(c=>c!=='.'));if(occupied.length!==4||occupied.some(type=>type!==a.adjusted.type))return false;const placed=C.compose({board,active:actual},18),cleared=C.fullRows(placed);return mask(cleared.length?C.collapseRows(placed,cleared):placed)===mask(target);
 });
}
`+s.slice(b);
});
edit('js/puzzles.js',s=>{
 s=swap(s,'this.puzzle=true;this.matches=true;this.placements=0;', "this.puzzle=true;this.matches=true;this.placements=0;this.identicalPieces=r.recommended.type===r.next.type;if(this.identicalPieces){const first=after(r.board,r.recommended),second=after(first.board,r.next);this.expectedFinal=second.board.map(row=>row.map(c=>c==='.'?'.':'#').join('')).join('/');this.expectedClears=first.rows.length+second.rows.length;}");
 return swap(s,'if(this.done)this.correct=this.matches&&this.placements===2;', "if(this.done){let matches=this.matches;if(this.identicalPieces){const rows=C.fullRows(this.board),settled=rows.length?C.collapseRows(this.board,rows):this.board;matches=settled.map(row=>row.map(c=>c==='.'?'.':'#').join('')).join('/')===this.expectedFinal&&(this.totalRows||0)===this.expectedClears&&!this.hiddenRows.some(row=>row.some(c=>c!=='.'));}this.correct=matches&&this.placements===2;}");
});
edit('assets/css/studio.css',s=>{
 s=swap(s,'animation:puzzle-count-odd .32s ease-out both','animation:puzzle-count-odd .6s ease-out both');s=swap(s,'animation:puzzle-count-even .32s ease-out both','animation:puzzle-count-even .6s ease-out both');
 const old='0%{transform:scale(.3);opacity:0}55%{transform:scale(1.12);opacity:.42}100%{transform:scale(1);opacity:.32}',next='0%{transform:scale(.01);opacity:0}28%{transform:scale(1);opacity:.38}50%{transform:scale(1.08);opacity:.32}100%{transform:scale(1.4);opacity:0}';if(s.split(old).length!==3)throw Error('Countdown keyframes changed');s=s.split(old).join(next);
 return swap(s,'animation:none;opacity:.32}}\n#mistakeGalleryItems', 'animation:puzzle-count-fade .6s ease-out both}}\n@keyframes puzzle-count-fade{0%,100%{opacity:0}28%,50%{opacity:.32}}\n#mistakeGalleryItems');
});
edit('index.html',s=>s.replace('studio.css?puzzle-colors-1','studio.css?puzzle-fairness-1').replace('js/puzzles.js?v=spaced-untimed-1','js/puzzles.js?v=equivalent-pairs-1').replace('js/mistake-journal.js?v=release-history-1','js/mistake-journal.js?v=opener-equivalence-1'));
console.log('Updated opener exemptions, identical-piece outcome grading and countdown zoom/fade.');
