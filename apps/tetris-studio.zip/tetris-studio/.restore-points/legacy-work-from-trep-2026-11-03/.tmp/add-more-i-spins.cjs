const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
const definitions=[
 {key:'i-spin-cross',title:'I-Spin (cross)',rows:['SSSS.SSSSS','SSSS.SSSSS','SSS....SSS','SSSS.SSSSS','SSSS.SSSSS'],x:3,y:13},
 {key:'i-spin-offset',title:'I-Spin (offset)',rows:['..........','....SSSSSS','S....SSSSS','S..SSSSSSS','SSSSSSSSSS','SSSSSSSSSS'],x:1,y:12},
 {key:'i-spin-open-pocket',title:'I-Spin (open pocket)',rows:['SSSS..SSSS','SSSS..SSSS','SSS....SSS','SSSS....SS','SSSS.SSSSS'],x:3,y:13}
];
for(const d of definitions){
 const s=structuredClone(require(path.join(root,'situations/i-spin-well.js')));s.title=d.title;
 const board=Array.from({length:18},()=>Array(10).fill('.'));d.rows.forEach((r,i)=>board[18-d.rows.length+i]=[...r]);
 const counter=[];for(let dy=0;dy<4;dy++)counter.push([d.x+1,d.y+dy]);for(let dx=0;dx<4;dx++)counter.push([d.x+dx,d.y+2]);
 for(const[x,y]of counter){if(board[y][x]!=='.'&&board[y][x]!==',')throw Error('Pocket overlap');board[y][x]=',';}
 for(const[x,y]of counter)for(const[dx,dy]of [[0,1],[0,-1],[1,0],[-1,0]]){if(board[y+dy]?.[x+dx]==='S')board[y+dy][x+dx]='s';}
 for(const dx of [0,3])for(const dy of [-1,1]){const x=d.x+dx,y=d.y+2+dy;if(board[y]?.[x]==='s')board[y][x]='$';}
 s.stack=board.slice(18-d.rows.length).map(r=>r.join(''));
 for(const f of s.frames.slice(3,7))f.active={x:d.x,y:d.y,rotation:1};s.frames[6].active.rotation=2;
 s.frames[3].caption='2 · Turn the I upright, line up with the channel, then descend to the horizontal slot.';
 s.frames[4].trigger={hole:[d.x+2,d.y+2],button:'B'};
 fs.writeFileSync(path.join(root,'situations',d.key+'.js'),'// I-spin variation reconstructed from the supplied reference.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(d.key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"i-spin-ledge"\n','"i-spin-ledge",\n'+definitions.map(d=>'  '+JSON.stringify(d.key)).join(',\n')+'\n'));
edit('index.html',s=>s.replace('<script src="situations.js">',definitions.map(d=>'<script src="situations/'+d.key+'.js"></script>').join('')+'<script src="situations.js">'));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'09'","libraryCount.textContent,'12'").replace('h.cards().length,8','h.cards().length,11').replace('[2,1,2,2,2]','[2,1,2,2,5]'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,9','C.parseCollection(demo).length,12').replace("s.title.startsWith('I-Spin'));assert.equal(variants.length,2)","s.title.startsWith('I-Spin'));assert.equal(variants.length,5)").replace('s.frames[7].clearRows,[i===0?16:15]','s.frames[7].clearRows,[[16],[15],[15],[14],[15]][i]'));
