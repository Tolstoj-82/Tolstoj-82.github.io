const fs=require('fs'),r='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio';
const extra=[
 ['adjustment-vits-s-east',['....S.....','..S.S.....','S.SSS.....','SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'S',x:1,y:12,rotation:1}],
 ['adjustment-vits-z-east',['SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'Z',x:1,y:11,rotation:1}],
 ['adjustment-vits-z-north',['SSSSSS....','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'Z',x:1,y:12,rotation:0}],
 ['adjustment-vits-t-west',['......S...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'T',x:0,y:11,rotation:3}],
 ['adjustment-vits-t-north',['SSSSSS....','SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'T',x:1,y:12,rotation:0}],
 ['adjustment-vits-t-east',['SSSSSSS...','SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'T',x:1,y:12,rotation:1}],
 ['adjustment-vits-t-south',['SS..SS....','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'T',x:1,y:12,rotation:2}],
 ['adjustment-vits-o-north',['......S...','.S.S.SS...','SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'O',x:0,y:11,rotation:0}]
];
let p=r+'/vits.test.cjs',s=fs.readFileSync(p,'utf8').replace('const fits=', 'fixtures.push(...'+JSON.stringify(extra)+');\nconst fits=').replace("s.section==='VITS').length,13","s.section==='VITS').length,21").replace("'PASS thirteen mirrored VITS: '","'PASS twenty-one mirrored VITS: '");fs.writeFileSync(p,s);
for(const name of ['core.test.cjs','app.test.cjs']){p=r+'/'+name;s=fs.readFileSync(p,'utf8').replaceAll('C.parseCollection(demo).length,241','C.parseCollection(demo).length,249').replaceAll("libraryCount.textContent,'241'","libraryCount.textContent,'249'").replaceAll('h.cards().length,240','h.cards().length,248').replace('containing thirteen L/J/S and I examples','containing twenty-one setups').replace('assert.equal(vits.children.length,14)','assert.equal(vits.children.length,22)');fs.writeFileSync(p,s);}
