const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
fs.copyFileSync(path.join(__dirname,'course.js'),path.join(root,'course.js'));
edit('index.html',s=>s.replace('<title>Tetris Studies · Tolstoj</title>','<title>Game Boy Tetris course</title>').replace('<h1>Tetris situations</h1>','<h1>Game Boy Tetris course</h1>').replace('☰</span> Situations','☰</span> Chapters').replace('<h2>Situations <span','<h2>Course <span').replace('<div class="board-player">','<section id="courseIntroduction" class="course-introduction-panel" hidden><h2 id="courseIntroTitle"></h2><div id="courseIntroBody"></div></section><div class="board-player">').replace('<div class="screen-bezel"><div class="lcd">','<div class="screen-bezel"><div id="ghostPlacementLabel" class="ghost-placement-label" hidden></div><div class="lcd">').replace('<ol id="spinConcepts">','<div id="nextPiecePanel" class="next-piece-panel" hidden><span>Next <strong id="nextPieceName"></strong></span><canvas id="nextPieceCanvas" width="48" height="36" role="img" aria-label="Next piece"></canvas></div><ol id="spinConcepts">').replace('<script src="situations.js">','<script src="situations/adjustment-lj-koryan.js"></script><script src="situations.js">').replace('<script src="playable.js">','<script src="course.js"></script><script src="playable.js">'));
edit('app.js',s=>{
 s=s.replace("url.searchParams.set('situation',situationKey(studies[selected]));", "url.searchParams.delete('lesson');url.searchParams.set('situation',situationKey(studies[selected]));");
 s=s.replace(' if(cleanStudies.has(s))return cleanStudies.get(s);',' if(cleanStudies.has(s))return cleanStudies.get(s);\n if(s.adjustment){const clean=TetrisCourse.clean(s);cleanStudies.set(s,clean);return clean;}');
 s=s.replace('  drawActiveOverlay(ctx,f,height);', '  drawActiveOverlay(ctx,f,height);TetrisCourse.annotations(ctx,f,height);');
 s=s.replace("['Spins','Spucks']", "['Introduction','Spins','Spucks','Adjustments']");
 s=s.replace("$('libraryCount').textContent=", "TetrisCourse.navigation(categories);$('libraryCount').textContent=");
 s=s.replace("card.onclick=()=>{globalThis.liveAttempt", "card.onclick=()=>{TetrisCourse.leaveIntro();globalThis.liveAttempt");
 s=s.replace("const isSpuck=situationKey(s)", "const isAdjustment=s.chapter==='Adjustments',isSpuck=situationKey(s)");
 s=s.replace("label=situationKey(s).startsWith('jd-spin-')", "label=isAdjustment?'Piece-dependent placements':situationKey(s).startsWith('jd-spin-')");
 s=s.replaceAll("categories.get(isSpuck?'Spucks':'Spins')", "categories.get(isAdjustment?'Adjustments':isSpuck?'Spucks':'Spins')");
 s=s.replace('function renderConcepts(){\n const s=current(),',()=>`function renderConcepts(){
 const lesson=current();$('spinConcepts').classList.toggle('adjustment-concepts',!!lesson.adjustment);
 if(lesson.adjustment){referenceSituation=null;TetrisCourse.reference(lesson,index);return;}
 const s=current(),`);
 s=s.replace('function render(full=false){renderConcepts();', 'function render(full=false){renderConcepts();TetrisCourse.supplement(current(),frame(),elapsed);');
 s=s.replace("renderConcepts();$('frameCaption').textContent=", "renderConcepts();TetrisCourse.supplement(current(),frame(),elapsed);$('frameCaption').textContent=");
 s=s.replace('inputs:showInputs,notice});', 'inputs:showInputs,next:TetrisCourse.practiceNext,notice});\nTetrisCourse.init({stop,closeMenu:closeSituationMenu});');
 return s;
});
edit('playable.js',s=>{
 s=s.replace("this.goal=C.clone(s.frames.filter(f=>!f.example&&f.active).at(-1)?.active||null);", "this.goals=s.adjustment?[C.clone(s.adjustment.adjusted),C.clone(s.adjustment.next)]:[C.clone(s.frames.filter(f=>!f.example&&f.active).at(-1)?.active||null)];this.pieceIndex=0;this.goal=this.goals[0];");
 s=s.replace('this.done=true;this.rows=rows.length;}',()=>`this.done=true;this.rows=rows.length;
 if(this.correct&&this.pieceIndex+1<this.goals.length){this.pieceIndex++;this.goal=this.goals[this.pieceIndex];this.pendingPiece=this.goal.type;this.spawnElapsed=0;this.done=false;this.active=null;}
 }`);
 s=s.replace('advance(ms){if(this.done)',()=>`advance(ms){if(this.pendingPiece){this.spawnElapsed+=ms;if(this.spawnElapsed>=2*1000/C.HZ){this.active={type:this.pendingPiece,x:3,y:0,rotation:0};this.pendingPiece=null;this.frame=null;this.elapsed=0;if(!this.fits(this.active)){this.done=true;this.correct=false;}}return;}if(this.done)`);
 s=s.replace('function draw(){if(!attempt)return;const f=', 'function draw(){if(!attempt)return;bridge.next?.(attempt.goals.length>1&&attempt.pieceIndex===0?attempt.goals[1].type:null);const f=');
 return s;
});
edit('studio.css',s=>s+`
/* Course navigation and adjustment lessons share the original player layout. */
.course-lesson-link { display: block; width: 100%; text-align: left; border: 0; border-radius: 0; box-shadow: none; padding: 10px 12px; background: transparent; font-weight: 400; }
.course-introduction-panel { max-width: 560px; line-height: 1.7; padding: 8px 8px 24px; }
.course-introduction-panel h2 { font-size: 23px; margin-top: 0; }
.course-introduction .board-player,.course-introduction .study-heading,.course-introduction .try-situation,.course-introduction .stack-editor-toggle { display: none; }
.player-column .screen-bezel { position: relative; }
.ghost-placement-label { position: absolute; z-index: 3; right: 7px; bottom: 7px; padding: 3px 6px; background: #ffffffed; color: #334155; border: 1px solid #64748b; border-radius: 3px; font: 600 11px system-ui,sans-serif; pointer-events: none; }
.next-piece-panel { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid #cbd5e1; font-size: 13px; }
.next-piece-panel canvas { width: 48px; height: 36px; image-rendering: pixelated; }
.board-player > .spin-summary .adjustment-concepts li:nth-child(3)::before { counter-increment: spin-item; content: counter(spin-item) '.'; }
`);
