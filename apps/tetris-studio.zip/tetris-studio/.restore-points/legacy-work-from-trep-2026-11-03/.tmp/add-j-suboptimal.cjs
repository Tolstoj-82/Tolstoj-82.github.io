const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const variant of ['well','center']){
 const left=variant==='well',x=left?0:1,y=15,rotation=left?1:3,after=left?2:0;
 const s=structuredClone(require(path.join(root,'situations/j-spin-'+variant+'.js')));s.title='J-Spin (suboptimal, '+variant+')';
 const rows=left?['..SSSSSSSS','..SSSSSSSS','..$sSSSSSS','...$SSSSSS','..$sSSSSSS']:['SS..SSSSSS','SS..SSSSSS','s$..SSSSSS','$...SSSSSS','s$..SSSSSS'];
 const board=Array.from({length:18},()=>Array(10).fill('.'));rows.forEach((r,i)=>board[i+13]=[...r]);
 for(const r of [rotation,after])for(const[dx,dy]of C.cells('J',r)){if(board[y+dy][x+dx]!=='.'&&board[y+dy][x+dx]!==',')throw Error('overlap');board[y+dy][x+dx]=',';}
 s.stack=board.slice(13).map(r=>r.join(''));
 for(const f of s.frames.slice(3,7))f.active={x,y,rotation};
 s.frames[3].buttons=[left?'B':'A'];
 s.frames[4].trigger={hole:[left?2:1,16],button:'A'};
 s.frames[5].buttons=['A'];s.frames[5].caption='4 · Press A to rotate the J counterclockwise into the shorter pocket.';
 s.frames[6].active.rotation=after;s.frames[6].caption='5 · The J fits into the shorter pocket and completes the row.';
 const key='j-spin-suboptimal-'+variant;fs.writeFileSync(path.join(root,'situations',key+'.js'),'// Suboptimal J-spin reconstructed from the supplied reference.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"j-spin-center"\n','"j-spin-center",\n  "j-spin-suboptimal-well",\n  "j-spin-suboptimal-center"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/j-spin-suboptimal-well.js"></script><script src="situations/j-spin-suboptimal-center.js"></script><script src="situations.js">'));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'14'","libraryCount.textContent,'16'").replace('h.cards().length,13','h.cards().length,15').replace('[2,1,2,2,5,2]','[2,1,2,2,5,4]'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,14','C.parseCollection(demo).length,16').replace("s.title.startsWith('J-Spin'));assert.equal(variants.length,2)","s.title.startsWith('J-Spin')&&!s.title.includes('suboptimal'));assert.equal(variants.length,2)")+`
test('suboptimal J-spins descend safely and use A to fill their shorter pockets',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('J-Spin (suboptimal'));assert.equal(variants.length,2);
 for(const[i,s]of variants.entries()){
  const f=s.frames[3],stack=C.compose({...f,active:undefined},18);
  for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells(a.type,a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}
  assert.deepEqual(s.frames[5].buttons,['A']);assert.equal(s.frames[6].active.rotation,i===0?2:0);assert.deepEqual(s.frames[7].clearRows,[16]);assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
