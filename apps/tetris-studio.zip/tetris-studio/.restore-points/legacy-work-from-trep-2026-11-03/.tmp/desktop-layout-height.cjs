const fs=require('node:fs');const p='../tetris-studio/assets/css/studio.css';let css=fs.readFileSync(p,'utf8');
css=css.replace('--desktop-board-width:min(clamp(192px,calc((100dvh - 270px)/2.03),432px),','--desktop-board-width:min(clamp(192px,calc((100dvh - 320px)/2.03),432px),');
const marker='@media(min-width:1000px) and (max-height:780px){\n main{padding-top:16px;';
if(!css.includes(marker))throw Error('Height rule not found');
css=css.replace(marker,'@media(min-width:1000px) and (max-height:780px){\n :root{--desktop-board-width:min(clamp(192px,calc((100dvh - 284px)/2.03),432px),calc(100vw - var(--desktop-sidebar-width) - 340px))}\n main{padding-top:16px;');
fs.writeFileSync(p,css);console.log('Reserved desktop height for the complete board, actions and transport.');
