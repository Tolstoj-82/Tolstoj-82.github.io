const s=require('fs').readFileSync('../tetris-studio/app.test.cjs','utf8');for(const m of s.matchAll(/.{0,70}children\[1\]\.children\[0\].{0,70}/g))console.log(m[0]);
