from pathlib import Path
r=Path('C:/Users/marti/Desktop/Tetris_lfsr.gb').read_bytes()
for lo,hi in [(0x7e00,0x8000),(0x2900,0x2a10)]:
 for p in range(lo,hi,16):print(f'{p:04x}',r[p:p+16].hex(' '))
print('XOR immediates')
for i,b in enumerate(r[:0x323f]):
 if b==0xee:print(hex(i),r[max(0,i-12):i+14].hex(' '))
