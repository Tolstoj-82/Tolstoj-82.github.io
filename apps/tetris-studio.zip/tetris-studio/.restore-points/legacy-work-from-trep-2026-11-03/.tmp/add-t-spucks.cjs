const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const side of ['right','left']){
 const right=side==='right',x=right?0:7,rotation=right?1:3,button=right?'B':'A',direction=right?'Right':'Left';
 const rows=['..SSSSSSSS','..SSSSSSSS','...SSSSSS','.....SSSSS','.....SSSSS'];const board=Array.from({length:18},()=>Array(10).fill('.'));rows.forEach((r,i)=>board[i+13]=[...(right?r:[...r].reverse().join(''))]);
 const poses=[{x,y:15,rotation},{x,y:15,rotation:2},{x:x+(right?1:-1),y:15,rotation:2},{x:x+(right?1:-1),y:16,rotation:2}];
 for(const a of poses)for(const[dx,dy]of C.cells('T',a.rotation)){if(board[a.y+dy][a.x+dx]!=='.'&&board[a.y+dy][a.x+dx]!==',')throw Error('overlap');board[a.y+dy][a.x+dx]=',';}
 // Include the extra empty end of the staircase from the reference.
 board[17][right?4:5]=',';
 for(let y=13;y<18;y++)for(let x=0;x<10;x++)if(board[y][x]===',')for(const[dx,dy]of [[0,-1],[0,1],[-1,0],[1,0]])if(board[y+dy]?.[x+dx]==='S')board[y+dy][x+dx]='s';
 for(const[px,py]of [[right?2:7,14],[right?3:6,15],[right?5:4,16]])if(board[py][px]==='s')board[py][px]='$';
 const active={x,y:15,rotation},result={x,y:15,rotation:2},finish={x:x+(right?1:-1),y:16,rotation:2},spawn={x:3,y:0};
 const s={title:'T-Spuck ('+side+' tuck)',piece:'T',stack:board.slice(13).map(r=>r.join('')),frames:[
 {step:'1',caption:'1 · The T piece in its starting orientation.',ticks:96,active:spawn,highlight:'blink',blink:true,reveal:'piece'},
 {step:'1a',caption:'1a · The stack around the staircase pocket is the motif.',ticks:144,active:spawn,motif:true,mandatoryAfter:48,highlight:false,blink:true,reveal:'match'},
 {step:'1b',caption:'1b · The counter-motif leaves space for the rotation and the sideways tuck.',ticks:96,active:spawn,counterMotif:true,highlight:false,blink:true,reveal:'counter'},
 {step:'2',caption:'2 · Turn the T upright and descend beside the staircase.',ticks:144,active,buttons:[button],animate:true,fallFirst:4,reveal:'rotation'},
 {step:'3',caption:'3 · Align the pivot with the empty square toward the staircase.',ticks:96,active,trigger:{hole:[right?2:7,16],button},blink:true,reveal:'trigger'},
 {step:'4',caption:'4 · Press '+button+' to turn the T with its spike pointing up.',ticks:45,active,buttons:[button],reveal:'input'},
 {step:'5',caption:'5 · The T has turned. It still needs a sideways input to tuck underneath.',ticks:70,active:result,reveal:'spin'},
 {step:'6',caption:'6 · Press '+direction.toLowerCase()+' to tuck the T into the staircase as it falls.',ticks:48,active:result,buttons:[direction]},
 {step:'7',caption:'7 · Move '+direction.toLowerCase()+', then gravity lowers the T into the pocket. No line clears here.',ticks:84,active:finish,buttons:[direction],animate:true}
 ]};
 const key='t-spuck-'+side;fs.writeFileSync(path.join(root,'situations',key+'.js'),'// T spin-and-tuck reconstructed from the supplied reference.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"l-spin-suboptimal-right"\n','"l-spin-suboptimal-right",\n  "t-spuck-right",\n  "t-spuck-left"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/t-spuck-right.js"></script><script src="situations/t-spuck-left.js"></script><script src="situations.js">'));
edit('app.js',s=>s.replace("const family=situationKey(s).split('-spin')[0],label=", "const isSpuck=situationKey(s).includes('-spuck-'),family=situationKey(s).split('-spin')[0],label=isSpuck?'T-Spucks':").replace("categories.get('Spins').append(group)","categories.get(isSpuck?'Spucks':'Spins').append(group)"));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'19'","libraryCount.textContent,'21'").replace('h.cards().length,18','h.cards().length,20').replace('assert.equal(categories[1].children.length,1);',"assert.equal(categories[1].children.length,2);assert.equal(categories[1].children[1].children[0].textContent,'T-Spucks');assert.equal(categories[1].children[1].children.length,3);"));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,19','C.parseCollection(demo).length,21')+`
test('T-Spucks rotate then tuck sideways with safe paths and no line clear',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('T-Spuck'));assert.equal(variants.length,2);
 for(const[i,s]of variants.entries()){
  assert.deepEqual(s.frames[5].buttons,[i===0?'B':'A']);assert.equal(s.frames[6].active.rotation,2);assert.deepEqual(s.frames[7].buttons,[i===0?'Right':'Left']);assert(s.frames[8].animate);assert(!s.frames.some(f=>f.clear));
  for(const f of s.frames.filter(f=>f.animate)){const stack=C.compose({...f,active:undefined},18);for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells(a.type,a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}}
  assert.equal(s.frames[8].active.y,16);assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
