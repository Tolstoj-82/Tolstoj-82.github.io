const fs=require('node:fs'),root='../tetris-studio/';
const file=root+'js/app.js';let s=fs.readFileSync(file,'utf8');
s=s.replace('function drawRomTile(ctx,id,x,y,size=8){','function drawRomTile(ctx,id,x,y,size=8,palette=shades){').replace('ctx.fillStyle=shades[+pattern[py][px]]','ctx.fillStyle=palette[+pattern[py][px]]');
const a=s.indexOf('  if(f.placementHint){'),b=s.indexOf('   if(f.motif){',a);if(a<0||b<0)throw Error('Ghost renderer not found');
s=s.slice(0,a)+`  if(f.placementHint){
   const hint=f.placementHint,shape=C.cells(hint.type,hint.rotation),sprites=C.pieceLayout(hint.type,hint.rotation),blue=['#dce9fa','#9ab9df','#477cb9','#244b7b'],active=new Set(f.active?C.cells(f.active.type,f.active.rotation).map(([dx,dy])=>[f.active.x+dx,f.active.y+dy].join(',')):[]);
   const visible=(x,y)=>y>=0&&y<height&&board[y]?.[x]==='.'&&!active.has([x,y].join(','));
   ctx.save();ctx.globalAlpha=.75;
   if(hint.type==='I'){
    const xs=shape.map(([dx])=>hint.x+dx),ys=shape.map(([,dy])=>hint.y+dy),left=Math.min(...xs),top=Math.min(...ys),w=(Math.max(...xs)-left+1)*8,h=(Math.max(...ys)-top+1)*8,px=8+left*8,py=(18-height+top)*8;
    ctx.fillStyle='#477cb9';
    if(shape.every(([dx,dy])=>visible(hint.x+dx,hint.y+dy))){ctx.fillRect(px,py,w,1);ctx.fillRect(px,py+h-1,w,1);ctx.fillRect(px,py+1,1,h-2);ctx.fillRect(px+w-1,py+1,1,h-2);}
    else for(let y=0;y<h;y++)for(let x=0;x<w;x++)if((x===0||x===w-1||y===0||y===h-1)&&visible(left+Math.floor(x/8),top+Math.floor(y/8)))ctx.fillRect(px+x,py+y,1,1);
   }else for(const[i,[dx,dy]]of shape.entries()){const x=hint.x+dx,y=hint.y+dy;if(visible(x,y))drawRomTile(ctx,sprites[i][2],8+x*8,(18-height+y)*8,8,blue);}
   ctx.restore();
  }
`+s.slice(b);fs.writeFileSync(file,s);
const test=root+'tests/app.test.cjs';let tests=fs.readFileSync(test,'utf8');tests=tests.replaceAll("o.color==='#477cb9'&&o.alpha===.9","['#dce9fa','#9ab9df','#477cb9','#244b7b'].includes(o.color)&&o.alpha===.75");
tests=tests.replace("'hollow blue ghost is drawn'","'blue ghost is drawn'").replace("assert.equal(edges.length,16);assert(edges.every(o=>o.w===1||o.h===1),'ghost has outlines only');","assert(edges.length===4||edges.length===256,'I has one rectangle; other pieces retain their ROM pixels');");
tests+=`
test('Free play ghosts preserve real mino textures in a fully blue palette, with one rectangle for I',()=>{
 const h=boot(),C=h.context.TetrisCore,blue=['#dce9fa','#9ab9df','#477cb9','#244b7b'];
 for(const[type,count]of [['L',4],['J',4],['I',2],['O',1],['Z',2],['S',2],['T',4]])for(let rotation=0;rotation<count;rotation++){
  const hint={type,x:3,y:10,rotation},board=C.empty(18);h.context.drawGrid(h.elements.board,board,18,{board,placementHint:hint,highlight:false});
  const pixels=h.elements.board.ops.filter(o=>o.alpha===.75);assert(pixels.every(o=>blue.includes(o.color)),'no green ghost pixels, including the outlines');
  if(type==='I'){assert.equal(pixels.length,4);const cells=C.cells(type,rotation),width=(Math.max(...cells.map(p=>p[0]))-Math.min(...cells.map(p=>p[0]))+1)*8,height=(Math.max(...cells.map(p=>p[1]))-Math.min(...cells.map(p=>p[1]))+1)*8;assert.equal(pixels[0].w,width);assert.equal(pixels[1].w,width);assert.equal(pixels[2].h,height-2);assert.equal(pixels[3].h,height-2);}
  else{assert.equal(pixels.length,256);const sprites=C.pieceLayout(type,rotation);for(let i=0;i<4;i++)for(let py=0;py<8;py++)for(let px=0;px<8;px++)assert.equal(pixels[i*64+py*8+px].color,blue[+C.ROM.tiles[sprites[i][2]][py][px]],type+' exact ROM texture');}
 }
});
`;
fs.writeFileSync(test,tests);
const html=root+'index.html';fs.writeFileSync(html,fs.readFileSync(html,'utf8').replace('js/app.js?v=blue-ghost-2','js/app.js?v=blue-texture-ghost-3'));
const doc=root+'docs/FREE-PLAY.md';fs.writeFileSync(doc,fs.readFileSync(doc,'utf8').replace('Hints use hollow blue mino outlines; ghost minos do not draw green ROM tiles or filled centres. Active and locked minos keep their ordinary graphics.','Hint minos use the original ROM texture with all four shades remapped to blue, including their outlines. The I hint uses a single blue bounding rectangle instead of individual mino textures or internal dividers. Ghosts remain translucent and do not paint over the active piece. Active and locked minos keep their ordinary graphics.'));
console.log('Restored blue-tinted ROM minos, including blue outlines, with a single I rectangle.');
