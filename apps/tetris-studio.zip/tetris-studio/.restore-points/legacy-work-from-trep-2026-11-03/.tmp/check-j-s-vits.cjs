const fs=require('fs'),r='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio';
const extra=[
 ['adjustment-vits-j-south',['.S.S......','SSSSSS....','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'J',x:1,y:12,rotation:2}],
 ['adjustment-vits-j-west',['..S...S...','.SSS..S...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'J',x:0,y:11,rotation:3}],
 ['adjustment-vits-j-north',['.....S....','.S.S.S....','SSSSSS.S..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'J',x:1,y:12,rotation:0}],
 ['adjustment-vits-j-east',['......S...','.S.S..S...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'J',x:1,y:11,rotation:1}],
 ['adjustment-vits-s-north',['SSSSS.....','SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],{type:'S',x:1,y:11,rotation:0}]
];
let p=r+'/vits.test.cjs',s=fs.readFileSync(p,'utf8');s=s.replace('const fits=', 'fixtures.push(...'+JSON.stringify(extra)+');\nconst fits=');s=s.replace("s.section==='VITS').length,8", "s.section==='VITS').length,13").replace("'PASS eight mirrored VITS: '","'PASS thirteen mirrored VITS: '");fs.writeFileSync(p,s);
for(const name of ['core.test.cjs','app.test.cjs']){p=r+'/'+name;s=fs.readFileSync(p,'utf8').replaceAll('C.parseCollection(demo).length,236','C.parseCollection(demo).length,241').replaceAll("libraryCount.textContent,'236'","libraryCount.textContent,'241'").replaceAll('h.cards().length,235','h.cards().length,240').replace('containing the eight L/I examples','containing thirteen L/J/S and I examples').replace('assert.equal(vits.children.length,9)','assert.equal(vits.children.length,14)');fs.writeFileSync(p,s);}
