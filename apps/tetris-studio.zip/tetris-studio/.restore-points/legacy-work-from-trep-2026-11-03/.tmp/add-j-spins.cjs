const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const variant of ['well','center']){
 const left=variant==='well',x=left?0:2,y=15,rotation=left?1:3,after=left?0:2;
 const s=structuredClone(require(path.join(root,'situations/i-spin-well.js')));s.title='J-Spin ('+variant+')';s.piece='J';
 const rows=left?['..SSSSSSSS','..SSSSSSSS','..$sSSSSSS','...$SSSSSS','...$SSSSSS']:['SSS..SSSSS','S$s..SSSSS','Ss...SSSSS','S$...SSSSS','S$s..SSSSS'];
 const board=Array.from({length:18},()=>Array(10).fill('.'));rows.forEach((r,i)=>board[i+13]=[...r]);
 for(const r of [rotation,after])for(const[dx,dy]of C.cells('J',r)){if(board[y+dy][x+dx]!=='.'&&board[y+dy][x+dx]!==',')throw Error('overlap');board[y+dy][x+dx]=',';}
 s.stack=board.slice(13).map(r=>r.join(''));
 for(const f of s.frames.slice(0,3)){f.active={x:3,y:0};f.caption=f.caption.replaceAll('I piece','J piece');}
 for(const f of s.frames.slice(3,7))f.active={x,y,rotation};
 s.frames[2].caption='1b · The empty pocket is the counter-motif: room for the upright J and the turn beneath the overhang.';
 s.frames[3].buttons=[left?'B':'A'];s.frames[3].caption='2 · Turn the J upright, move into the channel, then descend to the pocket.';
 s.frames[4].trigger={hole:[left?2:2,16],button:'B'};s.frames[4].caption='3 · Align the pivot with the adjacent empty square on its '+(left?'right.':'left.');
 delete s.frames[5].buttonOptions;s.frames[5].caption='4 · Press B to rotate the J clockwise into the pocket.';
 s.frames[6].active.rotation=after;s.frames[6].caption='5 · The J fits under the overhang and completes the row.';
 const key='j-spin-'+variant;fs.writeFileSync(path.join(root,'situations',key+'.js'),'// J-spin placement reconstructed from the supplied reference.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"i-spin-open-pocket"\n','"i-spin-open-pocket",\n  "j-spin-well",\n  "j-spin-center"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/j-spin-well.js"></script><script src="situations/j-spin-center.js"></script><script src="situations.js">'));
edit('app.js',s=>s.replace("i:'I-Spins',jd:","i:'I-Spins',j:'J-Spins',jd:"));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'12'","libraryCount.textContent,'14'").replace('h.cards().length,11','h.cards().length,13').replace("'S-Spins','I-Spins']","'S-Spins','I-Spins','J-Spins']").replace('[2,1,2,2,5]','[2,1,2,2,5,2]'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,12','C.parseCollection(demo).length,14')+`
test('J-spin placements have safe approaches, B input and one completed row',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('J-Spin'));assert.equal(variants.length,2);
 for(const[i,s]of variants.entries()){
  assert.deepEqual(s.frames.map(f=>f.step),['1','1a','1b','2','3','4','5','6']);
  const f=s.frames[3],stack=C.compose({...f,active:undefined},18);
  for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells(a.type,a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}
  assert.deepEqual(s.frames[5].buttons,['B']);assert.equal(s.frames[5].buttonOptions,undefined);assert.equal(s.frames[6].active.rotation,i===0?0:2);assert.deepEqual(s.frames[7].clearRows,[16]);assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
