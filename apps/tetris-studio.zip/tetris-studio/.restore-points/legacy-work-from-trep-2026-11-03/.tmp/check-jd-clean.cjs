const fs=require('fs');const p=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio\app.test.cjs`;
let s=fs.readFileSync(p,'utf8');s=s.replace(" await test('Spins and Spucks",` await test('JD clean playback preserves both opening turns and the tuck before final rotation',()=>{
  for(const side of ['left','right']){const h=boot(undefined,'file:///C:/tetris/index.html?situation=jd-spin-'+side);h.elements.cleanPlayback.checked=true;h.change('cleanPlayback',true);const s=h.exported(),poses=s.frames.filter(f=>f.active),inputs=poses.map((f,i)=>[f,i]).filter(([f])=>f.buttons.length);
   assert.deepEqual(inputs.filter(([f])=>f.buttons.includes('B')).slice(0,2).map(([f])=>f.active.rotation),[1,2]);
   const tuck=inputs.find(([f])=>f.buttons.includes(side==='left'?'Left':'Right'));const final=inputs.at(-1);assert(tuck[1]<final[1]);assert.deepEqual(final[0].buttons,[side==='left'?'A':'B']);
   for(const f of poses){const stack=h.context.TetrisCore.compose({...f,active:undefined},18);for(const[x,y]of h.context.TetrisCore.cells('T',f.active.rotation))assert.equal(stack[f.active.y+y][f.active.x+x],'.');}
   assert(s.frames.at(-1).clear);
  }
 });
 await test('Spins and Spucks`);fs.writeFileSync(p,s);
