const fs=require('fs');
const defs=[
 {key:'adjustment-vits-australian-west',title:'VITS · Australian · L West',source:['......S...','..S...SS..','.SSS..SS..','SSSS.SS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],def:{type:'L',x:0,y:15,rotation:1},adjusted:{type:'L',x:0,y:11,rotation:3}},
 {key:'adjustment-vits-australian-east',title:'VITS · Australian · L East',source:['.S.S.S.S..','SSSSSSSS..','SSSSSSS...','SSSSSSS...','SSSSSSS...','SSSSSSSS..','SSSSSSSS..'],def:{type:'L',x:0,y:15,rotation:1},adjusted:{type:'L',x:1,y:13,rotation:1}},
 {key:'adjustment-vits-australian-south',title:'VITS · Australian · L South',source:['......S...','.S.S.SS...','SSSSSS....','SSSSSS....','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],def:{type:'L',x:0,y:15,rotation:1},adjusted:{type:'L',x:1,y:12,rotation:2}},
 {key:'adjustment-vits-australian-north',title:'VITS · Australian · L North',source:['....S.....','S...SS....','S.S.SSS...','SSSSSS....','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],def:{type:'L',x:0,y:15,rotation:1},adjusted:{type:'L',x:1,y:11,rotation:0}}
].map(d=>({...d,description:'An Australian: tuck L right into the recess, then lower I at the left wall and tuck it right beneath L. The first tuck sets up the second.'}));
let script=fs.readFileSync('.tmp/add-vits-section.cjs','utf8');const first=script.indexOf('definitions=['),end=script.indexOf('\n];',first);if(first<0||end<0)throw Error('Missing definitions');script=script.slice(0,first)+'definitions='+JSON.stringify(defs,null,2)+script.slice(end+2);
script=script.replace("pre=n?{...target,x:target.x-1}:target", "pre={...target,x:target.x-1}");script=script.replace("if(n){if(!fits(board,target))", "if(true){if(!fits(board,target))");
script=script.replace("caption:n&&g.input==='right'?'Press Right once to tuck I under L.'", "caption:g.input==='right'?(n?'Press Right once to tuck I under L.':'Press Right once to tuck L beneath the overhang.')");
script=script.replace("caption:'Four rows are ready for a Tetris; the left well stays open.'", "caption:'The first tuck set up the I tuck. The left well stays open for a Tetris.'");
script=script.replace("template.section='VITS';generated.unshift(['adjustment-vits-palito',template]);",'');script=script.replaceAll('229','232').replaceAll('228','231').replaceAll('232\'','236\'').replace('demo).length,232','demo).length,236').replace('h.cards().length,231','h.cards().length,235');
script=script.replace("console.log('Moved Palito into VITS and added three mirrored L/I lessons.');", "console.log('Added four Australian VITS lessons.');");
fs.writeFileSync('.tmp/add-australian-vits-generated.cjs',script);
