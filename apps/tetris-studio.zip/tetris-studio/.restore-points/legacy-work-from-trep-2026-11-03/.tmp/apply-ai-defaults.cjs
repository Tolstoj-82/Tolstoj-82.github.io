const fs=require('node:fs'),path=require('node:path'),root=path.resolve('../tetris-studio'),C=require(root+'/js/core'),H=require(root+'/js/placement-hint');require(root+'/js/course');
const changes={'australian-tucks':{type:'L',x:1,y:16,rotation:2},'l-doubletuck':{type:'J',x:6,y:14,rotation:2}};
const backup=path.resolve('artifacts/ai-defaults-before');fs.mkdirSync(backup,{recursive:true});
for(const[key,pose]of Object.entries(changes)){
 const file=root+'/situations/adjustment-'+key+'.js',raw=C.clone(require(file)),s=C.normalize(raw),b=C.compose({...s.frames[0],active:undefined},18);
 if(!H.fits(b,pose)||H.fits(b,{...pose,y:pose.y+1})||!H.plan(b,C.spawn(pose.type),pose,{gravityFrames:17}))throw Error(key+' invalid AI default');
 fs.copyFileSync(file,backup+'/'+path.basename(file));raw.adjustment.default=pose;
 for(const frame of raw.frames)if(frame.ghost?.label==='Default')frame.ghost={...pose,label:'Default'};
 global.TetrisCourse.clean(C.normalize(raw));
 fs.writeFileSync(file,'// Mirrored Game Boy adjustment. Default checked with the free-play AI.\n(function(root){const situation='+JSON.stringify(raw,null,2)+';if(typeof module!=="undefined")module.exports=situation;else(root.TetrisSituationFiles??={})['+JSON.stringify('adjustment-'+key)+']=situation;})(globalThis);\n');
 console.log('Updated',key,JSON.stringify(pose));
}
const test=root+'/tests/adjustments.test.cjs';let t=fs.readFileSync(test,'utf8').replace("['australian-tucks',{type:'L',x:0,y:15,rotation:3}]","['australian-tucks',{type:'L',x:1,y:16,rotation:2}]").replace("['l-doubletuck',{type:'J',x:5,y:14,rotation:2}]","['l-doubletuck',{type:'J',x:6,y:14,rotation:2}]").replace("assert.equal(H.features(C.compose({board:base,active:a.default},18)).holes,H.features(base).holes,key+' no added holes');","assert(H.features(C.compose({board:base,active:a.default},18)).holes<=H.features(base).holes,key+' no added holes');");fs.writeFileSync(test,t);
const index=root+'/index.html';t=fs.readFileSync(index,'utf8');for(const key of Object.keys(changes))t=t.replace(new RegExp('(situations/adjustment-'+key+'\\.js)(?:\\?[^"\\s]*)?'),'$1?v=ai-default-3');fs.writeFileSync(index,t);
