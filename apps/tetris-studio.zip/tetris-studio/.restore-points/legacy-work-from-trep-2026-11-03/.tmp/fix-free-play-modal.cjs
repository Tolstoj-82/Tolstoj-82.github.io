const fs=require('node:fs'),path=require('node:path'),base=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,file=path.join(base,'assets/css/studio.css');let s=fs.readFileSync(file,'utf8');
const oldShort='@media(min-width:520px) and (max-height:640px){#freeStartPicker{width:min(600px,calc(100vw - 24px));grid-template-columns:minmax(0,.85fr) minmax(0,1.15fr);grid-template-areas:"title title" "levels options" "actions actions";column-gap:16px}#freeStartPicker .free-seed-fields{align-self:end}}';
const oldSource='@media(min-width:520px) and (max-height:640px){#freeStartPicker{grid-template-areas:"title title" "source source" "levels options" "actions actions"}}';
const oldAuto='@media(min-width:520px) and (min-height:641px) and (max-height:740px){#freeStartPicker{width:min(600px,calc(100vw - 24px));grid-template-columns:minmax(0,.85fr) minmax(0,1.15fr);grid-template-areas:"title title" "source source" "levels options" "actions actions";column-gap:16px}}';
const oldMobile='@media(max-width:519px) and (max-height:740px){#freeStartPicker{gap:4px;padding:10px}#freeStartPicker button.free-switch{min-height:36px;padding:6px 66px 6px 12px;font-size:12px}#freeStartPicker #freeStartLevels button{min-height:30px}.free-source-label select{min-height:30px}}';
for(const rule of [oldShort,oldSource,oldAuto,oldMobile]){if(!s.includes(rule))throw Error('Expected modal rule missing');s=s.replace(rule,'');}
s=s.replace('grid-template-areas:"title" "levels" "options" "actions";justify-content:stretch','grid-template-areas:"title" "source" "levels" "options" "actions";grid-template-rows:auto auto auto minmax(0,1fr) auto;justify-content:stretch');
s=s.replace('overflow:visible;text-align:left;background:#f8fafc','overflow:hidden;text-align:left;background:#f8fafc');s=s.replace('#freeStartPicker{grid-template-areas:"title" "source" "levels" "options" "actions"}','');
s+=`\n/* One consistent setup grid; the footer never gets pushed outside the dialog. */
#freeStartPicker .free-start-options{min-height:0;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-gutter:stable;padding:2px;box-sizing:border-box}
#freeStartPicker>.free-source-label{min-width:0;margin:0}
#freeStartPicker .free-start-levels{min-width:0}
#freeStartPicker .free-start-actions{align-self:end;margin:0}
@media(max-height:740px){#freeStartPicker{gap:4px;padding:10px}#freeStartPicker button.free-switch{min-height:38px;padding:7px 66px 7px 12px;font-size:12px}#freeStartPicker #freeStartLevels button{min-height:32px;font-size:13px}#freeStartPicker .free-source-label select{min-height:30px;height:30px}#freeStartPicker .free-start-actions button{min-height:32px}}
@media(max-height:640px){#freeStartPicker button.free-switch{min-height:34px;padding:5px 66px 5px 12px}#freeStartPicker #freeStartLevels button{min-height:28px}#freeStartPicker .free-source-label select{min-height:28px;height:28px}}
@media(min-width:680px) and (max-height:680px){#freeStartPicker{width:min(680px,calc(100vw - 24px));grid-template-columns:minmax(0,1fr) minmax(0,1fr);grid-template-rows:auto auto minmax(0,1fr) auto;grid-template-areas:"title title" "source source" "levels options" "actions actions";column-gap:20px}}
@media(max-height:480px){#freeStartPicker{padding:8px;gap:3px}#freeStartPicker button.free-switch{min-height:32px;padding:4px 66px 4px 12px}#freeStartPicker .free-start-actions button{min-height:28px;padding:3px 8px}}
`;
fs.writeFileSync(file,s);const html=path.join(base,'index.html');s=fs.readFileSync(html,'utf8').replace('assets/css/studio.css?autoplay-1','assets/css/studio.css?free-modal-layout-2');fs.writeFileSync(html,s);
