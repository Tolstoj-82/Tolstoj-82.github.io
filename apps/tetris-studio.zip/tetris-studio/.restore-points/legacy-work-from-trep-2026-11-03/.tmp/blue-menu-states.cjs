const fs=require('fs'),file='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio/studio.css';
let css=fs.readFileSync(file,'utf8');
const changes=[
 ['background:#e5ebdd;border-color:#859677;color:#344c24','background:#dbeafe;border-color:#3b82f6;color:#1e3a8a'],
 ['border-color:#c3caba;background:#e7ebdf','border-color:#bfdbfe;background:#eff6ff'],
 ['border:1px solid #c5ccbf','border:1px solid #cbd5e1'],
 ['background:#536c3e;color:#fff;border-color:#344c24','background:#dbeafe;color:#1e3a8a;border-color:#3b82f6'],
 ['.level-speed-group.shared button[aria-pressed="true"]{background:#536c3e}', '.level-speed-group.shared button[aria-pressed="true"]{background:#dbeafe;color:#1e3a8a}']
];
for(const[a,b]of changes){if(!css.includes(a))throw Error('Missing color rule: '+a);css=css.replaceAll(a,b);}
fs.writeFileSync(file,css);
console.log('Replaced green Course/Settings tab and level-selection colors with blue. No geometry changes.');
