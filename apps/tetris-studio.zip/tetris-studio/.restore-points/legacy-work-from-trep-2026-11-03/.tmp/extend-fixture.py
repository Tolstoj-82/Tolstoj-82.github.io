from pathlib import Path
p=Path('.tmp/verify-native-turns.py')
s=p.read_text()
s=s.replace("rows=[{'pieceId'", "descriptors=[]\nfor i,start in enumerate(starts):\n d=0x2c20+i*4;pattern=start-2;coords=int.from_bytes(r[pattern:pattern+2],'little');oy,ox=r[d+2:d+4];points=[]\n for n,v in enumerate(r[start:start+16]):\n  if v==255:break\n  if v==254:continue\n  cy,cx=r[coords+2*n:coords+2*n+2]\n  sy=((oy+24)&255)+cy+int(oy+24>255)-16\n  sx=((ox+63)&255)+cx+int(ox+63>255)-8\n  assert (sx-16)%8==0 and sy%8==0\n  points.append([(sx-16)//8,sy//8,v])\n descriptors.append({'id':i,'pointer':pattern,'offsetY':oy,'offsetX':ox,'spawnCells':points})\nrows=[{'pieceId'")
s=s.replace("'layouts':layouts,'turns':rows", "'layouts':layouts,'descriptors':descriptors,'turns':rows")
p.write_text(s)
