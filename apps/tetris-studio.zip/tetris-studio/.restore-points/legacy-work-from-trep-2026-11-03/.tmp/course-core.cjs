const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
edit('core.js',s=>{
 const at=s.indexOf('function normalize(raw){');
 const helper=`function lessonPose(a,name,height){
 if(!a||!Object.hasOwn(SHAPES,a.type))throw Error(name+' needs a piece type.');
 const x=integer(a.x,-3,9,name+' x'),y=integer(a.y,0,height-1,name+' y'),rotation=integer(a.rotation??0,0,3,name+' rotation');
 if(cells(a.type,rotation).some(([dx,dy])=>x+dx<0||x+dx>=10||y+dy>=height))throw Error(name+' extends outside the board.');return{type:a.type,x,y,rotation};
}
`;
 s=s.slice(0,at)+helper+s.slice(at);
 s=s.replace('  if(f.animate!==undefined',()=>`  if(f.ghost){frame.ghost=lessonPose(f.ghost,'Ghost',height);frame.ghost.label=String(f.ghost.label||'Default').slice(0,20);}
  if(f.placementHighlights!==undefined){if(!Array.isArray(f.placementHighlights)||f.placementHighlights.length>2)throw Error('Use up to two placement highlights.');frame.placementHighlights=f.placementHighlights.map(a=>lessonPose(a,'Placement',height));}
  for(const key of ['ghostBlink','nextBlink','showNext','placementBlink'])if(f[key]!==undefined){if(typeof f[key]!=='boolean')throw Error('Invalid '+key);frame[key]=f[key];}
  if(f.lessonStage!==undefined)frame.lessonStage=integer(f.lessonStage,1,7,'lesson stage');
  if(f.animate!==undefined`);
 s=s.replace('return {...view,trigger:on?',()=>`return {...view,ghost:!view.ghostBlink||on?view.ghost:undefined,placementHighlights:!view.placementBlink||on?view.placementHighlights:undefined,nextPreviewVisible:!view.nextBlink||on,trigger:on?`);
 s=s.replace("return{version:1,title:raw.title,description:raw.description||'',height,frames};",()=>`const result={version:1,title:raw.title,description:raw.description||'',height,frames};
 if(raw.chapter!==undefined){if(!['Adjustments'].includes(raw.chapter))throw Error('Unknown lesson chapter.');result.chapter=raw.chapter;}
 if(raw.adjustment){const m=raw.adjustment;result.adjustment={default:lessonPose(m.default,'Default position',height),adjusted:lessonPose(m.adjusted,'Adjusted position',height),next:lessonPose(m.next,'Next position',height)};}
 return result;`);
 s=s.replace('const out={title:s.title};',()=>"const out={title:s.title};if(s.chapter)out.chapter=s.chapter;if(s.adjustment)out.adjustment=clone(s.adjustment);");
 s=s.replace('  if(f.buttons.length)',()=>`  for(const key of ['ghost','ghostBlink','nextBlink','showNext','placementHighlights','placementBlink','lessonStage'])if(f[key]!==undefined)result[key]=clone(f[key]);
  if(f.next!=='T')result.next=f.next;
  if(f.animate&&f.animationFrom&&n&&s.frames[n-1].active?.type!==f.active.type)result.animationFrom=clone(f.animationFrom);
  if(f.buttons.length)`);
 // frameAt adds transient fields only when sampling, not to stored frames.
 return s;
});
const C=require(path.join(root,'core.js'));
const stack=['.SS.......','.SSs..sSSS','.SSs..sSSS'];
const first={type:'J',x:4,y:15,rotation:3},second={type:'L',x:3,y:15,rotation:1},def={type:'J',x:4,y:15,rotation:1},spawn={type:'J',x:3,y:0,rotation:0};
const base=C.empty(15).concat(stack.map(r=>[...r.replaceAll('s','L').replaceAll('S','L')]));
const lock1=C.compose({board:base,active:first},18),lock2=C.compose({board:lock1,active:second},18);
const rowDiff=(a,b)=>Object.fromEntries(b.map((r,y)=>[y,r.join('')]).filter(([y,r])=>r!==a[y].join('')));
const both=[first,second],common={next:'L',showNext:true,highlight:false};
const frames=[
 {step:'1',caption:'The adjustment motif: the stack minos the two pieces will wrap around.',ticks:96,motif:true,blink:true,lessonStage:1},
 {step:'2',caption:'Default: the J would normally go here. Keep the falling piece at its spawn while comparing.',ticks:96,active:spawn,ghost:{...def,label:'Default'},ghostBlink:true,blink:true,lessonStage:2},
 {step:'3',caption:'Look ahead: the next piece is L. The default J placement blocks its well.',ticks:96,active:spawn,ghost:{...def,label:'Default'},nextBlink:true,blink:true,lessonStage:3},
 {step:'4',caption:'Adjusted: turn the J the other way to keep the adjacent well open for L.',ticks:96,active:spawn,ghost:{...first,label:'Adjusted'},ghostBlink:true,blink:true,lessonStage:4},
 {step:'5',caption:'Place J in the adjusted position, leaving the neighbouring column open.',ticks:144,active:first,animate:true,fallFirst:4,buttons:['A'],lessonStage:5},
 {step:'6',caption:'Now bring in the next L. Its long side fits the open well beside J.',ticks:30,active:{type:'L',x:3,y:0,rotation:0},rows:rowDiff(base,lock1),showNext:false,lessonStage:6},
 {step:'6a',caption:'Turn L upright and lower it beside J.',ticks:144,active:second,animate:true,fallFirst:4,buttons:['B'],showNext:false,lessonStage:6},
 {step:'7',caption:'The adjusted J and the next L fit together. Compare the pair.',ticks:96,rows:rowDiff(lock1,lock2),placementHighlights:both,placementBlink:true,blink:true,showNext:false,lessonStage:7},
 {step:'7a',caption:'Notice the motif again: both little pillars are capped and enclosed by the two pieces.',ticks:96,motif:true,blink:true,showNext:false,lessonStage:7}
].map(f=>({...common,...f}));
const raw={title:'L-J Koryan Thing',chapter:'Adjustments',description:'Mirrored from the NES reference: J first, L next on Game Boy.',stack,adjustment:{default:def,adjusted:first,next:second},frames};
const key='adjustment-lj-koryan';fs.writeFileSync(path.join(root,'situations',key+'.js'),'// NES reference mirrored horizontally: NES L/J become Game Boy J/L.\n(function(root){\nconst situation = '+JSON.stringify(raw,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
edit('situations.js',s=>s.replace('"jd-spin-right"\n','"jd-spin-right",\n  "adjustment-lj-koryan"\n'));
