from pathlib import Path
import re

css = Path('../tetris-studio/studio.css').read_text(encoding='utf-8')
css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)
css = re.sub(r'"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27', '', css)
depth = 0
for char in css:
    depth += (char == '{') - (char == '}')
    assert depth >= 0
assert depth == 0
for width, height in [(1000, 600), (1280, 720), (1366, 768), (1440, 900), (1920, 1080)]:
    board = max(144, min(288, (height - 280) / 2.03))
    hardware = board * (1.5 + 128 / 242)
    assert hardware + 260 <= height
    assert board + 232 + 24 <= width - 320 - 40
    print(f'{width}x{height}: {round(board)}px board; stage fits width and height budget')
print('CSS blocks balanced')
