const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const side of ['left','right']){
 const left=side==='left',x=left?1:6,y=15,rotation=left?3:1,after=left?2:0;
 const s=structuredClone(require(path.join(root,'situations/j-spin-well.js')));s.title='L-Spin (optimal, '+side+')';s.piece='L';
 const rows=left?['SS..SSSSSS','SS..SSSSSS','s$..SSSSSS','$...SSSSSS','$...SSSSSS']:['SSSSSS..SS','SSSSSS..s$','SSSSSS...s','SSSSSS...$','SSSSSS..s$'];
 const board=Array.from({length:18},()=>Array(10).fill('.'));rows.forEach((r,i)=>board[i+13]=[...r]);
 for(const r of [rotation,after])for(const[dx,dy]of C.cells('L',r)){if(board[y+dy][x+dx]!=='.'&&board[y+dy][x+dx]!==',')throw Error('overlap');board[y+dy][x+dx]=',';}
 s.stack=board.slice(13).map(r=>r.join(''));
 for(const f of s.frames.slice(0,3)){f.active={x:3,y:0};f.caption=f.caption.replaceAll('J piece','L piece').replaceAll('upright J','upright L');}
 for(const f of s.frames.slice(3,7))f.active={x,y,rotation};
 s.frames[3].buttons=[left?'A':'B'];s.frames[3].caption='2 · Turn the L upright, move into the channel, then descend to the pocket.';
 s.frames[4].trigger={hole:[left?1:8,16],button:'A'};s.frames[4].caption='3 · Align the pivot with the adjacent empty square on its '+(left?'left.':'right.');
 s.frames[5].buttons=['A'];s.frames[5].caption='4 · Press A to rotate the L counterclockwise into the pocket.';
 s.frames[6].active.rotation=after;s.frames[6].caption='5 · The L fits under the overhang and completes the row.';
 const key='l-spin-optimal-'+side;fs.writeFileSync(path.join(root,'situations',key+'.js'),'// Optimal L-spin reconstructed from the supplied reference.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"j-spin-suboptimal-center"\n','"j-spin-suboptimal-center",\n  "l-spin-optimal-left",\n  "l-spin-optimal-right"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/l-spin-optimal-left.js"></script><script src="situations/l-spin-optimal-right.js"></script><script src="situations.js">'));
edit('app.js',s=>s.replace("j:'J-Spins',jd:","j:'J-Spins',l:'L-Spins',jd:"));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'16'","libraryCount.textContent,'18'").replace('h.cards().length,15','h.cards().length,17').replace("'I-Spins','J-Spins']","'I-Spins','J-Spins','L-Spins']").replace('[2,1,2,2,5,4]','[2,1,2,2,5,4,2]'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,16','C.parseCollection(demo).length,18')+`
test('optimal L-spins descend safely and rotate with A into one-row clears',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('L-Spin'));assert.equal(variants.length,2);
 for(const[i,s]of variants.entries()){
  assert.deepEqual(s.frames.map(f=>f.step),['1','1a','1b','2','3','4','5','6']);
  const f=s.frames[3],stack=C.compose({...f,active:undefined},18);
  for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells(a.type,a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}
  assert.deepEqual(s.frames[5].buttons,['A']);assert.equal(s.frames[6].active.rotation,i===0?2:0);assert.deepEqual(s.frames[7].clearRows,[16]);assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
