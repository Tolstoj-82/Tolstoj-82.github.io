const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
edit('index.html',s=>s.replace('<div class="study-heading">','<button id="openStackEditor" class="stack-editor-toggle">Edit stack</button><div class="study-heading">').replace('<p id="status"',`<section id="stackEditor" class="stack-editor panel" hidden aria-label="Stack editor">
<div class="stack-editor-heading"><h2 id="stackEditorTitle">Edit stack</h2><button id="closeStackEditor">Close</button></div>
<p>Paint cells or edit the rows. Download the updated file and replace its matching file in situations/. Changes are not saved in this browser.</p>
<label>Paint <select id="stackBrush"><option value="S">Stack (S)</option><option value="s">Motif (s)</option><option value="$">Mandatory motif ($)</option><option value=",">Counter-motif (,)</option><option value=".">Empty (.)</option><option value="I">I mino</option><option value="O">O mino</option><option value="T">T mino</option><option value="Z">Z mino</option><option value="J">J mino</option><option value="L">L mino</option></select></label>
<div class="stack-editor-layout"><div id="stackPaintGrid" class="stack-paint-grid" aria-label="Editable stack grid"></div><label>Stack rows (10 cells per row)<textarea id="stackRows" rows="18" spellcheck="false" aria-label="Stack rows"></textarea></label></div>
<p id="stackEditorError" role="status"></p><button id="downloadStack">Download situation file</button><button id="resetStack">Reset stack</button>
</section><p id="status"`));
edit('studio.css',s=>s+`
.stack-editor-toggle { float: right; margin: 0 0 8px 8px; }
.stack-editor { margin-top: 24px; border: 1px solid #cbd5e1; border-radius: 6px; padding: 16px; max-width: 650px; }
.stack-editor-heading { display: flex; justify-content: space-between; align-items: center; gap: 12px; }
.stack-editor h2 { margin: 0; font-size: 18px; }
.stack-editor p { font-size: 13px; line-height: 1.5; }
.stack-editor-layout { display: flex; align-items: flex-start; gap: 24px; margin: 12px 0; flex-wrap: wrap; }
.stack-paint-grid { display: grid; grid-template-columns: repeat(10,22px); gap: 1px; background: #536c3e; border: 2px solid #26351e; touch-action: none; }
.stack-paint-grid button { width: 22px; height: 22px; padding: 0; border: 0; border-radius: 0; font: 11px monospace; box-shadow: none; color: #26351e; background: #a6b779; }
.stack-paint-grid button[data-kind="stack"] { background: #536c3e; color: #fff; }
.stack-paint-grid button[data-kind="motif"] { background: #e7a52b; }
.stack-paint-grid button[data-kind="mandatory"] { background: #fff39a; }
.stack-paint-grid button[data-kind="counter"] { background: #b79bd5; }
#stackRows { width: 160px; font: 15px/1.45 monospace; white-space: pre; }
#stackEditorError { color: #9b243a; min-height: 20px; }
`);
edit('app.js',s=>s.replace("card.onclick=()=>{closeSituationMenu();", "card.onclick=()=>{$('stackEditor').hidden=true;closeSituationMenu();")+`
// Edit an explicit copy of the selected file; browser storage is never used.
let stackEditSource=null,stackEditKey='',stackEditRows=[];
function stackCandidate(){
 const raw=C.clone(stackEditSource),rows=stackEditRows.map(r=>r.join(''));while(rows.length&&/^\\.{10}$/.test(rows[0]))rows.shift();raw.stack=rows;return raw;
}
function validateStackEdit(){
 try{C.normalize(stackCandidate());$('stackEditorError').textContent='';$('downloadStack').disabled=false;return true;}
 catch(error){$('stackEditorError').textContent=error.message;$('downloadStack').disabled=true;return false;}
}
function renderStackGrid(){
 const grid=$('stackPaintGrid');grid.replaceChildren();
 stackEditRows.forEach((row,y)=>row.forEach((cell,x)=>{
  const b=document.createElement('button');b.type='button';b.textContent=cell==='.'?'':cell;b.dataset.kind=cell==='$'?'mandatory':cell===','?'counter':/[a-z]/.test(cell)?'motif':cell==='.'?'empty':'stack';b.setAttribute('aria-label','Row '+(y+1)+', column '+(x+1)+': '+cell);
  const paint=erase=>{stackEditRows[y][x]=erase?'.':($('stackBrush').value||'S');$('stackRows').value=stackEditRows.map(r=>r.join('')).join('\\n');renderStackGrid();validateStackEdit();};
  b.onclick=()=>paint(false);b.oncontextmenu=e=>{e.preventDefault();paint(true);};grid.append(b);
 }));
}
function openStackEditor(){
 stop();stackEditKey=situationKey(studies[selected]);const raw=globalThis.TetrisSituationFiles?.[stackEditKey];
 if(!raw){notice('No source situation file available.');return;}
 stackEditSource=C.clone(raw);const height=raw.height||18;stackEditRows=Array.from({length:height-(raw.stack||[]).length},()=>Array(10).fill('.')).concat((raw.stack||[]).map(r=>[...r]));
 $('stackEditorTitle').textContent='Edit stack · '+raw.title;$('stackEditor').hidden=false;$('stackBrush').value='S';$('stackRows').value=stackEditRows.map(r=>r.join('')).join('\\n');renderStackGrid();validateStackEdit();
}
$('openStackEditor').onclick=openStackEditor;$('resetStack').onclick=openStackEditor;$('closeStackEditor').onclick=()=>{$('stackEditor').hidden=true;};
$('stackRows').oninput=()=>{
 const rows=$('stackRows').value.replace(/\\r/g,'').split('\\n');
 if(rows.length>(stackEditSource.height||18)||rows.some(r=>r.length!==10)){$('stackEditorError').textContent='Use up to '+(stackEditSource.height||18)+' rows, each exactly 10 cells.';$('downloadStack').disabled=true;return;}
 stackEditRows=Array.from({length:(stackEditSource.height||18)-rows.length},()=>Array(10).fill('.')).concat(rows.map(r=>[...r]));renderStackGrid();validateStackEdit();
};
$('downloadStack').onclick=()=>{
 if(!validateStackEdit())return;
 const raw=stackCandidate(),source='(function(root){\\nconst situation = '+JSON.stringify(raw,null,2)+';\\nif(typeof module!=="undefined")module.exports=situation;\\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(stackEditKey)+']=situation;\\n})(globalThis);\\n';
 const url=URL.createObjectURL(new Blob([source],{type:'text/javascript'})),a=document.createElement('a');a.href=url;a.download=stackEditKey+'.js';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
};
`);
