const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const side of ['left','right']){
 const left=side==='left',x=left?3:4,tx=left?2:5,dir=left?'Left':'Right',final=left?1:3,button=left?'A':'B',spawn={x:3,y:0};
 const rows=['sss.......','ss........','sss.SSSSSS'].map(r=>left?r:[...r].reverse().join('')),b=rows.map(r=>[...r]);
 for(const a of [{x,y:15,rotation:2},{x:tx,y:15,rotation:2},{x:tx,y:15,rotation:final}])for(const[dx,dy]of C.cells('T',a.rotation)){if(!['.',','].includes(b[a.y+dy-15][a.x+dx]))throw Error('overlap');b[a.y+dy-15][a.x+dx]=',';}
 const s={title:'JD spin ('+side+')',piece:'T',stack:b.map(r=>r.join('')),frames:[
 {step:'1',caption:'1 · The T starts with its spike pointing down.',ticks:96,active:spawn,highlight:'blink',blink:true,reveal:'piece'},
 {step:'1a',caption:'1a · The stack wraps around the vertical T-shaped pocket.',ticks:96,active:spawn,motif:true,highlight:false,blink:true,reveal:'match'},
 {step:'1b',caption:'1b · Leave room beside the pocket to tuck before the final rotation.',ticks:96,active:spawn,counterMotif:true,highlight:false,blink:true,reveal:'counter'},
 {step:'2a',caption:'2a · Press B for the first quarter turn.',ticks:36,active:{...spawn,rotation:1},buttons:['B']},
 {step:'2b',caption:'2b · Press B again. The spike now points up.',ticks:36,active:{...spawn,rotation:2},buttons:['B']},
 {step:'2',caption:'2 · Descend beside the pocket with the spike pointing up.',ticks:144,active:{x,y:15,rotation:2},animate:true,fallFirst:4,buttons:[],reveal:'rotation'},
 {step:'3',caption:'3 · Align the pivot with the empty square toward the pocket.',ticks:96,active:{x,y:15,rotation:2},trigger:{hole:[left?3:6,16],button},blink:true,reveal:'trigger'},
 {step:'3a',caption:'3a · Press '+dir.toLowerCase()+' once to tuck into the pocket before rotating.',ticks:48,active:{x:tx,y:15,rotation:2},buttons:[dir],animate:true},
 {step:'4',caption:'4 · Press '+button+' to rotate the tucked T into the vertical pocket.',ticks:45,active:{x:tx,y:15,rotation:2},buttons:[button],reveal:'input'},
 {step:'5',caption:'5 · The T fits neatly into the pocket.',ticks:70,active:{x:tx,y:15,rotation:final},reveal:'spin'},
 {step:'6',caption:'6 · The completed bottom row clears.',clear:true}
 ]};
 const key='jd-spin-'+side;fs.writeFileSync(path.join(root,'situations',key+'.js'),'(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"z-spuck-center"\n','"z-spuck-center",\n  "jd-spin-left",\n  "jd-spin-right"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/jd-spin-left.js"></script><script src="situations/jd-spin-right.js"></script><script src="situations.js">'));
edit('app.js',s=>s.replace("const isSpuck=situationKey(s).includes('-spuck-')","const isSpuck=situationKey(s).includes('-spuck-')||situationKey(s).startsWith('jd-spin-')").replace("label=isSpuck?(situationKey(s).split('-')[0].toUpperCase()+'-Spucks'):","label=situationKey(s).startsWith('jd-spin-')?'JD spins':isSpuck?(situationKey(s).split('-')[0].toUpperCase()+'-Spucks'):").replace("if(t===turnAt){a.rotation=target.rotation;buttons=approach.buttons;}","if(situationKey(s).startsWith('jd-spin-')&&t===18){a.rotation=1;buttons=['B'];}\n    if(t===turnAt){a.rotation=target.rotation;buttons=situationKey(s).startsWith('jd-spin-')?['B']:approach.buttons;}").replace("situationKey(s).includes('-spuck-')))","(situationKey(s).includes('-spuck-')||situationKey(s).startsWith('jd-spin-'))))"));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'27'","libraryCount.textContent,'29'").replace('h.cards().length,26','h.cards().length,28').replace('categories[1].children.length,4','categories[1].children.length,5'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,27','C.parseCollection(demo).length,29')+`
test('JD spins turn twice, tuck before their final rotation and fit both mirrored pockets',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('JD spin'));assert.equal(variants.length,2);
 for(const[i,s]of variants.entries()){
  assert.equal(s.frames[3].active.rotation,1);assert.equal(s.frames[4].active.rotation,2);assert.deepEqual(s.frames[3].buttons,['B']);assert.deepEqual(s.frames[4].buttons,['B']);assert.deepEqual(s.frames[7].buttons,[i===0?'Left':'Right']);assert.deepEqual(s.frames[8].buttons,[i===0?'A':'B']);assert.deepEqual(s.frames[10].clearRows,[17]);
  for(const f of s.frames.filter(f=>f.animate)){const stack=C.compose({...f,active:undefined},18);for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells('T',a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}}
  assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
