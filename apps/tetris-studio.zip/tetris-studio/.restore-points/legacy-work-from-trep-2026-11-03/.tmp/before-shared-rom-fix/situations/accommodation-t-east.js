// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "T · East",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SSs.SSSSS",
    ".SSSsSSSSS"
  ],
  "accommodation": {
    "orientation": 1,
    "target": {
      "type": "T",
      "x": 3,
      "y": 14,
      "rotation": 1
    },
    "surface": [
      [
        3,
        16
      ],
      [
        4,
        17
      ]
    ],
    "heights": [
      1,
      0
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "14": "....T.....",
        "15": "...TT.....",
        "16": ".LLLTLLLLL"
      },
      "placementHighlights": [
        {
          "type": "T",
          "x": 3,
          "y": 14,
          "rotation": 1
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "14": "..........",
        "15": "..........",
        "16": ".LLL.LLLLL"
      },
      "active": {
        "type": "T",
        "x": 3,
        "y": 0,
        "rotation": 1
      },
      "highlight": false,
      "showNext": false,
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 112,
      "active": {
        "type": "T",
        "x": 3,
        "y": 14,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 14,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-t-east"]=situation;
})(globalThis);
