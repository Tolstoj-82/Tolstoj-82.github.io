// Optimal L-spin reconstructed from the supplied reference.
(function(root){
const situation = {
  "title": "L-Spin (optimal, left)",
  "stack": [
    "SS..SSSSSS",
    "SS..SSSSSS",
    "s$,,SSSSSS",
    "$,,,SSSSSS",
    "$.,,SSSSSS"
  ],
  "piece": "L",
  "frames": [
    {
      "step": "1",
      "caption": "1 · The L piece in its starting orientation.",
      "ticks": 96,
      "active": {
        "x": 3,
        "y": 0
      },
      "highlight": "blink",
      "blink": true,
      "reveal": "piece"
    },
    {
      "step": "1a",
      "caption": "1a · The supporting stack around the slot. Brighter cells mark the provisional required corners.",
      "ticks": 144,
      "active": {
        "x": 3,
        "y": 0
      },
      "motif": true,
      "highlight": false,
      "blink": true,
      "reveal": "match",
      "mandatoryAfter": 48
    },
    {
      "step": "1b",
      "caption": "1b · The empty pocket is the counter-motif: room for the upright L and the turn beneath the overhang.",
      "ticks": 96,
      "active": {
        "x": 3,
        "y": 0
      },
      "counterMotif": true,
      "highlight": false,
      "blink": true,
      "reveal": "counter"
    },
    {
      "step": "2",
      "caption": "2 · Turn the L upright, move into the channel, then descend to the pocket.",
      "ticks": 144,
      "active": {
        "x": 1,
        "y": 15,
        "rotation": 3
      },
      "buttons": [
        "A"
      ],
      "animate": true,
      "fallFirst": 4,
      "reveal": "rotation"
    },
    {
      "step": "3",
      "caption": "3 · Align the pivot with the adjacent empty square on its left.",
      "ticks": 120,
      "active": {
        "x": 1,
        "y": 15,
        "rotation": 3
      },
      "trigger": {
        "hole": [
          1,
          16
        ],
        "button": "B"
      },
      "blink": true,
      "reveal": "trigger"
    },
    {
      "step": "4",
      "caption": "4 · Press B to rotate the L clockwise into the pocket.",
      "ticks": 120,
      "active": {
        "x": 1,
        "y": 15,
        "rotation": 3
      },
      "buttons": [
        "B"
      ],
      "reveal": "input",
      "blink": true
    },
    {
      "step": "5",
      "caption": "5 · The L fits under the overhang and completes the row.",
      "ticks": 90,
      "active": {
        "x": 1,
        "y": 15,
        "rotation": 0
      },
      "reveal": "spin"
    },
    {
      "step": "6",
      "caption": "6 · The completed row clears.",
      "clear": true
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["l-spin-optimal-left"]=situation;
})(globalThis);
