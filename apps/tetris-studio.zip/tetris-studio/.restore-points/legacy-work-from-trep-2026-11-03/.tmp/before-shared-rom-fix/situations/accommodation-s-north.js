// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "S · North",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SS..sSSSS",
    ".SSssSSSSS"
  ],
  "accommodation": {
    "orientation": 0,
    "target": {
      "type": "S",
      "x": 3,
      "y": 14,
      "rotation": 0
    },
    "surface": [
      [
        3,
        17
      ],
      [
        4,
        17
      ],
      [
        5,
        16
      ]
    ],
    "heights": [
      0,
      0,
      1
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "15": "....SS....",
        "16": ".LLSSLLLLL"
      },
      "placementHighlights": [
        {
          "type": "S",
          "x": 3,
          "y": 14,
          "rotation": 0
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "15": "..........",
        "16": ".LL..LLLLL"
      },
      "active": {
        "type": "S",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "highlight": false,
      "showNext": false,
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 112,
      "active": {
        "type": "S",
        "x": 3,
        "y": 14,
        "rotation": 0
      },
      "animate": true,
      "fallFirst": 14,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-s-north"]=situation;
})(globalThis);
