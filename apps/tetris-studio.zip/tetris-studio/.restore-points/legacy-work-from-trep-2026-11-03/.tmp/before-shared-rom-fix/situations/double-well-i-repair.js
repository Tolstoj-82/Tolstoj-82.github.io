// Double-well example from the supplied Game Boy reference.
(function(root){const situation={
  "title": "I · Restore the Tetris well",
  "chapter": "Save stacking",
  "section": "Double-Well",
  "description": "The I fills column 2 rather than skimming immediately. This repairs the two-wide opening into a one-wide Tetris well. A later I can clear the four prepared bottom rows.",
  "stack": [
    "........SS",
    ".......SSS",
    ".......SSS",
    ".......SSS",
    "....SSSSSS",
    "..SSSSSSSS",
    "..SSSSSSSS",
    "..SSSSSSSS",
    ".SSSSSSSSS",
    ".SSSSSSSSS",
    ".SSSSSSSSS",
    ".SSSSSSSSS"
  ],
  "doubleWell": {
    "role": "repair",
    "target": {
      "type": "I",
      "rotation": 1,
      "x": 0,
      "y": 10
    },
    "clears": 0,
    "note": "The I fills column 2 rather than skimming immediately. This repairs the two-wide opening into a one-wide Tetris well. A later I can clear the four prepared bottom rows.",
    "key": "double-well-i-repair"
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "motif": {
        "space": true,
        "cells": [
          [
            0,
            11
          ],
          [
            1,
            11
          ],
          [
            0,
            12
          ],
          [
            1,
            12
          ],
          [
            0,
            13
          ],
          [
            1,
            13
          ]
        ],
        "color": "#6d94c4"
      },
      "highlight": false,
      "showNext": false,
      "caption": "The two-column entrance sits above the one-column Tetris well."
    },
    {
      "step": "2",
      "ticks": 48,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "showNext": false,
      "caption": "The current piece is I. Choose its orientation before the descent."
    },
    {
      "step": "3",
      "ticks": 36,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 1
      },
      "animate": true,
      "buttons": [
        "A"
      ],
      "showNext": false,
      "caption": "Orient the piece using the original Game Boy rotation buttons."
    },
    {
      "step": "4",
      "ticks": 60,
      "active": {
        "type": "I",
        "rotation": 1,
        "x": 0,
        "y": 0
      },
      "animate": true,
      "buttons": [
        "Left"
      ],
      "showNext": false,
      "caption": "Move over the left-hand double well."
    },
    {
      "step": "5",
      "ticks": 132,
      "active": {
        "type": "I",
        "rotation": 1,
        "x": 0,
        "y": 10
      },
      "animate": true,
      "showNext": false,
      "caption": "The I fills column 2 rather than skimming immediately. This repairs the two-wide opening into a one-wide Tetris well. A later I can clear the four prepared bottom rows."
    },
    {
      "step": "6",
      "ticks": 96,
      "rows": {
        "10": ".I..LLLLLL",
        "11": ".ILLLLLLLL",
        "12": ".ILLLLLLLL",
        "13": ".ILLLLLLLL"
      },
      "tileOverrides": [
        {
          "x": 1,
          "y": 10,
          "tile": 128
        },
        {
          "x": 1,
          "y": 11,
          "tile": 136
        },
        {
          "x": 1,
          "y": 12,
          "tile": 136
        },
        {
          "x": 1,
          "y": 13,
          "tile": 137
        }
      ],
      "highlight": false,
      "showNext": false,
      "caption": "No line clear yet: column 2 is repaired and the original Tetris well stays open."
    },
    {
      "step": "7",
      "ticks": 144,
      "highlight": false,
      "showNext": false,
      "caption": "The lower four rows are now Tetris-ready. This is the I-piece special case."
    }
  ]
};if(typeof module!=="undefined")module.exports=situation;else(root.TetrisSituationFiles??={})["double-well-i-repair"]=situation;})(globalThis);
