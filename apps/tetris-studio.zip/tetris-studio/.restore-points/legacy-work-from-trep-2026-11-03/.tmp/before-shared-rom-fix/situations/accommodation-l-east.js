// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "L · East",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SSs.SSSSS",
    ".SSS.SSSSS",
    ".SSSsSSSSS"
  ],
  "accommodation": {
    "orientation": 1,
    "target": {
      "type": "L",
      "x": 3,
      "y": 14,
      "rotation": 1
    },
    "surface": [
      [
        3,
        15
      ],
      [
        4,
        17
      ]
    ],
    "heights": [
      2,
      0
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "14": "...LL.....",
        "15": ".LLLLLLLLL",
        "16": ".LLLLLLLLL"
      },
      "placementHighlights": [
        {
          "type": "L",
          "x": 3,
          "y": 14,
          "rotation": 1
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "14": "..........",
        "15": ".LLL.LLLLL",
        "16": ".LLL.LLLLL"
      },
      "active": {
        "type": "L",
        "x": 3,
        "y": 0,
        "rotation": 1
      },
      "highlight": false,
      "showNext": false,
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 112,
      "active": {
        "type": "L",
        "x": 3,
        "y": 14,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 14,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-l-east"]=situation;
})(globalThis);
