// Mirrored Game Boy lesson with verified inputs.
(function(root){
const situation = {
  "title": "Pump Fake Passer Upper",
  "chapter": "Adjustments",
  "description": "Move I to the outside of the double well, leaving the hook-shaped landing for L rather than filling it with the bar.",
  "stack": [
    "........sS",
    ".SSSs...sS",
    ".SSSS...sS",
    ".SSSS...sS",
    ".SSSSSssSS",
    ".SSSSSSSSS"
  ],
  "adjustment": {
    "default": {
      "type": "I",
      "x": 4,
      "y": 12,
      "rotation": 1
    },
    "adjusted": {
      "type": "I",
      "x": 6,
      "y": 12,
      "rotation": 1
    },
    "next": {
      "type": "L",
      "x": 5,
      "y": 13,
      "rotation": 1
    }
  },
  "frames": [
    {
      "step": "1",
      "lessonStage": 1,
      "caption": "Notice the stack motif around the two landing positions.",
      "ticks": 96,
      "next": "L",
      "showNext": true,
      "highlight": false,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "motif": true,
      "blink": true
    },
    {
      "step": "2",
      "lessonStage": 2,
      "caption": "Default: this is the usual landing without the next-piece adjustment.",
      "ticks": 96,
      "next": "L",
      "showNext": true,
      "highlight": false,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "ghost": {
        "type": "I",
        "x": 4,
        "y": 12,
        "rotation": 1,
        "label": "Default"
      },
      "ghostBlink": true,
      "blink": true
    },
    {
      "step": "3",
      "lessonStage": 3,
      "caption": "Look ahead: L is next.",
      "ticks": 96,
      "next": "L",
      "showNext": true,
      "highlight": false,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "ghost": {
        "type": "I",
        "x": 4,
        "y": 12,
        "rotation": 1,
        "label": "Default"
      },
      "nextBlink": true,
      "blink": true
    },
    {
      "step": "4",
      "lessonStage": 4,
      "caption": "Move I to the outside of the double well, leaving the hook-shaped landing for L rather than filling it with the bar.",
      "ticks": 96,
      "next": "L",
      "showNext": true,
      "highlight": false,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "ghost": {
        "type": "I",
        "x": 6,
        "y": 12,
        "rotation": 1,
        "label": "Adjusted"
      },
      "ghostBlink": true,
      "blink": true
    },
    {
      "step": "4a",
      "lessonStage": 4,
      "caption": "Next: L fits beside the adjusted I.",
      "ticks": 96,
      "next": "L",
      "showNext": true,
      "highlight": false,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "referenceGhost": {
        "type": "I",
        "x": 6,
        "y": 12,
        "rotation": 1,
        "label": "Adjusted"
      },
      "ghost": {
        "type": "L",
        "x": 5,
        "y": 13,
        "rotation": 1,
        "label": "Next"
      },
      "ghostBlink": true,
      "blink": true
    },
    {
      "step": "5",
      "lessonStage": 5,
      "ticks": 2,
      "next": "L",
      "showNext": true,
      "highlight": false,
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "rows": {},
      "caption": "Bring in I."
    },
    {
      "step": "5a",
      "lessonStage": 5,
      "active": {
        "type": "I",
        "x": 6,
        "y": 0,
        "rotation": 0
      },
      "animationFrom": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "animate": true,
      "ticks": 24,
      "highlight": false,
      "next": "L",
      "showNext": true,
      "buttons": [
        "Right"
      ],
      "caption": "Press right to move I into place."
    },
    {
      "step": "5b",
      "lessonStage": 5,
      "active": {
        "type": "I",
        "x": 6,
        "y": 0,
        "rotation": 3
      },
      "animationFrom": {
        "type": "I",
        "x": 6,
        "y": 0,
        "rotation": 0
      },
      "animate": true,
      "ticks": 24,
      "highlight": false,
      "next": "L",
      "showNext": true,
      "buttons": [
        "A"
      ],
      "caption": "Press A to rotate I."
    },
    {
      "step": "5c",
      "lessonStage": 5,
      "active": {
        "type": "I",
        "x": 6,
        "y": 12,
        "rotation": 3
      },
      "animationFrom": {
        "type": "I",
        "x": 6,
        "y": 0,
        "rotation": 3
      },
      "animate": true,
      "ticks": 72,
      "highlight": false,
      "next": "L",
      "showNext": true,
      "buttons": [],
      "caption": "Let gravity lower I."
    },
    {
      "step": "6",
      "lessonStage": 6,
      "ticks": 2,
      "next": "L",
      "showNext": false,
      "highlight": false,
      "active": {
        "type": "L",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "rows": {
        "12": ".......ILL",
        "13": ".LLLL..ILL",
        "14": ".LLLL..ILL",
        "15": ".LLLL..ILL"
      },
      "caption": "Bring in L.",
      "tileOverrides": [
        {
          "x": 7,
          "y": 12,
          "tile": 128
        },
        {
          "x": 7,
          "y": 13,
          "tile": 136
        },
        {
          "x": 7,
          "y": 14,
          "tile": 136
        },
        {
          "x": 7,
          "y": 15,
          "tile": 137
        }
      ]
    },
    {
      "step": "6a",
      "lessonStage": 6,
      "active": {
        "type": "L",
        "x": 5,
        "y": 0,
        "rotation": 0
      },
      "animationFrom": {
        "type": "L",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "animate": true,
      "ticks": 24,
      "highlight": false,
      "next": "L",
      "showNext": false,
      "buttons": [
        "Right"
      ],
      "caption": "Press right to move L into place.",
      "tileOverrides": [
        {
          "x": 7,
          "y": 12,
          "tile": 128
        },
        {
          "x": 7,
          "y": 13,
          "tile": 136
        },
        {
          "x": 7,
          "y": 14,
          "tile": 136
        },
        {
          "x": 7,
          "y": 15,
          "tile": 137
        }
      ]
    },
    {
      "step": "6b",
      "lessonStage": 6,
      "active": {
        "type": "L",
        "x": 5,
        "y": 0,
        "rotation": 1
      },
      "animationFrom": {
        "type": "L",
        "x": 5,
        "y": 0,
        "rotation": 0
      },
      "animate": true,
      "ticks": 24,
      "highlight": false,
      "next": "L",
      "showNext": false,
      "buttons": [
        "B"
      ],
      "caption": "Press B to rotate L.",
      "tileOverrides": [
        {
          "x": 7,
          "y": 12,
          "tile": 128
        },
        {
          "x": 7,
          "y": 13,
          "tile": 136
        },
        {
          "x": 7,
          "y": 14,
          "tile": 136
        },
        {
          "x": 7,
          "y": 15,
          "tile": 137
        }
      ]
    },
    {
      "step": "6c",
      "lessonStage": 6,
      "active": {
        "type": "L",
        "x": 5,
        "y": 13,
        "rotation": 1
      },
      "animationFrom": {
        "type": "L",
        "x": 5,
        "y": 0,
        "rotation": 1
      },
      "animate": true,
      "ticks": 78,
      "highlight": false,
      "next": "L",
      "showNext": false,
      "buttons": [],
      "caption": "Let gravity lower L.",
      "tileOverrides": [
        {
          "x": 7,
          "y": 12,
          "tile": 128
        },
        {
          "x": 7,
          "y": 13,
          "tile": 136
        },
        {
          "x": 7,
          "y": 14,
          "tile": 136
        },
        {
          "x": 7,
          "y": 15,
          "tile": 137
        }
      ]
    },
    {
      "step": "7",
      "lessonStage": 7,
      "ticks": 96,
      "rows": {
        "12": ".......ILL",
        "13": ".LLLLLLILL",
        "14": ".LLLL.LILL",
        "15": ".LLLL.LILL"
      },
      "highlight": false,
      "placementHighlights": [
        {
          "type": "I",
          "x": 6,
          "y": 12,
          "rotation": 1
        },
        {
          "type": "L",
          "x": 5,
          "y": 13,
          "rotation": 1
        }
      ],
      "caption": "Notice the resulting stack.",
      "tileOverrides": [
        {
          "x": 7,
          "y": 12,
          "tile": 128
        },
        {
          "x": 7,
          "y": 13,
          "tile": 136
        },
        {
          "x": 7,
          "y": 14,
          "tile": 136
        },
        {
          "x": 7,
          "y": 15,
          "tile": 137
        }
      ],
      "placementBlink": true
    },
    {
      "step": "7a",
      "lessonStage": 7,
      "ticks": 96,
      "motif": {
        "cells": [
          [
            8,
            12
          ],
          [
            4,
            13
          ],
          [
            8,
            13
          ],
          [
            8,
            14
          ],
          [
            8,
            15
          ],
          [
            6,
            16
          ],
          [
            7,
            16
          ]
        ],
        "color": "#e7a52b"
      },
      "blink": true,
      "caption": "Notice the motif around the completed pair."
    }
  ],
  "motionVerified": true
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["adjustment-pump-fake"]=situation;
})(globalThis);
