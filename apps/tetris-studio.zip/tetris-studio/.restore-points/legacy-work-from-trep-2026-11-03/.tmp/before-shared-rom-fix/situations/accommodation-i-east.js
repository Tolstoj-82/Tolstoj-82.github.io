// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "I · East",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SSS.SSSSS",
    ".SSSsSSSSS"
  ],
  "accommodation": {
    "orientation": 1,
    "target": {
      "type": "I",
      "x": 3,
      "y": 13,
      "rotation": 1
    },
    "surface": [
      [
        4,
        17
      ]
    ],
    "heights": [
      0
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "13": "....I.....",
        "14": "....I.....",
        "15": "....I.....",
        "16": ".LLLILLLLL"
      },
      "placementHighlights": [
        {
          "type": "I",
          "x": 3,
          "y": 13,
          "rotation": 1
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "tileOverrides": [
        {
          "x": 4,
          "y": 13,
          "tile": 128
        },
        {
          "x": 4,
          "y": 14,
          "tile": 136
        },
        {
          "x": 4,
          "y": 15,
          "tile": 136
        },
        {
          "x": 4,
          "y": 16,
          "tile": 137
        }
      ],
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "13": "..........",
        "14": "..........",
        "15": "..........",
        "16": ".LLL.LLLLL"
      },
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 1
      },
      "highlight": false,
      "showNext": false,
      "tileOverrides": [],
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 104,
      "active": {
        "type": "I",
        "x": 3,
        "y": 13,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 13,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-i-east"]=situation;
})(globalThis);
