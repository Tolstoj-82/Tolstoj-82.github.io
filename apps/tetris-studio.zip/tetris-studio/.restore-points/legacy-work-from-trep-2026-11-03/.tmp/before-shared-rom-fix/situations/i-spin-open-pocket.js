// I-spin variation reconstructed from the supplied reference.
(function(root){
const situation = {
  "title": "I-Spin (open pocket)",
  "stack": [
    "SSSs,.SSSS",
    "SSS$,.$SSS",
    "SSs,,,,sSS",
    "SSS$,...SS",
    "SSSS.SSSSS"
  ],
  "piece": "I",
  "frames": [
    {
      "step": "1",
      "caption": "1 · The I piece in its starting orientation.",
      "ticks": 96,
      "active": {
        "x": 3,
        "y": 0
      },
      "highlight": "blink",
      "blink": true,
      "reveal": "piece"
    },
    {
      "step": "1a",
      "caption": "1a · The supporting stack around the slot. Brighter cells mark the provisional required corners.",
      "ticks": 144,
      "active": {
        "x": 3,
        "y": 0
      },
      "motif": true,
      "highlight": false,
      "blink": true,
      "reveal": "match",
      "mandatoryAfter": 48
    },
    {
      "step": "1b",
      "caption": "1b · The empty cross-shaped space is the counter-motif: room for the upright I and its horizontal turn.",
      "ticks": 96,
      "active": {
        "x": 3,
        "y": 0
      },
      "counterMotif": true,
      "highlight": false,
      "blink": true,
      "reveal": "counter"
    },
    {
      "step": "2",
      "caption": "2 · Turn the I upright, line up with the channel, then descend to the horizontal slot.",
      "ticks": 144,
      "active": {
        "x": 3,
        "y": 13,
        "rotation": 1
      },
      "buttons": [
        "B"
      ],
      "animate": true,
      "fallFirst": 4,
      "reveal": "rotation"
    },
    {
      "step": "3",
      "caption": "3 · Align four squares across the slot: one left of the pivot, the pivot itself, and two to its right.",
      "ticks": 120,
      "active": {
        "x": 3,
        "y": 13,
        "rotation": 1
      },
      "trigger": {
        "hole": [
          5,
          15
        ],
        "button": "B"
      },
      "blink": true,
      "reveal": "trigger"
    },
    {
      "step": "4",
      "caption": "4 · Press B or A. Either button toggles the I between its two orientation states.",
      "ticks": 120,
      "active": {
        "x": 3,
        "y": 13,
        "rotation": 1
      },
      "buttons": [
        "B"
      ],
      "reveal": "input",
      "buttonOptions": [
        "B",
        "A"
      ],
      "blink": true
    },
    {
      "step": "5",
      "caption": "5 · The I turns horizontally into the slot and completes the row.",
      "ticks": 90,
      "active": {
        "x": 3,
        "y": 13,
        "rotation": 2
      },
      "reveal": "spin"
    },
    {
      "step": "6",
      "caption": "6 · The completed row clears.",
      "clear": true
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["i-spin-open-pocket"]=situation;
})(globalThis);
