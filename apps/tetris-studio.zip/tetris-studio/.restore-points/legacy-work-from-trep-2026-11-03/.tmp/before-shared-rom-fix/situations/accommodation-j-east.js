// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "J · East",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SS..SSSSS",
    ".SSssSSSSS"
  ],
  "accommodation": {
    "orientation": 1,
    "target": {
      "type": "J",
      "x": 3,
      "y": 14,
      "rotation": 1
    },
    "surface": [
      [
        3,
        17
      ],
      [
        4,
        17
      ]
    ],
    "heights": [
      0,
      0
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "14": "....J.....",
        "15": "....J.....",
        "16": ".LLJJLLLLL"
      },
      "placementHighlights": [
        {
          "type": "J",
          "x": 3,
          "y": 14,
          "rotation": 1
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "14": "..........",
        "15": "..........",
        "16": ".LL..LLLLL"
      },
      "active": {
        "type": "J",
        "x": 3,
        "y": 0,
        "rotation": 1
      },
      "highlight": false,
      "showNext": false,
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 112,
      "active": {
        "type": "J",
        "x": 3,
        "y": 14,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 14,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-j-east"]=situation;
})(globalThis);
