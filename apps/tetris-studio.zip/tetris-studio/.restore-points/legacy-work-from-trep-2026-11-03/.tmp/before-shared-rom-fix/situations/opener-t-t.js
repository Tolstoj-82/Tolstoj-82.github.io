// Empty-board NES opener mirrored horizontally for Game Boy.
(function(root){
const situation = {
  "title": "T → T",
  "chapter": "Openers",
  "description": "NES T → T, mirrored horizontally for Game Boy.",
  "stack": [],
  "adjustment": {
    "default": {
      "type": "T",
      "x": 8,
      "y": 15,
      "rotation": 1
    },
    "adjusted": {
      "type": "T",
      "x": 8,
      "y": 15,
      "rotation": 1
    },
    "next": {
      "type": "T",
      "x": 6,
      "y": 16,
      "rotation": 2
    }
  },
  "frames": [
    {
      "step": "1",
      "lessonStage": 4,
      "caption": "T → T: the completed opening.",
      "ticks": 96,
      "rows": {
        "15": ".........T",
        "16": ".......TTT",
        "17": "......TTTT"
      },
      "next": "T",
      "showNext": false,
      "highlight": false,
      "placementHighlights": [
        {
          "type": "T",
          "x": 8,
          "y": 15,
          "rotation": 1
        },
        {
          "type": "T",
          "x": 6,
          "y": 16,
          "rotation": 2
        }
      ],
      "placementColors": [
        "#e04444",
        "#35a35c"
      ]
    },
    {
      "step": "2",
      "lessonStage": 4,
      "caption": "Start with T in the spawning position.",
      "ticks": 2,
      "active": {
        "type": "T",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "next": "T",
      "showNext": true,
      "highlight": false,
      "rows": {
        "15": "..........",
        "16": "..........",
        "17": ".........."
      }
    },
    {
      "step": "3",
      "lessonStage": 5,
      "caption": "Move T right 4 columns.",
      "ticks": 48,
      "active": {
        "type": "T",
        "x": 7,
        "y": 0,
        "rotation": 0
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "Right"
      ],
      "next": "T",
      "showNext": true,
      "highlight": false
    },
    {
      "step": "4",
      "lessonStage": 5,
      "caption": "Press B to turn T.",
      "ticks": 36,
      "active": {
        "type": "T",
        "x": 7,
        "y": 0,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "B"
      ],
      "next": "T",
      "showNext": true,
      "highlight": false
    },
    {
      "step": "5",
      "lessonStage": 5,
      "caption": "Move T right.",
      "ticks": 36,
      "active": {
        "type": "T",
        "x": 8,
        "y": 0,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "Right"
      ],
      "next": "T",
      "showNext": true,
      "highlight": false
    },
    {
      "step": "6",
      "lessonStage": 5,
      "caption": "Let T fall into position.",
      "ticks": 144,
      "active": {
        "type": "T",
        "x": 8,
        "y": 15,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [],
      "next": "T",
      "showNext": true,
      "highlight": false
    },
    {
      "step": "7",
      "lessonStage": 6,
      "caption": "Bring in T.",
      "ticks": 2,
      "active": {
        "type": "T",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "rows": {
        "15": ".........T",
        "16": "........TT",
        "17": ".........T"
      },
      "next": "T",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "8",
      "lessonStage": 6,
      "caption": "Move T right 2 columns.",
      "ticks": 36,
      "active": {
        "type": "T",
        "x": 5,
        "y": 0,
        "rotation": 0
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "Right"
      ],
      "next": "T",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "9",
      "lessonStage": 6,
      "caption": "Press B for the first quarter-turn.",
      "ticks": 36,
      "active": {
        "type": "T",
        "x": 5,
        "y": 0,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "B"
      ],
      "next": "T",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "10",
      "lessonStage": 6,
      "caption": "Press B again for the second quarter-turn.",
      "ticks": 36,
      "active": {
        "type": "T",
        "x": 5,
        "y": 0,
        "rotation": 2
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "B"
      ],
      "next": "T",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "11",
      "lessonStage": 6,
      "caption": "Let T fall into position.",
      "ticks": 144,
      "active": {
        "type": "T",
        "x": 5,
        "y": 16,
        "rotation": 2
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [],
      "next": "T",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "12",
      "lessonStage": 6,
      "caption": "Move T right.",
      "ticks": 36,
      "active": {
        "type": "T",
        "x": 6,
        "y": 16,
        "rotation": 2
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "Right"
      ],
      "next": "T",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "13",
      "lessonStage": 7,
      "caption": "The T → T opening.",
      "ticks": 96,
      "rows": {
        "16": ".......TTT",
        "17": "......TTTT"
      },
      "next": "T",
      "showNext": false,
      "highlight": false
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["opener-t-t"]=situation;
})(globalThis);
