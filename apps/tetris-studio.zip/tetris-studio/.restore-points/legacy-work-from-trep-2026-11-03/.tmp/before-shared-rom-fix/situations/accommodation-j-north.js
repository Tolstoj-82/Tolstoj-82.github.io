// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "J · North",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SSss.SSSS",
    ".SSSSsSSSS"
  ],
  "accommodation": {
    "orientation": 0,
    "target": {
      "type": "J",
      "x": 3,
      "y": 14,
      "rotation": 0
    },
    "surface": [
      [
        3,
        16
      ],
      [
        4,
        16
      ],
      [
        5,
        17
      ]
    ],
    "heights": [
      1,
      1,
      0
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "15": "...JJJ....",
        "16": ".LLLLJLLLL"
      },
      "placementHighlights": [
        {
          "type": "J",
          "x": 3,
          "y": 14,
          "rotation": 0
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "15": "..........",
        "16": ".LLLL.LLLL"
      },
      "active": {
        "type": "J",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "highlight": false,
      "showNext": false,
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 112,
      "active": {
        "type": "J",
        "x": 3,
        "y": 14,
        "rotation": 0
      },
      "animate": true,
      "fallFirst": 14,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-j-north"]=situation;
})(globalThis);
