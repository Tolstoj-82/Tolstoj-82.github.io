// Empty-board NES opener mirrored horizontally for Game Boy.
(function(root){
const situation = {
  "title": "Z → J",
  "chapter": "Openers",
  "description": "NES S → L, mirrored horizontally for Game Boy.",
  "stack": [],
  "adjustment": {
    "default": {
      "type": "Z",
      "x": 3,
      "y": 15,
      "rotation": 0
    },
    "adjusted": {
      "type": "Z",
      "x": 3,
      "y": 15,
      "rotation": 0
    },
    "next": {
      "type": "J",
      "x": 1,
      "y": 16,
      "rotation": 2
    }
  },
  "frames": [
    {
      "step": "1",
      "lessonStage": 4,
      "caption": "Z → J: the completed opening.",
      "ticks": 96,
      "rows": {
        "16": ".J.ZZ.....",
        "17": ".JJJZZ...."
      },
      "next": "J",
      "showNext": false,
      "highlight": false,
      "placementHighlights": [
        {
          "type": "Z",
          "x": 3,
          "y": 15,
          "rotation": 0
        },
        {
          "type": "J",
          "x": 1,
          "y": 16,
          "rotation": 2
        }
      ],
      "placementColors": [
        "#e04444",
        "#35a35c"
      ]
    },
    {
      "step": "2",
      "lessonStage": 4,
      "caption": "Start with Z in the spawning position.",
      "ticks": 2,
      "active": {
        "type": "Z",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "next": "J",
      "showNext": true,
      "highlight": false,
      "rows": {
        "16": "..........",
        "17": ".........."
      }
    },
    {
      "step": "3",
      "lessonStage": 5,
      "caption": "Let Z fall into position.",
      "ticks": 144,
      "active": {
        "type": "Z",
        "x": 3,
        "y": 15,
        "rotation": 0
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [],
      "next": "J",
      "showNext": true,
      "highlight": false
    },
    {
      "step": "4",
      "lessonStage": 6,
      "caption": "Bring in J.",
      "ticks": 2,
      "active": {
        "type": "J",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "rows": {
        "16": "...ZZ.....",
        "17": "....ZZ...."
      },
      "next": "J",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "5",
      "lessonStage": 6,
      "caption": "Move J left 3 columns.",
      "ticks": 36,
      "active": {
        "type": "J",
        "x": 0,
        "y": 0,
        "rotation": 0
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "Left"
      ],
      "next": "J",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "6",
      "lessonStage": 6,
      "caption": "Press B for the first quarter-turn.",
      "ticks": 36,
      "active": {
        "type": "J",
        "x": 0,
        "y": 0,
        "rotation": 1
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "B"
      ],
      "next": "J",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "7",
      "lessonStage": 6,
      "caption": "Press B again for the second quarter-turn.",
      "ticks": 36,
      "active": {
        "type": "J",
        "x": 0,
        "y": 0,
        "rotation": 2
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "B"
      ],
      "next": "J",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "8",
      "lessonStage": 6,
      "caption": "Let J fall into position.",
      "ticks": 144,
      "active": {
        "type": "J",
        "x": 0,
        "y": 16,
        "rotation": 2
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [],
      "next": "J",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "9",
      "lessonStage": 6,
      "caption": "Move J right.",
      "ticks": 36,
      "active": {
        "type": "J",
        "x": 1,
        "y": 16,
        "rotation": 2
      },
      "animate": true,
      "fallFirst": 0,
      "buttons": [
        "Right"
      ],
      "next": "J",
      "showNext": false,
      "highlight": false
    },
    {
      "step": "10",
      "lessonStage": 7,
      "caption": "The Z → J opening.",
      "ticks": 96,
      "rows": {
        "16": ".J.ZZ.....",
        "17": ".JJJZZ...."
      },
      "next": "J",
      "showNext": false,
      "highlight": false
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["opener-z-j"]=situation;
})(globalThis);
