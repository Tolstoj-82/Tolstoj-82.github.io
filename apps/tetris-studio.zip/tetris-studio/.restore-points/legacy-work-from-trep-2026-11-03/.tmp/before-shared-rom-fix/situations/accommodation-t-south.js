// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "T · South",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SS...SSSS",
    ".SSsssSSSS"
  ],
  "accommodation": {
    "orientation": 2,
    "target": {
      "type": "T",
      "x": 3,
      "y": 15,
      "rotation": 2
    },
    "surface": [
      [
        3,
        17
      ],
      [
        4,
        17
      ],
      [
        5,
        17
      ]
    ],
    "heights": [
      0,
      0,
      0
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "15": "....T.....",
        "16": ".LLTTTLLLL"
      },
      "placementHighlights": [
        {
          "type": "T",
          "x": 3,
          "y": 15,
          "rotation": 2
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "15": "..........",
        "16": ".LL...LLLL"
      },
      "active": {
        "type": "T",
        "x": 3,
        "y": 0,
        "rotation": 2
      },
      "highlight": false,
      "showNext": false,
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 120,
      "active": {
        "type": "T",
        "x": 3,
        "y": 15,
        "rotation": 2
      },
      "animate": true,
      "fallFirst": 15,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-t-south"]=situation;
})(globalThis);
