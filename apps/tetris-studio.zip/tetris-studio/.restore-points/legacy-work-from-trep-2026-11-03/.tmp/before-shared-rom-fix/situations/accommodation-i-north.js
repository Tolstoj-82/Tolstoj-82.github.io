// Accommodation surface above a single nine-wide base.
(function(root){
const situation = {
  "title": "I · North",
  "chapter": "Clean stacking",
  "section": "Accommodation stacking",
  "description": "A matching surface supports every occupied column of the piece. It can fall straight down without creating holes or overhangs.",
  "stack": [
    ".SS....SSS",
    ".SSssssSSS"
  ],
  "accommodation": {
    "orientation": 0,
    "target": {
      "type": "I",
      "x": 3,
      "y": 14,
      "rotation": 0
    },
    "surface": [
      [
        3,
        17
      ],
      [
        4,
        17
      ],
      [
        5,
        17
      ],
      [
        6,
        17
      ]
    ],
    "heights": [
      0,
      0,
      0,
      0
    ]
  },
  "frames": [
    {
      "step": "1",
      "ticks": 96,
      "rows": {
        "16": ".LLIIIILLL"
      },
      "placementHighlights": [
        {
          "type": "I",
          "x": 3,
          "y": 14,
          "rotation": 0
        }
      ],
      "placementColors": [
        "#e04444"
      ],
      "highlight": false,
      "showNext": false,
      "tileOverrides": [
        {
          "x": 3,
          "y": 16,
          "tile": 138
        },
        {
          "x": 4,
          "y": 16,
          "tile": 139
        },
        {
          "x": 5,
          "y": 16,
          "tile": 139
        },
        {
          "x": 6,
          "y": 16,
          "tile": 143
        }
      ],
      "caption": "The piece fits this accommodation surface without leaving holes."
    },
    {
      "step": "2",
      "ticks": 2,
      "rows": {
        "16": ".LL....LLL"
      },
      "active": {
        "type": "I",
        "x": 3,
        "y": 0,
        "rotation": 0
      },
      "highlight": false,
      "showNext": false,
      "tileOverrides": [],
      "caption": ""
    },
    {
      "step": "3",
      "ticks": 112,
      "active": {
        "type": "I",
        "x": 3,
        "y": 14,
        "rotation": 0
      },
      "animate": true,
      "fallFirst": 14,
      "buttons": [],
      "highlight": false,
      "showNext": false,
      "caption": ""
    }
  ]
};
if(typeof module!=="undefined")module.exports=situation;
else (root.TetrisSituationFiles??={})["accommodation-i-north"]=situation;
})(globalThis);
