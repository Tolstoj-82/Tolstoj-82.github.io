(function(root){
'use strict';
const C=typeof module!=='undefined'?require('./core.js'):root.TetrisCore;
const directions=['d','l','u','r'];
const G=typeof module!=='undefined'?require('./stack-generator.js'):root.TetrisStackGenerator,BANK=typeof module!=='undefined'?require('./notation-bank.js'):root.TetrisNotationBank;
function token(p,explicit=false){const shape=C.cells(p.type,p.rotation),cols=[...new Set(shape.map(([x])=>p.x+x+1))].sort((a,b)=>a-b);return p.type+(explicit&&['L','J','T'].includes(p.type)?directions[p.rotation]:'')+' '+cols.join(cols.includes(10)?'·':'');}
function build(poses,{entry=null}={}){
 const signature=JSON.stringify(poses);entry=entry||BANK.find(e=>JSON.stringify(e.spec)===signature);
 if(!entry){const seed=[...signature].reduce((n,c)=>((n*31)^c.charCodeAt(0))>>>0,1);entry=G.generate(poses,{random:G.seeded(seed),variants:1}).entries[0];}
 if(!entry||!entry.quality.accepted)throw Error('No teaching-quality stack found for this placement.');
 const targets=C.clone(entry.targets),board=entry.stack.map(r=>[...r]);
 const first=targets[0],next=targets[1],title=targets.map(p=>token(p)).join(', '),frames=[{board,active:{type:first.type,x:3,y:0,rotation:0},ticks:2,highlight:false,showNext:!!next,next:next?.type,caption:'Place '+title+'.'}];
 let completed=board;for(const p of targets)completed=C.compose({board:completed,active:p},18);
 frames.push({board:completed,ticks:96,highlight:false,showNext:false,placementHighlights:targets,placementColors:['#e04444','#35a35c'].slice(0,targets.length),caption:'Solution: '+title+'.'});
 const s=C.normalize({title,frames,...(next?{adjustment:{default:first,adjusted:first,next}}:{})});
 s.notation=true;s.notationTargets=targets;s.stackQuality=entry.quality;s.qualityWell=entry.well;
 // Attempt takes its one-piece goal from the final active frame.
 if(!next)s.frames.push({...s.frames[0],active:first,ticks:96,caption:'Solution: '+title+'.'});
 return s;
}
function exercises(){return BANK.filter(e=>e.practice).map(entry=>build(entry.spec,{entry}));}
function lesson(container){
 const make=(tag,text)=>{const e=document.createElement(tag);if(text)e.textContent=text;return e;};
 const intro=make('p','Columns are numbered 1–10, from left to right. Write the piece, then the columns it occupies. In a pair, the first piece is current and the second is next.');container.append(intro);container.append(make('h3','Read the columns first'));
 const ruler=make('div');ruler.className='notation-columns';for(let n=1;n<=10;n++)ruler.append(make('span',String(n)));container.append(ruler);
 container.append(make('p','L 234, T 89 means: place the current L across columns 2, 3 and 4, then the next T across columns 8 and 9. The stack may make the orientation clear. If it does not, add the direction of the spike.'));
 container.append(make('p','The numbers name the occupied columns, not a route or a sequence of button presses. L 234 spans three columns. T 89 spans two, so the T is vertical. I 5 is a vertical bar in column 5; I 4567 is a horizontal bar across four columns. The notation does not specify a row: read the landing height from the stack.'));
 container.append(make('h3','Let the stack tell you the orientation'));
 container.append(make('p','Usually, the piece and the columns are enough. Look at the surface in those columns and choose the orientation that fits. On these practice stacks, the intended orientation lands without leaving holes. You do not need to write Ld when L 234 already makes the placement clear.'));
 container.append(make('p','The same short instruction can mean a different orientation on a different stack. The two L 234 examples below are both valid: their surfaces tell you whether the spike faces down or up. Read the stack rather than memorising one orientation for each set of columns.'));
 container.append(make('h3','Add a direction only when needed'));
 container.append(make('p','If the columns and the available stack context do not make your intention clear, add a lowercase letter after L, J or T. It describes the direction of the spike, not a movement input. These suffixes clarify an ambiguous placement; they are not a required part of every instruction.'));
 const key=make('dl');key.className='notation-key';for(const[a,b]of [['u','spike up'],['d','spike down'],['l','spike left'],['r','spike right']]){key.append(make('dt',a),make('dd',b));}container.append(key);
 container.append(make('p','For a three-column L, J or T, u/d distinguishes spike up from spike down: Lu 234 versus Ld 234. For a two-column orientation, l/r distinguishes spike left from spike right: Tl 89 versus Tr 89. Without a suffix, L 234 or T 89 is still the normal way to write a clear placement. I, S and Z have two states, and O has one, so their column span already distinguishes their orientations.'));
 container.append(make('h3','Current piece, then next piece'));
 container.append(make('p','In L 234, T-89, first place the current L in columns 2–4; then place the next T in columns 8–9. A space or hyphen separates the piece from its columns. Read the second placement against the stack after the first piece has landed. Red marks the first piece in the examples; green marks the second.'));
 container.append(make('p','Column 10 is one column, not columns 1 and 0. To keep multi-column placements readable, these examples separate it with a dot: O 9·10 occupies columns 9 and 10.'));
 container.append(make('h3','Examples on matching surfaces'));
 const examples=make('div');examples.className='notation-examples';
 for(const spec of [[['L',0,2],['T',3,8]],[['L',0,2]],[['L',2,2]],[['T',1,8]],[['I',1,10]],[['O',0,9]]]){
  const s=build(spec),card=make('figure'),canvas=make('canvas');canvas.width=240;canvas.height=168;canvas.setAttribute('role','img');canvas.setAttribute('aria-label',s.title+' on a matching stack');const ctx=canvas.getContext('2d'),final=s.frames[1],tiles=C.visualTiles(final,18);const shades=['#a6b779','#829560','#536c3e','#26351e'];
  for(let y=12;y<18;y++)for(let x=0;x<10;x++){const pattern=C.ROM.tiles[tiles[y][x]];for(let py=0;py<8;py++)for(let px=0;px<8;px++){ctx.fillStyle=shades[+pattern[py][px]];ctx.fillRect(x*24+px*3,(y-12)*24+py*3,3,3);}}
  for(const [i,p]of s.notationTargets.entries()){ctx.save();ctx.globalAlpha=.55;ctx.fillStyle=i?'#35a35c':'#e04444';for(const[dx,dy]of C.cells(p.type,p.rotation))ctx.fillRect((p.x+dx)*24,(p.y+dy-12)*24,24,24);ctx.restore();}
  ctx.fillStyle='#475569';for(let n=1;n<=10;n++)ctx.fillRect((n-1)*24,146,1,5);
  const numbers=make('div');numbers.className='notation-columns';for(let n=1;n<=10;n++)numbers.append(make('span',String(n)));
  const explanation=make('p',s.notationTargets.length>1?'First the L, then the T. The surfaces identify both orientations.':['L','J','T'].includes(s.notationTargets[0].type)?'The surface makes '+token(s.notationTargets[0],true)+' clear, so the direction suffix can be omitted.':'The occupied columns identify the orientation.');card.append(make('figcaption',s.title),canvas,numbers,explanation);examples.append(card);
 }container.append(examples);
 container.append(make('h3','Read it, then place it'));
 container.append(make('p','Try it: read the instruction, rotate if needed, and place the piece in the named columns. Pair drills ask for both pieces in order. First identify the piece, then the columns, then the orientation that fits the surface. Each stack accommodates the requested placements without tucks or spins. The prompts normally omit direction letters because the stack supplies that information.'));
 const button=make('button','Practise stack notation');button.id='startNotationPractice';button.onclick=()=>{root.TetrisCourse.leaveIntro();root.liveAttempt.startNotation();};container.append(button);
}
const api={token,build,exercises,lesson};if(typeof module!=='undefined')module.exports=api;else root.TetrisNotation=api;
})(globalThis);
