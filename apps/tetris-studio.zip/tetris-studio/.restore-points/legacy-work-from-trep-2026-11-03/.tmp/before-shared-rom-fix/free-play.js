(function(root){
'use strict';
const C=typeof module!=='undefined'?require('./core.js'):root.TetrisCore,P=typeof module!=='undefined'?require('./playable.js'):root.TetrisPlayable;
const ORDER=Object.freeze(['L','J','I','O','Z','S','T']),CPU_HZ=4194304,FRAME_CYCLES=70224,FRAME_MS=FRAME_CYCLES/CPU_HZ*1000;
function seedPhase(){const a=new Uint16Array(1);if(root.crypto?.getRandomValues){root.crypto.getRandomValues(a);return a[0];}return Math.floor((root.performance?.now?.()??Date.now())*CPU_HZ/1000)&65535;}
class RomRandom{
 constructor({phase=seedPhase(),hidden=0,preview=0,readDivider=null}={}){this.cycles=phase&65535;this.hidden=hidden&252;this.preview=preview&252;this.readDivider=readDivider;this.lastTrace=null;}
 tick(cycles){this.cycles+=cycles;}
 divider(){return this.readDivider?this.readDivider(this.cycles)&255:(Math.floor(this.cycles/256)&255);}
 select(){const c=this.preview&252,oldHidden=this.hidden;let h=3,d=0;const reads=[];this.tick(8); // LD H,3 at $2041
  for(;;){this.tick(12);let b=this.divider();reads.push(b);this.tick(4);let a=0;this.tick(4); // LD B,A / XOR A
   for(;;){b=(b-1)&255;this.tick(4);if(b===0){this.tick(12);break;}this.tick(8);a=(a+4)&255;this.tick(16);this.tick(8);if(a===28){this.tick(12);a=0;this.tick(4);}else this.tick(20);}
   d=a;this.tick(4);this.tick(12);this.tick(4);h--;this.tick(4);if(h===0){this.tick(12);break;}this.tick(8);const reject=((oldHidden|d|c)&252)===c;this.tick(20);this.tick(reject?12:8);if(!reject)break;
  }
  this.tick(4);this.hidden=d;this.tick(12);this.tick(4);this.preview=oldHidden;this.tick(16);
  this.lastTrace={reads,current:c,previousHidden:oldHidden,candidate:d,preview:this.preview,cycles:this.cycles};return ORDER[c>>2];
 }
 beginGame(){this.preview=0;let active;for(let n=0;n<3;n++)active=this.select();return active;}
 get next(){return ORDER[this.preview>>2];}
}
function nativeTurn(type,rotation,action){return C.nativeTurn(type,rotation,action);}
const spawn=type=>({type,x:3,y:0,rotation:C.STATE_LAYOUTS[type].indexOf(0)});
function levelAfterLines(level,lines){return level<20&&lines<1000&&Math.floor(lines/10)>level?level+1:level;}
class FreeGame extends P.Attempt{
 constructor({level=0,rng=new RomRandom()}={}){super({height:18,frames:[{board:C.empty(18),active:spawn('L')}]},P.gravityForLevel(level));this.freePlay=true;this.rng=rng;this.startLevel=Math.max(0,Math.min(20,Number(level)||0));this.level=this.startLevel;this.score=0;this.lines=0;this.pieces=0;this.goals=[];this.active=spawn(rng.beginGame());this.nextPiece=rng.next;this.done=false;this.correct=false;this.frame=null;this.softCounter=0;this.gravityInput=false;this.frames=0;this.epoch=rng.cycles;this.spawnLocks=0;}
 onInputFrame({down,horizontal}){this.frames++;this.rng.cycles=this.epoch+this.frames*FRAME_CYCLES;if(!down||horizontal)this.softCounter=0;}
 input(action){if((action==='a'||action==='b')&&!this.done&&this.active){const next={...this.active,rotation:nativeTurn(this.active.type,this.active.rotation,action)};if(!this.fits(next))return false;this.active=next;return true;}if(action==='down'&&!this.gravityInput&&!this.done&&!this.pendingPiece)this.softCounter++;return super.input(action);}
 setLevel(level){this.startLevel=Math.max(0,Math.min(20,Number(level)||0));this.level=Math.max(this.startLevel,Math.min(20,Math.floor(this.lines/10)));this.gravity=P.gravityForLevel(this.level);this.elapsed=0;}
 lock(){if(!this.active||this.done)return;const p=this.active,tiles=C.visualTiles({board:this.board,active:p,tileOverrides:this.tileOverrides},18);this.board=C.compose({board:this.board,active:p},18);this.pieces++;const rows=C.fullRows(this.board);this.rows=rows.length;this.totalRows=this.lines=Math.min(9999,this.lines+rows.length);this.score=(this.score+[0,40,100,300,1200][rows.length]*(this.level+1)+Math.max(0,this.softCounter-1))%1000000;this.softCounter=0;
  this.tileOverrides=[];this.board.forEach((row,y)=>row.forEach((type,x)=>{if(type==='I')this.tileOverrides.push({x,y,tile:tiles[y][x]});}));
  this.frame={board:this.board,buttons:[],highlight:false,tileOverrides:this.tileOverrides,...(rows.length?{clear:true,clearRows:rows}:{})};this.active=null;this.pendingRows=rows;this.transitionApplied=false;this.clearTicks=0;this.spawnElapsed=0;this.spawnDelay=(rows.length?C.LINE_CLEAR.ticks:C.ENTRY_DELAY)*1000/C.HZ;this.pendingPiece=this.nextPiece;
  if(p.x===3&&p.y===0){if(++this.spawnLocks>=2){this.done=true;this.pendingPiece=null;}}this.pendingLevel=rows.length?levelAfterLines(this.level,this.lines):this.level;
 }
 advance(ms){if(this.pendingPiece){this.spawnElapsed+=ms;if(this.pendingRows.length){this.clearTicks=Math.min(C.LINE_CLEAR.ticks,this.spawnElapsed*C.HZ/1000);if(!this.transitionApplied&&this.clearTicks+1e-7>=C.LINE_CLEAR.ticks-3){this.level=this.pendingLevel;this.gravity=P.gravityForLevel(this.level);this.transitionApplied=true;}}if(this.spawnElapsed+1e-7>=this.spawnDelay){if(this.pendingRows.length){this.board=C.collapseRows(this.board,this.pendingRows);this.tileOverrides=this.tileOverrides.filter(o=>!this.pendingRows.includes(o.y)).map(o=>({...o,y:o.y+this.pendingRows.filter(y=>y>o.y).length}));}this.pendingRows=[];if(this.pendingLevel!==undefined){this.level=this.pendingLevel;this.gravity=P.gravityForLevel(this.level);}const type=this.rng.select();this.nextPiece=this.rng.next;this.active=spawn(type);this.pendingPiece=null;this.frame=null;this.elapsed=0;}return;}
  this.gravityInput=true;try{super.advance(ms);}finally{this.gravityInput=false;}
 }
 idle(ms){const cycles=Math.max(0,Math.floor(ms*CPU_HZ/1000));this.epoch+=cycles;this.rng.cycles+=cycles;}
}
const api={RomRandom,FreeGame,ORDER,spawn,nativeTurn,levelAfterLines,CPU_HZ,FRAME_CYCLES,FRAME_MS};if(typeof module!=='undefined')module.exports=api;else root.TetrisFreePlay=api;
})(globalThis);
