const fs=require('fs'),p=require('path'),root='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio',C=require(p.join(root,'core.js'));
const pose=(type,x,y,rotation=0)=>({type,x,y,rotation});
const defs=[
['adjustment-vert-s-for-l','Vertical S for L · 89 (Ori: Vert Z for J)', ['SSSSS.....','SSSSSS....','SSSSSSSSS.','SSSSSSSSS.','SSSSSSSSS.'],pose('S',1,12),pose('S',2,12,1),pose('L',-1,12,3),'Stand S vertically to support L and prepare the stack for a Tetris.'],
['adjustment-zvert','Zvert (Ori: Svert)',['SSSSSSS...','SSSSSSS...','SSSSSSS...','SSSSSSSSS.','SSSSSSSSS.'],pose('Z',0,13),pose('Z',1,13,1),pose('Z',0,12,1),'Stand the first Z vertically to leave a landing for the next Z.'],
['adjustment-o-sz-flat','O for S/Z flat · Manners / Wok / Swipe to unlock',['S....SSSS.','SSSSSSSSS.'],pose('O',6,14),pose('O',4,14),pose('S',7,13),'Shift O inward to leave a flat landing for S.'],
['adjustment-js-tristop','JS Tristop thing (Ori: LZ Tristop thing)',['SSSSS.....','SSSSS.....','SSSSSSS...','SSSSSSSSS.','SSSSSSSSS.'],pose('J',3,12,3),pose('J',2,12),pose('S',1,13),'Lay J on the shelf, then spin and tuck S underneath it.']
];
for(const [key,title,source,def,adj,next,description]of defs){
 const base=Array.from({length:18-source.length},()=>Array(10).fill('.')).concat(source.map(r=>[...r].reverse().map(c=>c==='S'?'L':'.'))),locked=C.compose({board:base,active:adj},18),both=C.compose({board:locked,active:next},18),occupied=new Set([adj,next].flatMap(a=>C.cells(a.type,a.rotation).map(([x,y])=>`${x+a.x},${y+a.y}`)));
 const stack=base.slice(18-source.length).map((row,r)=>row.map((c,x)=>c==='.'?'.':[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>occupied.has(`${x+dx},${r+18-source.length+dy}`))?'s':'S').join(''));
 const s=JSON.parse(JSON.stringify(require(p.join(root,'situations/adjustment-key-tuck-setup.js'))));Object.assign(s,{title,description,section:'Good but Situational',stack,adjustment:{default:def,adjusted:adj,next}});
 s.frames=s.frames.filter(f=>f.step!=='6b');
 const rows=(b,prev)=>Object.fromEntries(b.map((r,y)=>[y,r.join('')]).filter(([y,r])=>r!==prev[y].join('')));
 for(const f of s.frames){delete f.rows;delete f.buttons;f.next=next.type;f.caption=f.step==='1'?'Notice the stack motif around the two landing positions.':f.step==='2'?'Default: the usual landing without this adjustment.':f.step==='3'?`Look ahead: ${next.type} is next.`:f.step==='4'?description:f.step==='4a'?`The next ${next.type} fits beside the adjusted ${adj.type}.`:f.step==='5'?`Place ${adj.type} in the adjusted position.`:f.step==='6'?`Bring in ${next.type}.`:f.step==='6a'?`Place ${next.type} in the space left for it.`:f.step==='7'?'Notice how the two placements work together.':'Notice the motif around the completed pair.';
 if(f.active)f.active=pose(f.lessonStage<6?adj.type:next.type,3,0);if(f.ghost)f.ghost={...(f.step==='4a'?next:f.step==='4'?adj:def),label:f.ghost.label};if(f.referenceGhost)f.referenceGhost={...adj,label:'Adjusted'};
 if(f.step==='5'){f.active={...adj};f.buttons=adj.rotation?[adj.rotation===3?'A':'B']:[];}
 if(f.step==='6')f.rows=rows(locked,base);
 if(f.step==='6a'){f.active={...next};f.buttons=next.rotation?[next.rotation===3?'A':'B']:[];}
 if(f.placementHighlights){f.placementHighlights=[adj,next];f.rows=rows(both,locked);}
 }
 if(key==='adjustment-js-tristop'){
 const descent=s.frames.find(f=>f.step==='6a');descent.active=pose('S',0,13,1);descent.buttons=['B'];descent.caption='Lower S vertically beside the overhang.';
 const at=s.frames.indexOf(descent)+1;
 s.frames.splice(at,0,{step:'6b',lessonStage:6,caption:'Press A or B to spin S flat beneath J.',ticks:36,next:'S',showNext:false,highlight:false,active:pose('S',0,13),animate:true,fallFirst:0,buttons:['B'],buttonOptions:['B','A']},{step:'6c',lessonStage:6,caption:'Press Right once to finish the Spuck underneath J.',ticks:36,next:'S',showNext:false,highlight:false,active:{...next},animate:true,fallFirst:0,buttons:['Right']});
 }
 const file=p.join(root,'situations/'+key+'.js');fs.writeFileSync(file,'// NES reference mirrored horizontally for Game Boy.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
let core=fs.readFileSync(p.join(root,'core.js'),'utf8');core=core.replace(' if(raw.adjustment){const m=',` if(raw.section!==undefined){if(raw.chapter!=='Adjustments'||!['Good','Good but Situational'].includes(raw.section))throw Error('Unknown adjustment section.');result.section=raw.section;}\n if(raw.adjustment){const m=`).replace('if(s.chapter)out.chapter=s.chapter;','if(s.chapter)out.chapter=s.chapter;if(s.section)out.section=s.section;');fs.writeFileSync(p.join(root,'core.js'),core);
let app=fs.readFileSync(p.join(root,'app.js'),'utf8').replace("isAdjustment?'Piece-dependent placements'","isAdjustment?(s.section||'Good')");fs.writeFileSync(p.join(root,'app.js'),app);
const keys=defs.map(d=>d[0]);let manifest=fs.readFileSync(p.join(root,'situations.js'),'utf8').replace('  "adjustment-noro-pc-burn"','  "adjustment-noro-pc-burn",\n'+keys.map(k=>'  '+JSON.stringify(k)).join(',\n'));fs.writeFileSync(p.join(root,'situations.js'),manifest);
let html=fs.readFileSync(p.join(root,'index.html'),'utf8').replace('<script src="situations.js"',keys.map(k=>'<script src="situations/'+k+'.js" defer></script>').join('')+'<script src="situations.js"');fs.writeFileSync(p.join(root,'index.html'),html);
let tests=fs.readFileSync(p.join(root,'app.test.cjs'),'utf8').replace("h.cards().length,84","h.cards().length,88").replaceAll("libraryCount.textContent,'85'","libraryCount.textContent,'89'");fs.writeFileSync(p.join(root,'app.test.cjs'),tests);
