const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const variant of ['well','ledge']){
 const s=structuredClone(require(path.join(root,'situations/s-spin-well.js'))),y=variant==='well'?14:13;
 s.title=variant==='well'?'I-Spin (well)':'I-Spin (ledge)';s.piece='I';
 s.stack=variant==='well'?['..SSSSSSSS','.,SSSSSSSS','.,$sSSSSSS',',,,,$SSSSS','.,$sSSSSSS']:['.,.SSSSSSS','.,.$SSSSSS',',,,,$SSSSS','.,$sSSSSSS','....SSSSSS'];
 for(const f of s.frames)if(f.caption)f.caption=f.caption.replaceAll('S piece','I piece').replaceAll('the S','the I').replaceAll('horizontal S','horizontal I');
 for(const f of s.frames.slice(3,7))f.active={x:0,y,rotation:1};
 s.frames[1].caption='1a · The supporting stack around the slot. Brighter cells mark the provisional required corners.';
 s.frames[2].caption='1b · The empty cross-shaped space is the counter-motif: room for the upright I and its horizontal turn.';
 s.frames[3].caption='2 · Turn the I upright, move into the left channel, then descend to the slot.';
 s.frames[4].trigger={hole:[2,y+2],button:'B'};
 s.frames[4].caption='3 · Align the pivot with the empty square immediately to its right, along the horizontal slot.';
 s.frames[6].active.rotation=2;
 s.frames[6].caption='5 · The I turns horizontally into the slot and completes the row.';
 s.frames[7].caption='6 · The completed row clears.';
 const key='i-spin-'+variant;fs.writeFileSync(path.join(root,'situations',key+'.js'),'// Provisional I-spin reconstruction from the supplied reference.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"s-spin-center"\n','"s-spin-center",\n  "i-spin-well",\n  "i-spin-ledge"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/i-spin-well.js"></script><script src="situations/i-spin-ledge.js"></script><script src="situations.js">'));
edit('app.js',s=>s.replace("s:'S-Spins',jd:","s:'S-Spins',i:'I-Spins',jd:"));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'07'","libraryCount.textContent,'09'").replace('h.cards().length,6','h.cards().length,8').replace("['T-Spins','JD spin','Z-Spins','S-Spins']","['T-Spins','JD spin','Z-Spins','S-Spins','I-Spins']").replace('),[2,1,2,2])','),[2,1,2,2,2])'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,7','C.parseCollection(demo).length,9')+`
test('I-spin variants descend safely, fit their slots and clear the reference row',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('I-Spin'));assert.equal(variants.length,2);
 for(const[i,s]of variants.entries()){
  assert.deepEqual(s.frames.map(f=>f.step),['1','1a','1b','2','3','4','5','6']);assert.equal(s.frames[2].counterMotif.cells.length,7);
  const f=s.frames[3],stack=C.compose({...f,active:undefined},18);
  for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells(a.type,a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}
  assert.deepEqual(s.frames[5].buttonOptions,['B','A']);assert.deepEqual(s.frames[7].clearRows,[i===0?16:15]);assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
