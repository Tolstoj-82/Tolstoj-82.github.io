const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
edit('situations.js',s=>s.replace('  "jd-spin",\n',''));
edit('index.html',s=>s.replace('<script src="situations/jd-spin.js"></script>',''));
fs.unlinkSync(path.join(root,'situations/jd-spin.js'));
edit('app.js',s=>s.replace("openGroups=new Set(Array.from(list.children).filter(group=>group.open).map(group=>group.dataset.group)),groups=new Map();list.replaceChildren();",`openGroups=new Set(),groups=new Map();
function remember(node){for(const child of node.children){if(child.open)openGroups.add(child.dataset.group);remember(child);}}remember(list);list.replaceChildren();
const categories=new Map();for(const label of ['Spins','Spucks']){const category=document.createElement('details');category.className='spin-group situation-category';category.dataset.group=label;category.open=openGroups.has(label);const heading=document.createElement('summary');heading.textContent=label;category.append(heading);categories.set(label,category);list.append(category);}
`).replace('groups.set(label,group);list.append(group);','groups.set(label,group);categories.get(\'Spins\').append(group);'));
edit('studio.css',s=>s+'\n.situation-category > .spin-group { margin-left: 10px; }\n.situation-category > summary { font-size: 15px; }\n');
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,20','C.parseCollection(demo).length,19'));
edit('app.test.cjs',s=>{
 s=s.replace('const cards=()=>elements.situationList.children.flatMap(group=>group.children.slice(1));',`const cards=()=>{const result=[];function walk(node){for(const child of node.children){if(child.tagName==='BUTTON')result.push(child);else walk(child);}}walk(elements.situationList);return result;};`);
 s=s.replaceAll("libraryCount.textContent,'20'","libraryCount.textContent,'19'").replace('h.cards().length,19','h.cards().length,18').replace('[7,8,9,10,11]','[6,7,8,9,10]').replace('h.cards()[4]','h.cards()[3]').replace('data.situations[4]','data.situations[3]').replace('data.situations[3].stack[0]','data.situations[2].stack[0]').replace('for(const card of [3,4])','for(const card of [2,3])');
 const start=s.indexOf(" await test('spin families start"),end=s.indexOf(" await test('situation menu toggles",start);
 s=s.slice(0,start)+` await test('Spins and Spucks start collapsed, group existing spins and preserve expansion',()=>{
  const h=boot(),categories=h.elements.situationList.children;assert.deepEqual(categories.map(g=>g.children[0].textContent),['Spins','Spucks']);assert(categories.every(g=>!g.open));assert.equal(categories[1].children.length,1);
  const groups=categories[0].children.slice(1);assert.deepEqual(groups.map(g=>g.children[0].textContent),['T-Spins','Z-Spins','S-Spins','I-Spins','J-Spins','L-Spins']);assert(groups.every(g=>!g.open));assert.deepEqual(groups.map(g=>g.children.length-1),[2,2,2,5,4,4]);
  categories[0].open=true;groups[2].open=true;h.cards()[5].onclick();assert.equal(h.elements.studyTitle.textContent,'S-Spin (center)');assert(h.elements.situationList.children[0].open);assert(h.elements.situationList.children[0].children[3].open);assert.equal(boot().elements.situationList.children[0].open,false);assert(!h.cards().some(c=>c.children[1].children[0].textContent==='JD spin'));
 });
`+s.slice(end);return s;
});
