const C=require('../../tetris-studio/js/core'),H=require('../../tetris-studio/js/placement-hint'),F=require('../../tetris-studio/js/free-play'),Q=require('../../tetris-studio/js/stack-quality');
for(const seed of ['123456','000001','ABCDEF']){
 const rng=new F.LfsrRandom({seed});let type=rng.beginGame(),board=C.empty(18),lines=0,noHint=0,total=0,max=0,n=0;
 for(;n<60;n++){const t=performance.now(),r=H.compute({board,active:C.spawn(type),nextPiece:rng.next,gravityFrames:53,elapsedFrames:0,level:0,lines:0});total+=performance.now()-t;if(!r){noHint++;break;}const result=H.apply(board,r.placement);board=result.board;lines+=result.cleared;max=Math.max(max,Q.analyze(board).height.max);type=rng.select();}
 const m=Q.analyze(board);console.log(JSON.stringify({seed,pieces:n,noHint,lines,peakHeight:max,finalHoles:m.holes.count,finalHeight:m.height.max,totalSearchMs:Math.round(total)}));
}
