const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
fs.writeFileSync(path.join(root,'adjustments.test.cjs'),String.raw`
const assert=require('node:assert/strict'),C=require('./core.js'),raw=require('./situations/adjustment-lj-koryan.js'),s=C.normalize(raw),{Attempt}=require('./playable.js');require('./course.js');
const test=(name,fn)=>{fn();console.log('PASS '+name);};
const fits=(board,a)=>C.cells(a.type,a.rotation).every(([x,y])=>a.x+x>=0&&a.x+x<10&&board[a.y+y][a.x+x]==='.');
test('NES Koryan reference is mirrored horizontally, including L/J handedness',()=>{
 const original=['.......SS.','SSSS..SSS.','SSSS..SSS.'];const board=C.compose(s.frames[0],18).slice(15).map(r=>r.map(c=>c==='.'?'.':'S').join(''));
 assert.deepEqual(board,original.map(r=>[...r].reverse().join('')));assert.equal(s.adjustment.adjusted.type,'J');assert.equal(s.adjustment.next.type,'L');assert.deepEqual(s.frames[0].motif.cells,[[3,16],[6,16],[3,17],[6,17]]);
});
test('default blocks the next L, while adjusted placements fit and cap the motif',()=>{
 const b=C.compose(s.frames[0],18),m=s.adjustment;assert(fits(b,m.default));assert(!fits(C.compose({board:b,active:m.default},18),m.next));assert(fits(b,m.adjusted));assert(fits(C.compose({board:b,active:m.adjusted},18),m.next));
 const occupied=new Set([m.adjusted,m.next].flatMap(a=>C.cells(a.type,a.rotation).map(([x,y])=>[x+a.x,y+a.y].join(','))));for(const[x,y]of s.frames[0].motif.cells)assert(occupied.has([x===3?4:5,y].join(',')));
});
test('default and adjusted ghosts, next cue, pair highlight and final motif blink are separate steps',()=>{
 assert.equal(s.frames[0].active,undefined);assert(s.frames[0].motif);for(const i of [1,2,3])assert.equal(s.frames[i].active.y,0);
 assert.equal(C.frameAt(s.frames[1],0).ghost.label,'Default');assert.equal(C.frameAt(s.frames[1],13).ghost,undefined);assert.equal(C.frameAt(s.frames[2],0).nextPreviewVisible,true);assert.equal(C.frameAt(s.frames[2],13).nextPreviewVisible,false);assert.equal(s.frames[3].ghost.label,'Adjusted');assert.equal(s.frames[7].placementHighlights.length,2);assert.equal(C.frameAt(s.frames[7],13).placementHighlights,undefined);assert(s.frames.at(-1).motif);
});
test('both piece animations and the continuous clean playback avoid stack collisions',()=>{
 for(const f of s.frames.filter(f=>f.animate)){const b=C.compose({...f,active:undefined},18);for(let t=0;t<=f.ticks;t++)assert(fits(b,C.frameAt(f,t).active));}
 const clean=global.TetrisCourse.clean(s);assert(clean.frames.some(f=>f.active?.type==='J'));assert(clean.frames.some(f=>f.active?.type==='L'));for(const f of clean.frames){if(f.active)assert(fits(C.compose({...f,active:undefined},18),f.active));assert(!f.ghost&&!f.motif&&!f.placementHighlights);}
});
test('adjustment metadata and every lesson cue survive compact file export',()=>assert.deepEqual(C.normalize(C.compact(s)),s));
test('playable adjustment requires both correct placements before success and retries a wrong first placement',()=>{
 const a=new Attempt(s);a.active=C.clone(s.adjustment.adjusted);a.lock();assert(!a.done);assert.equal(a.pendingPiece,'L');a.advance(2*1000/C.HZ);assert.equal(a.active.type,'L');assert.equal(a.active.y,0);a.active=C.clone(s.adjustment.next);a.lock();assert(a.done&&a.correct);
 const b=new Attempt(s);b.active=C.clone(s.adjustment.default);b.lock();assert(b.done&&!b.correct);assert(!b.pendingPiece);
});
`);
let p=path.join(root,'core.test.cjs'),s1=fs.readFileSync(p,'utf8').replace('C.parseCollection(demo).length,29','C.parseCollection(demo).length,30');fs.writeFileSync(p,s1);
p=path.join(root,'app.test.cjs');s1=fs.readFileSync(p,'utf8').replace("child.tagName==='BUTTON'", "child.tagName==='BUTTON'&&child.className?.includes('study-card')").replaceAll("libraryCount.textContent,'29'","libraryCount.textContent,'30'").replace('h.cards().length,28','h.cards().length,29');
const a=s1.indexOf(" await test('Spins and Spucks start"),b=s1.indexOf(" await test('situation menu toggles",a);
s1=s1.slice(0,a)+` await test('course chapters start collapsed and preserve existing spin groups',()=>{
 const h=boot(),categories=h.elements.situationList.children;assert.deepEqual(categories.map(g=>g.children[0].textContent),['Introduction','Spins','Spucks','Adjustments']);assert(categories.every(g=>!g.open));assert.equal(categories[2].children[1].children[0].textContent,'T-Spucks');assert.equal(categories[2].children[1].children.length,5);
 const groups=categories[1].children.slice(1);assert.deepEqual(groups.map(g=>g.children[0].textContent),['T-Spins','Z-Spins','S-Spins','I-Spins','J-Spins','L-Spins']);assert.deepEqual(groups.map(g=>g.children.length-1),[2,2,2,5,4,4]);
 categories[1].open=true;groups[2].open=true;h.cards()[5].onclick();assert.equal(h.elements.studyTitle.textContent,'S-Spin (center)');assert(h.elements.situationList.children[1].open);assert(h.elements.situationList.children[1].children[3].open);assert.equal(boot().elements.situationList.children[1].open,false);
 });
 await test('adjustment URL opens its chapter and shows ghosts, next piece and the two-piece sequence',()=>{
 const h=boot(undefined,'file:///C:/tetris/index.html?situation=adjustment-lj-koryan');assert.equal(h.elements.studyTitle.textContent,'L-J Koryan Thing');const categories=h.elements.situationList.children;assert(categories[3].open);assert(categories[3].children[1].open);assert.equal(h.elements.spinConcepts.children.length,5);
 h.click('next');assert.equal(h.elements.ghostPlacementLabel.textContent,'Default');assert.equal(h.elements.ghostPlacementLabel.hidden,false);h.click('next');assert.equal(h.elements.nextPieceName.textContent,'L');h.click('next');assert.equal(h.elements.ghostPlacementLabel.textContent,'Adjusted');
 const s=h.exported();assert.equal(s.adjustment.adjusted.type,'J');assert.equal(s.adjustment.next.type,'L');h.elements.cleanPlayback.checked=true;h.change('cleanPlayback',true);const clean=h.exported();assert(clean.frames.some(f=>f.active?.type==='J'));assert(clean.frames.some(f=>f.active?.type==='L'));
 });
 await test('introductory lessons are navigable and situation selection returns to the player',()=>{
 const h=boot();h.elements.situationList.children[0].children[1].onclick();assert.equal(h.elements.courseIntroduction.hidden,false);assert.equal(h.elements.courseIntroTitle.textContent,'Welcome');assert.equal(new URL(h.context.location.href).searchParams.get('lesson'),'welcome');
 h.cards()[0].onclick();assert(h.elements.courseIntroduction.hidden);assert.equal(new URL(h.context.location.href).searchParams.get('lesson'),null);
 const direct=boot(undefined,'file:///C:/tetris/index.html?lesson=reading-the-board');assert.equal(direct.elements.courseIntroduction.hidden,false);assert.equal(direct.elements.courseIntroTitle.textContent,'Reading the board');assert(direct.elements.situationList.children[0].open);
 });
`+s1.slice(b);fs.writeFileSync(p,s1);
