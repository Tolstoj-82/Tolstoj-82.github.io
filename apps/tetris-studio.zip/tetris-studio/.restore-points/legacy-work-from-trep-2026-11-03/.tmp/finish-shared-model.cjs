const fs=require('fs'),root=require('path').resolve('../tetris-studio');function edit(file,fn){const p=root+'/'+file;fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')))}
edit('core.test.cjs',s=>s.replace("b[f.active.y+dy][f.active.x+dx],'.'","(f.active.y+dy<0?'.':b[f.active.y+dy][f.active.x+dx]),'.'"));
edit('adjustments.test.cjs',s=>s.replace("a.y+y>=0&&a.y+y<board.length&&board[a.y+y][a.x+x]", "a.y+y>=-2&&a.y+y<board.length&&(a.y+y<0?'.':board[a.y+y][a.x+x])"));
edit('course.js',s=>s.replace('expected=null,gap=false','expected=null,nextTap=0').replace("else if(!gap){if(attempt.input(action))", "else if(tick>=nextTap){if(attempt.input(action))").replace("gap=true;expected={...attempt.active};}else{gap=false;expected={...attempt.active};}","nextTap=tick+6;expected={...attempt.active};}else{expected={...attempt.active};}"));
edit('ASSETS.md',s=>s.replace('The app shifts the shared empty upper row out of most piece coordinates (and two rows for O) to retain useful editor anchors;', 'The app shifts one shared upper row out of non-I piece coordinates to retain useful editor anchors;'));
console.log('Adjusted playback input spacing and hidden-row assertions.');
