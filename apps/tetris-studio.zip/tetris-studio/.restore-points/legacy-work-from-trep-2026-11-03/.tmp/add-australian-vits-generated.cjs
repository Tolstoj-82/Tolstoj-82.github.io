const fs=require('fs'),r='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio',C=require(r+'/core.js'),{path:legalPath,fits}=require('./audit-course-paths.cjs');
const pose=(type,x,y,rotation)=>({type,x,y,rotation}),definitions=[
  {
    "key": "adjustment-vits-australian-west",
    "title": "VITS · Australian · L West",
    "source": [
      "......S...",
      "..S...SS..",
      ".SSS..SS..",
      "SSSS.SS...",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS.."
    ],
    "def": {
      "type": "L",
      "x": 0,
      "y": 15,
      "rotation": 1
    },
    "adjusted": {
      "type": "L",
      "x": 0,
      "y": 11,
      "rotation": 3
    },
    "description": "An Australian: tuck L right into the recess, then lower I at the left wall and tuck it right beneath L. The first tuck sets up the second."
  },
  {
    "key": "adjustment-vits-australian-east",
    "title": "VITS · Australian · L East",
    "source": [
      ".S.S.S.S..",
      "SSSSSSSS..",
      "SSSSSSS...",
      "SSSSSSS...",
      "SSSSSSS...",
      "SSSSSSSS..",
      "SSSSSSSS.."
    ],
    "def": {
      "type": "L",
      "x": 0,
      "y": 15,
      "rotation": 1
    },
    "adjusted": {
      "type": "L",
      "x": 1,
      "y": 13,
      "rotation": 1
    },
    "description": "An Australian: tuck L right into the recess, then lower I at the left wall and tuck it right beneath L. The first tuck sets up the second."
  },
  {
    "key": "adjustment-vits-australian-south",
    "title": "VITS · Australian · L South",
    "source": [
      "......S...",
      ".S.S.SS...",
      "SSSSSS....",
      "SSSSSS....",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS.."
    ],
    "def": {
      "type": "L",
      "x": 0,
      "y": 15,
      "rotation": 1
    },
    "adjusted": {
      "type": "L",
      "x": 1,
      "y": 12,
      "rotation": 2
    },
    "description": "An Australian: tuck L right into the recess, then lower I at the left wall and tuck it right beneath L. The first tuck sets up the second."
  },
  {
    "key": "adjustment-vits-australian-north",
    "title": "VITS · Australian · L North",
    "source": [
      "....S.....",
      "S...SS....",
      "S.S.SSS...",
      "SSSSSS....",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS.."
    ],
    "def": {
      "type": "L",
      "x": 0,
      "y": 15,
      "rotation": 1
    },
    "adjusted": {
      "type": "L",
      "x": 1,
      "y": 11,
      "rotation": 0
    },
    "description": "An Australian: tuck L right into the recess, then lower I at the left wall and tuck it right beneath L. The first tuck sets up the second."
  }
];
const template=C.clone(require(r+'/situations/adjustment-vits-palito.js')),delta=(b,a)=>Object.fromEntries(b.map((row,y)=>[y,row.join('')]).filter(([y,row])=>row!==a[y].join(''))),move=(a,input)=>({...a,x:a.x+(input==='left'?-1:input==='right'?1:0),y:a.y+(input==='down'?1:0),rotation:(a.rotation+(input==='a'?3:input==='b'?1:0))%4});
const generated=[];
for(const d of definitions){const next=pose('I',0,14,1),base=C.empty(18-d.source.length).concat(d.source.map(row=>[...row].reverse().map(c=>c==='S'?'L':'.'))),first=C.compose({board:base,active:d.adjusted},18);for(const[b,a]of [[base,d.def],[base,d.adjusted],[first,next]]){if(!fits(b,a)||fits(b,{...a,y:a.y+1}))throw Error(d.key+' invalid landing '+JSON.stringify(a));}
 const occupied=new Set([d.adjusted,next].flatMap(a=>C.cells(a.type,a.rotation).map(([x,y])=>[a.x+x,a.y+y].join(',')))),stack=base.slice(18-d.source.length).map((row,i)=>row.map((c,x)=>c==='.'?'.':[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>occupied.has([x+dx,i+18-d.source.length+dy].join(',')))?'s':'S').join(''));
 const raw=C.clone(template);Object.assign(raw,{title:d.title,chapter:'Adjustments',section:'VITS',description:d.description,stack,adjustment:{default:d.def,adjusted:d.adjusted,next},motionVerified:true});raw.frames=raw.frames.filter(f=>f.lessonStage<5);
 for(const f of raw.frames){if(f.active)f.active=pose('L',3,0,0);if(f.ghost){const label=f.ghost.label;f.ghost={...(label==='Default'?d.def:label==='Next'?next:d.adjusted),label};}if(f.referenceGhost)f.referenceGhost={...d.adjusted,label:'Adjusted'};if(f.step==='4')f.caption=d.description;if(f.step==='4a')f.caption='The I ghost shows the final tuck underneath L.';}
 let board=base;
 for(let n=0;n<2;n++){const target=n?next:d.adjusted,stage=5+n,spawn=pose(target.type,3,0,0),pre={...target,x:target.x-1},route=legalPath(board,pre);if(!route)throw Error(d.key+' unreachable approach');if(true){if(!fits(board,target))throw Error('Blocked I tuck');route.push('right');}
  raw.frames.push({step:String(stage),lessonStage:stage,ticks:2,rows:delta(board,base),active:spawn,next:'I',showNext:!n,highlight:false,caption:n?'Bring in I, ready for the tuck.':'Place L above the channel.'});
  let active=spawn,k=0,groups=[];for(const input of route){const last=groups.at(-1);if(last?.input===input&&['left','right','down'].includes(input))last.count++;else groups.push({input,count:1});}
  for(const g of groups){const from={...active};for(let i=0;i<g.count;i++)active=move(active,g.input);raw.frames.push({step:String(stage)+String.fromCharCode(97+k++),lessonStage:stage,ticks:Math.max(24,g.count*6),active:{...active},animationFrom:from,animate:true,fallFirst:g.input==='down'?g.count:0,buttons:g.input==='down'?[]:[{left:'Left',right:'Right',a:'A',b:'B'}[g.input]],next:'I',showNext:!n,highlight:false,caption:g.input==='right'?(n?'Press Right once to tuck I under L.':'Press Right once to tuck L beneath the overhang.'):g.input==='down'?'Let gravity lower '+target.type+'.':g.input==='a'||g.input==='b'?'Press '+g.input.toUpperCase()+' to turn '+target.type+'.':'Move '+target.type+' '+g.input+'.'});}
  board=C.compose({board,active:target},18);if(C.fullRows(board).length)throw Error('Unexpected clear');
 }
 const overrides=C.cells('I',next.rotation).map(([x,y],i)=>({x:x+next.x,y:y+next.y,tile:C.pieceLayout('I',next.rotation)[i][2]}));
 raw.frames.push({step:'7',lessonStage:7,ticks:96,rows:delta(board,base),tileOverrides:overrides,placementHighlights:[d.adjusted,next],placementBlink:true,highlight:false,showNext:false,caption:'The first tuck set up the I tuck. The left well stays open for a Tetris.'},{step:'7a',lessonStage:7,ticks:96,tileOverrides:overrides,motif:true,blink:true,highlight:false,showNext:false,caption:'Notice how L leaves space for the vertical I tuck.'});generated.push([d.key,raw]);
}
let p=r+'/core.js',s=fs.readFileSync(p,'utf8').replace("'Dicey','Memes/Anti-Adjustments']","'Dicey','Memes/Anti-Adjustments','VITS']");fs.writeFileSync(p,s);

for(const[key,raw]of generated)fs.writeFileSync(r+'/situations/'+key+'.js','// VITS reference mirrored horizontally from NES to Game Boy.\n(function(root){\nconst situation = '+JSON.stringify(raw,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
p=r+'/course.js';s=fs.readFileSync(p,'utf8').replace("['Memes/Anti-Adjustments','Memes / Anti-Adjustments']]", "['Memes/Anti-Adjustments','Memes / Anti-Adjustments'],['VITS','VITS']]");fs.writeFileSync(p,s);
p=r+'/situations.js';s=fs.readFileSync(p,'utf8').replace(/const names = (\[[\s\S]*?\]);/,(_,list)=>'const names = '+JSON.stringify([...JSON.parse(list),...definitions.map(d=>d.key)],null,2)+';');fs.writeFileSync(p,s);
p=r+'/index.html';s=fs.readFileSync(p,'utf8').replace('<script src="situations.js"',definitions.map(d=>'<script src="situations/'+d.key+'.js" defer></script>').join('')+'<script src="situations.js"');fs.writeFileSync(p,s);
for(const name of ['core.test.cjs','app.test.cjs']){p=r+'/'+name;s=fs.readFileSync(p,'utf8').replaceAll('C.parseCollection(demo).length,236','C.parseCollection(demo).length,236').replaceAll("libraryCount.textContent,'236'","libraryCount.textContent,'236'").replaceAll('h.cards().length,235','h.cards().length,231').replace("['Good','Good but Situational','Dicey','Memes/Anti-Adjustments']", "['Good','Good but Situational','Dicey','Memes/Anti-Adjustments','VITS']").replace("['Good','Good but situational','Dicey','Memes / Anti-Adjustments']", "['Good','Good but situational','Dicey','Memes / Anti-Adjustments','VITS']").replace('good.children.length,57','good.children.length,56');fs.writeFileSync(p,s);}
console.log('Added four Australian VITS lessons.');
