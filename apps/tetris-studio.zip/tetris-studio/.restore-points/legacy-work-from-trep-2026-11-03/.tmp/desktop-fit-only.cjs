const fs=require('fs'),file='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio/studio.css';
fs.appendFileSync(file,`

/* Desktop fit only: retain component appearance and reserve space for transport. */
@media(min-width:1000px){
 :root{--desktop-board-width:clamp(144px,calc((100dvh - 300px)/2.03),288px)}
 main{height:100dvh;padding:16px 20px;display:flex;flex-direction:column;overflow:hidden}
 .page-heading{flex-shrink:0;width:100%;margin-bottom:12px}
 .workspace{flex:1;min-height:0;width:100%;margin:0 auto}
 .preview{height:100%;min-height:0;display:flex;flex-direction:column}
 .study-heading{flex-shrink:0;min-height:30px}
 .board-player{flex:1;min-height:0;width:100%;max-width:100%;grid-template-columns:var(--desktop-board-width) minmax(0,1fr);gap:20px;margin:12px auto 0;align-content:start}
 .player-column{width:var(--desktop-board-width);min-height:0;gap:6px}
 .player-column .board-hardware{flex-shrink:0}
 .player-column .transport{padding:0}
 .player-column .transport-buttons{grid-template-columns:28px minmax(0,1fr) 28px;gap:4px}
 .player-column .transport-buttons button{min-width:0;padding:4px 2px;font-size:11px}
 .attempt-actions{gap:4px}.attempt-actions button{padding:4px;font-size:10px;min-height:28px}
 #playAttemptStatus{font-size:11px;margin:5px 0}
 .opener-preview-mode .board-player{grid-template-columns:var(--desktop-board-width)}
 .board-player>.spin-summary{min-width:0;max-height:100%;overflow-y:auto}
 .spin-summary>.step-explanation{height:clamp(100px,calc(100dvh - 480px),160px);min-height:0;margin-top:10px}
 .library{padding:16px;gap:8px}#situationList{min-height:0}
 .course-introduction-panel{min-height:0;overflow-y:auto;margin:12px auto}
 .board-level-picker{justify-content:flex-start;gap:5px;padding:8px}
 .board-level-picker h3{font-size:14px}.board-level-picker>label{display:none}
 .board-level-picker .level-pad{gap:3px}.board-level-picker .level-pad button{min-width:0;min-height:20px;padding:0;font-size:10px}
 .board-level-picker .level-speed-group.shared{padding:0}
 .board-level-picker>button{min-width:0;min-height:24px;padding:2px 8px;font-size:11px}
}
@media(min-width:1000px) and (max-height:740px){
 .board-player>.spin-summary>ol{grid-template-columns:14px minmax(0,130px) 40px;gap:2px 5px}
 .board-player>.spin-summary li span{min-height:28px;font-size:12px;line-height:1.2}
 .board-player>.spin-summary li canvas{width:40px;height:30px}
}
`);
console.log('Added desktop sizing rules only; button colors and component styling preserved.');
