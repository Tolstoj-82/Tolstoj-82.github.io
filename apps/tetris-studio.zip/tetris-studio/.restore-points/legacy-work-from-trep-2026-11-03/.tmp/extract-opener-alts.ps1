Add-Type -AssemblyName System.Drawing
$im=[Drawing.Bitmap]::FromFile('C:\Users\marti\AppData\Local\Temp\codex-clipboard-ea89880a-d75a-43de-829d-0ad4400b0744.png')
$rects=@(@('IL',584,271,667,324),@('IS',1180,283,1264,334),@('JJ',783,837,863,886),@('ZI',188,1435,276,1492),@('ZL',584,1435,667,1495),@('ZJ',783,1432,877,1491),@('ZT',981,1435,1070,1493))
$output=@()
foreach($spec in $rects){$x0=[int]$spec[1];$y0=[int]$spec[2];$w=[int]$spec[3]-$x0;$h=[int]$spec[4]-$y0;$mask=New-Object 'bool[]' ($w*$h);for($y=0;$y -lt $h;$y++){for($x=0;$x -lt $w;$x++){$p=$im.GetPixel($x0+$x,$y0+$y);$mask[$y*$w+$x]=($p.R -gt 180 -and $p.G -gt 180 -and $p.B -gt 180) -or ($p.B -gt 180 -and $p.R -lt 100) -or ($p.R -gt 180 -and $p.G -lt 150 -and $p.B -lt 100)}};$boxes=@();for($y=0;$y -lt $h;$y++){for($x=0;$x -lt $w;$x++){$idx=$y*$w+$x;if(!$mask[$idx]){continue};$mask[$idx]=$false;$q=[Collections.Generic.Queue[int]]::new();$q.Enqueue($idx);$minX=$x;$maxX=$x;$minY=$y;$maxY=$y;$count=0;while($q.Count){$v=$q.Dequeue();$vx=$v%$w;$vy=[int][Math]::Floor($v/$w);$minX=[Math]::Min($minX,$vx);$maxX=[Math]::Max($maxX,$vx);$minY=[Math]::Min($minY,$vy);$maxY=[Math]::Max($maxY,$vy);$count++;foreach($dy in -1..1){foreach($dx in -1..1){$nx=$vx+$dx;$ny=$vy+$dy;if($nx -lt 0 -or $nx -ge $w -or $ny -lt 0 -or $ny -ge $h){continue};$ni=$ny*$w+$nx;if($mask[$ni]){$mask[$ni]=$false;$q.Enqueue($ni)}}}};if($maxX-$minX -gt 2 -and $maxY-$minY -gt 2){$cp=$im.GetPixel([int](($minX+$maxX)/2+$x0),[int](($minY+$maxY)/2+$y0));$boxes+=,@(($minX+$x0),($minY+$y0),($maxX+$x0),($maxY+$y0),$count,$cp.R,$cp.G,$cp.B)}}};$output+=@{key=$spec[0];rect=@($x0,$y0,$w,$h);boxes=$boxes};}
$output | ConvertTo-Json -Depth 8 | Set-Content '.tmp/opener-alt-components.json'
$im.Dispose()



