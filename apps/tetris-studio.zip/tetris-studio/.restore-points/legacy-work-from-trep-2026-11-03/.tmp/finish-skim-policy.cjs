const fs=require('node:fs'),path=require('node:path'),base=path.resolve('../tetris-studio');
const file=path.join(base,'js/placement-hint.js');let s=fs.readFileSync(file,'utf8');
s=s.replace('const doubleWell=skim?Math.min(3,doubleDepth)*12-Math.max(0,doubleDepth-3)**2*5:0;','const doubleWell=skim||ctx.fast?Math.min(3,doubleDepth)*18-Math.max(0,doubleDepth-3)**2*5:0;');
s=s.replace('+(f.ready?(skim?6:38):0)+Math.min(4,f.readyRows)*(skim?1:5)-f.missing*(skim?.15:.9);','+(f.ready?(skim||ctx.fast?6:38):0)+Math.min(4,f.readyRows)*(skim||ctx.fast?1:5)-f.missing*(skim||ctx.fast?.15:.9);');fs.writeFileSync(file,s);
const test=path.join(base,'tests/placement-hint.test.cjs');fs.appendFileSync(test,`
// Fast play must burn before the lateral movement ceiling, not at top-out height.
const skimBoard=heightsBoard([0,0,5,5,5,5,5,5,5,5]);
assert.equal(H.context(skimBoard,{gravityFrames:3}).mode,'skim');
assert.equal(H.context(skimBoard,{gravityFrames:3}).skimHeight,5);
assert.equal(H.context(heightsBoard([0,0,7,7,7,7,7,7,7,7]),{gravityFrames:3}).mode,'survival');
assert.equal(H.context(skimBoard,{gravityFrames:53}).mode,'tetris','ordinary speed keeps its Tetris policy');
assert.equal(H.context(C.empty(18),{gravityFrames:2}).skimHeight,4);
assert.equal(H.context(C.empty(18),{gravityFrames:1}).skimHeight,3);
for(const type of ['O','L','J']){const s=snapshot(type,'O',3,skimBoard),hint=H.compute(s);assert(hint.cleared>0,type+' must take the reachable double-well skim at five rows');const after=H.apply(s.board,hint.placement);assert.equal(H.features(after.board).holes,0);assert(H.features(after.board).max<5);replay(s,hint.placement,hint.plan);}
const openDouble=heightsBoard([0,0,3,3,3,3,3,3,3,3]);assert.equal(H.context(openDouble,{gravityFrames:3}).mode,'skim','keep reducing an established double well');
const lowCtx=H.context(C.empty(18),{gravityFrames:3});assert(H.evaluate(heightsBoard([0,0,4,4,4,4,4,4,4,4]),lowCtx)>H.evaluate(heightsBoard([0,4,4,4,4,4,4,4,4,4]),lowCtx),'K should prepare the double well before the height trigger');
assert(H.reward(2,H.context(skimBoard,{gravityFrames:3}))>H.reward(2,H.context(skimBoard,{gravityFrames:53})));
assert.equal(H.safeSkim(skimBoard,{cleared:1,board:heightsBoard([0,0,6,6,6,6,6,6,6,6])},H.context(skimBoard,{gravityFrames:3})),false);
console.log('PASS early K skims, shallow double-well preparation, speed-dependent thresholds and native burn routes');
`);
const doc=path.join(base,'docs/AUTOPLAY.md');fs.appendFileSync(doc,'\nAt K (three frames per row), the advisor favours a shallow double well and starts skimming at a peak of five rows, with stronger recovery from seven rows. An existing useful double well can continue to be skimmed from three rows. L and M use earlier triggers of four and three rows respectively. Safe reachable singles, doubles and triples take priority over adding height; immediate reachable Tetrises are still taken. Both the full current/next search and provisional autoplay use this policy. Thresholds reserve movement time under the lower GB spawn, but the heuristic does not guarantee survival, especially at training speeds.\n');
console.log('Updated K preparation, regression tests and autoplay documentation');
