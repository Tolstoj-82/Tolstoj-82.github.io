const fs=require('node:fs');const p='../tetris-studio/assets/css/studio.css';let css=fs.readFileSync(p,'utf8');
css=css.replace('.course-introduction .study-actions,.opener-preview-mode .study-actions,','.course-introduction .study-actions,');
css=css.replace('max-width:1080px;grid-template-columns:var(--free-board-width) minmax(130px,1fr) minmax(130px,1fr);','max-width:1080px;grid-template-columns:var(--free-board-width) minmax(130px,240px) minmax(130px,240px);');
fs.writeFileSync(p,css);console.log('Kept opener editing available and bounded diagnostic panel widths.');
