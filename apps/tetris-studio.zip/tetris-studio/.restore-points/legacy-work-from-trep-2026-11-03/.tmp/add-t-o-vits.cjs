const fs=require('fs');
const definitions=[
 {key:'adjustment-vits-t-east',title:'VITS · T East',source:['SSSSSSS...','SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],def:{type:'T',x:5,y:11,rotation:2},adjusted:{type:'T',x:1,y:12,rotation:1},description:'Stand T with its spike pointing left, filling the step while leaving a roof for I. Lower I at the wall and tuck it right underneath to get Tetris ready.'},
 {key:'adjustment-vits-t-south',title:'VITS · T South',source:['SS..SS....','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],def:{type:'T',x:2,y:11,rotation:3},adjusted:{type:'T',x:1,y:12,rotation:2},description:'Turn T with its spike up and lay its three-wide base across the lower step. The next I tucks right beneath the left end.'},
 {key:'adjustment-vits-o-north',title:'VITS · O North',source:['......S...','.S.S.SS...','SSSSSSS...','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..','SSSSSSSS..'],def:{type:'O',x:-1,y:15,rotation:0},adjusted:{type:'O',x:0,y:11,rotation:0},description:'Place O on the shelf beside the left well instead of burning it at the bottom. This leaves space for I to descend at the wall and tuck right beneath O.'}
];
let script=fs.readFileSync('.tmp/add-vits-section.cjs','utf8'),first=script.indexOf('definitions=['),end=script.indexOf('\n];',first);script=script.slice(0,first)+'definitions='+JSON.stringify(definitions,null,2)+script.slice(end+2);
script=script.replace("pose('L',3,0,0)","pose(d.adjusted.type,3,0,0)").replace("f.caption='The I ghost shows the final tuck underneath L.'", "f.caption='The I ghost shows the final tuck underneath '+d.adjusted.type+'.'");
script=script.replace("'Place L above the channel.'", "'Place '+d.adjusted.type+' above the channel.'").replace("'Press Right once to tuck I under L.'", "'Press Right once to tuck I under '+d.adjusted.type+'.'");
script=script.replace("template.section='VITS';generated.unshift(['adjustment-vits-palito',template]);",'');
const tests=script.indexOf("for(const name of ['core.test.cjs','app.test.cjs'])");script=script.slice(0,tests)+"console.log('Added three mirrored T/O VITS lessons.');\n";
fs.writeFileSync('.tmp/add-t-o-vits-generated.cjs',script);
