const fs=require('fs'),r='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio',C=require(r+'/core.js'),{path:legalPath,fits}=require('./audit-course-paths.cjs');
const pose=(type,x,y,rotation)=>({type,x,y,rotation}),definitions=[
  {
    "key": "adjustment-vits-t-east",
    "title": "VITS · T East",
    "source": [
      "SSSSSSS...",
      "SSSSSSS...",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS.."
    ],
    "def": {
      "type": "T",
      "x": 5,
      "y": 11,
      "rotation": 2
    },
    "adjusted": {
      "type": "T",
      "x": 1,
      "y": 12,
      "rotation": 1
    },
    "description": "Stand T with its spike pointing left, filling the step while leaving a roof for I. Lower I at the wall and tuck it right underneath to get Tetris ready."
  },
  {
    "key": "adjustment-vits-t-south",
    "title": "VITS · T South",
    "source": [
      "SS..SS....",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS.."
    ],
    "def": {
      "type": "T",
      "x": 2,
      "y": 11,
      "rotation": 3
    },
    "adjusted": {
      "type": "T",
      "x": 1,
      "y": 12,
      "rotation": 2
    },
    "description": "Turn T with its spike up and lay its three-wide base across the lower step. The next I tucks right beneath the left end."
  },
  {
    "key": "adjustment-vits-o-north",
    "title": "VITS · O North",
    "source": [
      "......S...",
      ".S.S.SS...",
      "SSSSSSS...",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS..",
      "SSSSSSSS.."
    ],
    "def": {
      "type": "O",
      "x": -1,
      "y": 15,
      "rotation": 0
    },
    "adjusted": {
      "type": "O",
      "x": 0,
      "y": 11,
      "rotation": 0
    },
    "description": "Place O on the shelf beside the left well instead of burning it at the bottom. This leaves space for I to descend at the wall and tuck right beneath O."
  }
];
const template=C.clone(require(r+'/situations/adjustment-vits-palito.js')),delta=(b,a)=>Object.fromEntries(b.map((row,y)=>[y,row.join('')]).filter(([y,row])=>row!==a[y].join(''))),move=(a,input)=>({...a,x:a.x+(input==='left'?-1:input==='right'?1:0),y:a.y+(input==='down'?1:0),rotation:(a.rotation+(input==='a'?3:input==='b'?1:0))%4});
const generated=[];
for(const d of definitions){const next=pose('I',0,14,1),base=C.empty(18-d.source.length).concat(d.source.map(row=>[...row].reverse().map(c=>c==='S'?'L':'.'))),first=C.compose({board:base,active:d.adjusted},18);for(const[b,a]of [[base,d.def],[base,d.adjusted],[first,next]]){if(!fits(b,a)||fits(b,{...a,y:a.y+1}))throw Error(d.key+' invalid landing '+JSON.stringify(a));}
 const occupied=new Set([d.adjusted,next].flatMap(a=>C.cells(a.type,a.rotation).map(([x,y])=>[a.x+x,a.y+y].join(',')))),stack=base.slice(18-d.source.length).map((row,i)=>row.map((c,x)=>c==='.'?'.':[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>occupied.has([x+dx,i+18-d.source.length+dy].join(',')))?'s':'S').join(''));
 const raw=C.clone(template);Object.assign(raw,{title:d.title,chapter:'Adjustments',section:'VITS',description:d.description,stack,adjustment:{default:d.def,adjusted:d.adjusted,next},motionVerified:true});raw.frames=raw.frames.filter(f=>f.lessonStage<5);
 for(const f of raw.frames){if(f.active)f.active=pose(d.adjusted.type,3,0,0);if(f.ghost){const label=f.ghost.label;f.ghost={...(label==='Default'?d.def:label==='Next'?next:d.adjusted),label};}if(f.referenceGhost)f.referenceGhost={...d.adjusted,label:'Adjusted'};if(f.step==='4')f.caption=d.description;if(f.step==='4a')f.caption='The I ghost shows the final tuck underneath '+d.adjusted.type+'.';}
 let board=base;
 for(let n=0;n<2;n++){const target=n?next:d.adjusted,stage=5+n,spawn=pose(target.type,3,0,0),pre=n?{...target,x:target.x-1}:target,route=legalPath(board,pre);if(!route)throw Error(d.key+' unreachable approach');if(n){if(!fits(board,target))throw Error('Blocked I tuck');route.push('right');}
  raw.frames.push({step:String(stage),lessonStage:stage,ticks:2,rows:delta(board,base),active:spawn,next:'I',showNext:!n,highlight:false,caption:n?'Bring in I, ready for the tuck.':'Place '+d.adjusted.type+' above the channel.'});
  let active=spawn,k=0,groups=[];for(const input of route){const last=groups.at(-1);if(last?.input===input&&['left','right','down'].includes(input))last.count++;else groups.push({input,count:1});}
  for(const g of groups){const from={...active};for(let i=0;i<g.count;i++)active=move(active,g.input);raw.frames.push({step:String(stage)+String.fromCharCode(97+k++),lessonStage:stage,ticks:Math.max(24,g.count*6),active:{...active},animationFrom:from,animate:true,fallFirst:g.input==='down'?g.count:0,buttons:g.input==='down'?[]:[{left:'Left',right:'Right',a:'A',b:'B'}[g.input]],next:'I',showNext:!n,highlight:false,caption:n&&g.input==='right'?'Press Right once to tuck I under '+d.adjusted.type+'.':g.input==='down'?'Let gravity lower '+target.type+'.':g.input==='a'||g.input==='b'?'Press '+g.input.toUpperCase()+' to turn '+target.type+'.':'Move '+target.type+' '+g.input+'.'});}
  board=C.compose({board,active:target},18);if(C.fullRows(board).length)throw Error('Unexpected clear');
 }
 const overrides=C.cells('I',next.rotation).map(([x,y],i)=>({x:x+next.x,y:y+next.y,tile:C.pieceLayout('I',next.rotation)[i][2]}));
 raw.frames.push({step:'7',lessonStage:7,ticks:96,rows:delta(board,base),tileOverrides:overrides,placementHighlights:[d.adjusted,next],placementBlink:true,highlight:false,showNext:false,caption:'Four rows are ready for a Tetris; the left well stays open.'},{step:'7a',lessonStage:7,ticks:96,tileOverrides:overrides,motif:true,blink:true,highlight:false,showNext:false,caption:'Notice how L leaves space for the vertical I tuck.'});generated.push([d.key,raw]);
}
let p=r+'/core.js',s=fs.readFileSync(p,'utf8').replace("'Dicey','Memes/Anti-Adjustments']","'Dicey','Memes/Anti-Adjustments','VITS']");fs.writeFileSync(p,s);

for(const[key,raw]of generated)fs.writeFileSync(r+'/situations/'+key+'.js','// VITS reference mirrored horizontally from NES to Game Boy.\n(function(root){\nconst situation = '+JSON.stringify(raw,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
p=r+'/course.js';s=fs.readFileSync(p,'utf8').replace("['Memes/Anti-Adjustments','Memes / Anti-Adjustments']]", "['Memes/Anti-Adjustments','Memes / Anti-Adjustments'],['VITS','VITS']]");fs.writeFileSync(p,s);
p=r+'/situations.js';s=fs.readFileSync(p,'utf8').replace(/const names = (\[[\s\S]*?\]);/,(_,list)=>'const names = '+JSON.stringify([...JSON.parse(list),...definitions.map(d=>d.key)],null,2)+';');fs.writeFileSync(p,s);
p=r+'/index.html';s=fs.readFileSync(p,'utf8').replace('<script src="situations.js"',definitions.map(d=>'<script src="situations/'+d.key+'.js" defer></script>').join('')+'<script src="situations.js"');fs.writeFileSync(p,s);
console.log('Added three mirrored T/O VITS lessons.');
