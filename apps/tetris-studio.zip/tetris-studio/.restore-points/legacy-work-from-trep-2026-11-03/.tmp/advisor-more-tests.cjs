const fs=require('node:fs'),p='../tetris-studio/tests/placement-hint.test.cjs';fs.appendFileSync(p,`
// The forecast uses the GB rejection rule, verified independently through RomRandom.
for(const current of F.ORDER)for(const next of F.ORDER){
 const counts=Array(7).fill(0);
 for(let v=0;v<343;v++){const draws=[v%7,Math.floor(v/7)%7,Math.floor(v/49)],r=new F.RomRandom({preview:F.ORDER.indexOf(current)<<2,hidden:F.ORDER.indexOf(next)<<2,readDivider:()=>draws.shift()+1});r.select();counts[r.hidden>>2]++;}
 const distribution=H.futureProbabilities(current,next);assert(Math.abs(distribution.reduce((a,b)=>a+b.weight,0)-1)<1e-12);
 distribution.forEach((p,i)=>assert(Math.abs(p.weight-counts[i]/343)<1e-12,current+' '+next+' '+p.type));
}
const futures=H.futureScenarios('T','L');assert.equal(futures.length,14);assert.equal(new Set(futures.map(s=>s.pieces[0])).size,7);assert(Math.abs(futures.reduce((n,s)=>n+s.weight,0)-1)<1e-12);assert(futures.every(s=>s.pieces.length===2));
console.log('PASS future weights match all 49 GB OR states under independent uniform candidate reads');
// A high-scoring current move must not consume the whole beam with preview variants.
const fake=[];for(let x=0;x<6;x++)for(let n=0;n<30;n++)fake.push({placement:{x,y:16,rotation:0},value:1000-x*100-n});const diverse=H.diverseShortlist(fake,5,2);assert.equal(diverse.length,10);assert.equal(new Set(diverse.map(p=>p.placement.x)).size,5);for(let x=0;x<5;x++)assert.equal(diverse.filter(p=>p.placement.x===x).length,2);
const slow=H.compute(snapshot('T','O'));assert.equal(slow.searchStats.futureDepth,2);assert.equal(slow.searchStats.scenarios,14);assert(slow.searchStats.distinctCurrentMoves>1);assert(slow.searchStats.branches>0);assert(slow.searchStats.cacheHits>0);
const fast=H.compute(snapshot('T','O',1));assert.equal(fast.searchStats.futureDepth,1);assert.equal(fast.searchStats.scenarios,7);assert(fast.searchStats.branches>0);
console.log('PASS diverse current-move pruning, multi-step future simulation, caching and faster training budget');
// With a high stack, a useful double-well burn must beat refusing to reduce height.
const danger=C.empty(18);for(let y=4;y<18;y++)for(let x=2;x<10;x++)danger[y][x]='L';
const rescue=snapshot('O','T',53,danger),rescueHint=H.compute(rescue);assert.equal(rescueHint.searchStats.mode,'survival');assert.equal(rescueHint.cleared,2);replay(rescue,rescueHint.placement,rescueHint.plan);
const dirty=C.empty(18);dirty[17][3]='L';dirty[15][3]='L';assert.equal(H.context(dirty).mode,'dig');assert.equal(H.context(C.empty(18)).mode,'tetris');
console.log('PASS context-sensitive recovery and a necessary tactical double burn');
`);console.log('Added forecast-model, search-diversity and recovery regressions.');
