const fs=require('node:fs'),root='../tetris-studio/';const p=root+'js/placement-hint.js';let s=fs.readFileSync(p,'utf8');
s=s.replace('hiddenRows=null,tapFrames=5}={})','hiddenRows=null,tapFrames=5,record=true}={})');
s=s.replace('inputs.push(action);positions.push({...a});','if(record){inputs.push(action);positions.push({...a});}');
s=s.replace("return same(a,target)?{inputs,positions,frames:inputs.length}:null;","return same(a,target)?{inputs,positions,frames:frame+1}:null;");
s=s.replaceAll('{...timing,elapsedFrames:0,hiddenRows}', '{...timing,elapsedFrames:0,hiddenRows,record:false}');
s=s.replace('const groups=diverseShortlist(pairs,first.length,2),secondPlans=new Map(),valid=[];', 'const grouped=new Map();for(const p of [...pairs].sort((a,b)=>b.value-a.value)){const k=key(p.placement);if(!grouped.has(k))grouped.set(k,[]);grouped.get(k).push(p);}const valid=[];');
const a=s.indexOf('  for(const p of groups){'),b=s.indexOf('  // If no shortlisted preview',a);if(a<0||b<0)throw Error('Known-piece beam not found');
s=s.slice(0,a)+`  for(const group of grouped.values()){
   let retained=0;
   for(const p of group){
    if(currentTetris&&p.after.cleared!==4)continue;
    if(p.next&&!plan(p.after.board,spawn[nextPiece],p.next,{...timing,gravityFrames:p.nextGravity,elapsedFrames:0,record:false})){yield;continue;}
    p.value+=accommodation(p.result.board)*9;valid.push(p);yield;if(++retained===2)break;
   }
  }
`+s.slice(b);
s=s.replace('let branches=0;', 'let branches=0,cacheHits=0;const rolloutCache=new Map();');
s=s.replace('const step=rolloutStep(futureBoard,type,futureState,hiddenRows,ctx);branches++;',"const cacheKey=type+'|'+futureState.gravityFrames+'|'+futureBoard.map(row=>row.map(c=>c==='.'?'.':'#').join('')).join('/');let step;if(rolloutCache.has(cacheKey)){step=rolloutCache.get(cacheKey);cacheHits++;}else{step=rolloutStep(futureBoard,type,futureState,hiddenRows,ctx);rolloutCache.set(cacheKey,step);}branches++;");
s=s.replace("scenarios:scenarios.length,branches,model:","scenarios:scenarios.length,branches,cacheHits,model:");
fs.writeFileSync(p,s);
const ui=root+'js/playable.js';fs.writeFileSync(ui,fs.readFileSync(ui,'utf8').replace('hintResult.placement,snapshot)?','hintResult.placement,{...snapshot,record:false})?'));
fs.copyFileSync(root+'fixtures/placement-hint-strategy-audit.json',root+'fixtures/placement-hint-strategy-baseline.json');
console.log('Optimized route validation and cached future states; retained verified preview diversity.');
