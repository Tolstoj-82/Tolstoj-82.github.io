const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const variant of ['well','center']){
 const x=variant==='well'?0:4,s=structuredClone(require(path.join(root,'situations/s-spuck-'+variant+'.js')));s.title='Z-Spuck ('+variant+')';s.piece='Z';
 const rows=variant==='well'?['..SSSSSSSS','..SSSSSSSS','..sSSSSSSS','...ssSSSSS','....sSSSSS']:['SSSS..SSSS','SSSS..SSSS','SSSS..sSSS','SSSS...ssS','SSSS....sS'];
 const b=rows.map(r=>[...r]);for(const a of [{x,y:15,rotation:1},{x,y:15,rotation:0},{x:x+1,y:15,rotation:0}])for(const[dx,dy]of C.cells('Z',a.rotation)){if(!['.',','].includes(b[a.y+dy-13][a.x+dx]))throw Error('overlap');b[a.y+dy-13][a.x+dx]=',';}
 s.stack=b.map(r=>r.join(''));for(const f of s.frames){f.caption=f.caption.replaceAll('S piece','Z piece').replaceAll('the S','the Z').replaceAll('The S','The Z');}
 s.frames[1].caption='1a · The staircase minos shown in white in the reference form the motif.';
 for(const f of s.frames.slice(3,6))f.active={x,y:15,rotation:1};s.frames[4].trigger={hole:[x+2,16],button:'B'};
 for(const f of s.frames.slice(6,8))f.active={x,y:15,rotation:0};s.frames[8].active={x:x+1,y:15,rotation:0};
 const key='z-spuck-'+variant;fs.writeFileSync(path.join(root,'situations',key+'.js'),'(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"s-spuck-center"\n','"s-spuck-center",\n  "z-spuck-well",\n  "z-spuck-center"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/z-spuck-well.js"></script><script src="situations/z-spuck-center.js"></script><script src="situations.js">'));
edit('app.js',s=>s.replace("(situationKey(s).startsWith('s-spuck-')?'S-Spucks':'T-Spucks')","(situationKey(s).split('-')[0].toUpperCase()+'-Spucks')"));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'25'","libraryCount.textContent,'27'").replace('h.cards().length,24','h.cards().length,26').replace('categories[1].children.length,3','categories[1].children.length,4').replace(" await test('Spins and Spucks",` await test('Z-Spucks clean playback has one right tuck and collision-free positions',()=>{
  for(const variant of ['well','center']){const h=boot(undefined,'file:///C:/tetris/index.html?situation=z-spuck-'+variant);h.elements.cleanPlayback.checked=true;h.change('cleanPlayback',true);const s=h.exported();assert.equal(s.frames.filter(f=>f.buttons.includes('Right')).length,variant==='well'?1:2);
   for(const f of s.frames){const stack=h.context.TetrisCore.compose({...f,active:undefined},18);for(const[x,y]of h.context.TetrisCore.cells('Z',f.active.rotation))assert.equal(stack[f.active.y+y][f.active.x+x],'.');}
  }
 });
 await test('Spins and Spucks`));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,25','C.parseCollection(demo).length,27')+`
test('Z-Spucks use the staircase stack motif, either rotation, and one right tuck',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('Z-Spuck'));assert.equal(variants.length,2);
 for(const s of variants){assert.equal(s.frames[1].motif.cells.length,4);assert.deepEqual(s.frames[5].buttonOptions,['B','A']);assert.deepEqual(s.frames[8].buttons,['Right']);assert.equal(s.frames[8].active.x,s.frames[6].active.x+1);
  for(const f of s.frames.filter(f=>f.animate)){const stack=C.compose({...f,active:undefined},18);for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells('Z',a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}}
  assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
