(function(root){
'use strict';
const C=typeof module!=='undefined'?require('./core.js'):root.TetrisCore,H=typeof module!=='undefined'?require('./placement-hint.js'):root.TetrisPlacementHint;
const copy=v=>C.clone(v),same=(a,b)=>a&&b&&a.type===b.type&&a.x===b.x&&a.y===b.y&&a.rotation===b.rotation;
class AutoPlayer{
 constructor(game,{clientFactory=(receive,fail)=>H.createClient(receive,fail),onChange=()=>{}}={}){if(!game.freePlay||game.observed)throw Error('Autoplay requires a simulated Free play game.');this.game=game;this.onChange=onChange;this.phase='idle';this.token=0;this.disposed=false;this.remainder=0;this.pulse=0;this.target=null;this.wasFrozen=!!game.practiceFrozen;this.originalSpawn=game.onSpawn;this.spawnHook=()=>{this.originalSpawn?.call(game);this.begin();};game.onSpawn=this.spawnHook;this.client=clientFactory((result,snapshot)=>this.receive(result,snapshot),()=>this.receive(null,{autoplayToken:this.token}));}
 begin(){if(this.disposed)return;const g=this.game;if(g.done){this.phase='done';return;}if(!g.active){this.phase='entry';return;}this.client.stop();this.token++;this.target=null;this.route=null;this.index=0;this.remainder=0;this.pulse=0;this.action=null;this.phase='searching';g.practiceFrozen=true;this.timing=g.gravity;this.client.request({board:copy(g.board),hiddenRows:copy(g.hiddenRows),active:copy(g.active),nextPiece:g.nextPiece,gravityFrames:Math.round(g.gravity*C.HZ/1000),elapsedFrames:g.elapsed*C.HZ/1000,level:g.level,heart:g.heart,lines:g.lines,autoplayToken:this.token});this.onChange('searching');}
 receive(result,snapshot){if(this.disposed||this.phase!=='searching'||snapshot.autoplayToken!==this.token)return;const g=this.game,route=result?.placement&&H.plan(g.board,g.active,result.placement,{gravityFrames:Math.round(g.gravity*C.HZ/1000),elapsedFrames:g.elapsed*C.HZ/1000,hiddenRows:g.hiddenRows});g.practiceFrozen=false;if(!route){this.phase='unavailable';this.onChange('unavailable');return;}this.target=copy(result.placement);this.route=route;this.index=0;this.phase='playing';this.onChange('ready');}
 advance(ms){if(this.disposed)return;const g=this.game;if(this.phase==='searching'){this.remainder=0;return;}if(g.done){this.phase='done';this.target=null;return;}if(g.active&&this.phase==='playing'&&g.gravity!==this.timing){this.begin();return;}this.remainder+=Math.max(0,ms)*C.HZ/1000;const frameMs=1000/C.HZ;
  while(this.remainder+1e-9>=1){this.remainder=Math.max(0,this.remainder-1);if(this.phase==='searching'||this.disposed){this.remainder=0;return;}if(this.pulse>0)this.pulse--;if(g.done){this.phase='done';this.target=null;return;}
   if(g.pendingPiece||!g.active){g.onInputFrame?.({down:false,horizontal:false});g.advance(frameMs);continue;}
   if(this.phase!=='playing'||!this.route||this.index>=this.route.inputs.length){this.begin();return;}const action=this.route.inputs[this.index],expected=this.route.positions[this.index];g.onInputFrame?.({down:false,horizontal:action==='left'||action==='right'});if(action){if(!['left','right','a','b'].includes(action)||!g.input(action)){this.begin();return;}this.action=action;this.pulse=3;}g.advance(frameMs);this.index++;
   if(g.pendingPiece||g.done){this.phase=g.done?'done':'entry';this.target=null;continue;}if(!same(g.active,expected)){this.begin();return;}
  }
 }
 buttons(){return this.pulse>0&&this.action?[{left:'Left',right:'Right',a:'A',b:'B'}[this.action]]:[];}
 dispose(){if(this.disposed)return;this.disposed=true;this.token++;this.client.stop();if(this.game.onSpawn===this.spawnHook){if(this.originalSpawn)this.game.onSpawn=this.originalSpawn;else delete this.game.onSpawn;}if(this.phase==='searching')this.game.practiceFrozen=this.wasFrozen;this.target=null;this.route=null;this.pulse=0;this.phase='disposed';}
}
const api={AutoPlayer};if(typeof module!=='undefined')module.exports=api;else root.TetrisAutoplay=api;
})(globalThis);
