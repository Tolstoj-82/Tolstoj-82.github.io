const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
for(const side of ['left','right']){
 const left=side==='left',x=left?3:0,y=15,rotation=left?3:1,after=left?2:0;
 const s=structuredClone(require(path.join(root,'situations/l-spin-optimal-'+side+'.js')));s.title='L-Spin (suboptimal, '+side+')';
 const rows=left?['SSSS..SSSS','SSSS..SSSS','SSs$..SSSS','SS$...SSSS','SSs$..SSSS']:['..SSSSSSSS','..SSSSSSSS','..$sSSSSSS','...$SSSSSS','..$sSSSSSS'];
 const board=Array.from({length:18},()=>Array(10).fill('.'));rows.forEach((r,i)=>board[i+13]=[...r]);
 for(const r of [rotation,after])for(const[dx,dy]of C.cells('L',r)){if(board[y+dy][x+dx]!=='.'&&board[y+dy][x+dx]!==',')throw Error('overlap');board[y+dy][x+dx]=',';}
 s.stack=board.slice(13).map(r=>r.join(''));
 for(const f of s.frames.slice(3,7))f.active={x,y,rotation};
 s.frames[4].trigger={hole:[left?3:2,16],button:'A'};
 s.frames[5].buttons=['A'];s.frames[5].caption='4 · Press A to rotate the L counterclockwise into the shorter pocket.';
 s.frames[6].active.rotation=after;s.frames[6].caption='5 · The L fits into the shorter pocket and completes the row.';
 const key='l-spin-suboptimal-'+side;fs.writeFileSync(path.join(root,'situations',key+'.js'),'// Suboptimal L-spin reconstructed from the supplied reference.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
}
edit('situations.js',s=>s.replace('"l-spin-optimal-right"\n','"l-spin-optimal-right",\n  "l-spin-suboptimal-left",\n  "l-spin-suboptimal-right"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/l-spin-suboptimal-left.js"></script><script src="situations/l-spin-suboptimal-right.js"></script><script src="situations.js">').replace('id="libraryCount" class="count"','id="libraryCount" class="count" hidden'));
edit('studio.css',s=>s+'\n.library { border: 1px solid #cbd5e1; border-radius: 6px; padding: 12px; }\n');
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'18'","libraryCount.textContent,'20'").replace('h.cards().length,17','h.cards().length,19').replace('[2,1,2,2,5,4,2]','[2,1,2,2,5,4,4]'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,18','C.parseCollection(demo).length,20').replace("s.title.startsWith('L-Spin'));assert.equal(variants.length,2)","s.title.startsWith('L-Spin (optimal'));assert.equal(variants.length,2)")+`
test('suboptimal L-spins use A for the pictured counterclockwise turn with safe paths',()=>{
 const variants=C.demos().filter(s=>s.title.startsWith('L-Spin (suboptimal'));assert.equal(variants.length,2);
 for(const[i,s]of variants.entries()){
  const f=s.frames[3],stack=C.compose({...f,active:undefined},18);
  for(let t=0;t<=f.ticks;t++){const a=C.frameAt(f,t).active;for(const[x,y]of C.cells(a.type,a.rotation))assert.equal(stack[a.y+y][a.x+x],'.');}
  assert.deepEqual(s.frames[5].buttons,['A']);assert.equal(s.frames[6].active.rotation,(f.active.rotation+3)%4);assert.deepEqual(s.frames[7].clearRows,[16]);assert.deepEqual(C.normalize(C.compact(s)),s);
 }
});
`);
