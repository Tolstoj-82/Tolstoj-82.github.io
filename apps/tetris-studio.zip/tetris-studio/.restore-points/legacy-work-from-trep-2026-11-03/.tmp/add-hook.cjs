const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`,C=require(path.join(root,'core.js'));
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
const s=structuredClone(require(path.join(root,'situations/adjustment-sz-koryan.js'))),a={type:'L',x:7,y:15,rotation:1},b={type:'I',x:8,y:14,rotation:1},d={type:'L',x:7,y:15,rotation:3};
s.title='Hook';s.description='Mirrored NES hook adjustment: L first, I next. Leave the right wall clear for I.';s.stack=['.SSSSSSs..','.SSSSSSs..'];s.adjustment={default:d,adjusted:a,next:b};
const base=C.empty(16).concat(s.stack.map(r=>[...r.replaceAll('s','L').replaceAll('S','L')])),locked=C.compose({board:base,active:a},18),both=C.compose({board:locked,active:b},18),diff=(before,after)=>Object.fromEntries(after.map((r,y)=>[y,r.join('')]).filter(([y,r])=>r!==before[y].join('')));
const captions=['The hook motif: the stack edge that L will cap, with space beside the wall for I.','Default: the L foot would normally face the wall. That would block the next I.','Look ahead: I is next. Keep the wall column open for its vertical placement.','Adjusted: turn the L foot inward, capping the stack edge instead of blocking the wall.','Next: the vertical I will fit against the wall beside the adjusted L.','Turn L upright and lower it with the hook pointing inward.','Bring in the next I. The wall column is still open.','Turn I vertical and lower it against the right wall.','The hook and I form a unit, creating a gentler slope on the right.','Notice the motif again: the adjusted hook caps the stack edge and leaves room for I.'];
s.frames.forEach((f,i)=>{f.next='I';f.caption=captions[i];if(f.active)f.active={type:i===6||i===7?'I':'L',x:3,y:0,rotation:0};if(i===5)f.active={...a};if(i===7)f.active={...b};if(f.ghost)f.ghost=i===1||i===2?{...d,label:'Default'}:i===3?{...a,label:'Adjusted'}:{...b,label:'Next'};if(f.referenceGhost)f.referenceGhost={...a,label:'Adjusted'};if(f.rows)f.rows=i===6?diff(base,locked):diff(locked,both);if(f.placementHighlights)f.placementHighlights=[a,b];});
const key='adjustment-hook';fs.writeFileSync(path.join(root,'situations',key+'.js'),'// NES Hook reference mirrored horizontally: Game Boy L then I at the right wall.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(key)+']=situation;\n})(globalThis);\n');
edit('situations.js',s=>s.replace('"adjustment-sz-koryan"\n','"adjustment-sz-koryan",\n  "adjustment-hook"\n'));
edit('index.html',s=>s.replace('<script src="situations.js">','<script src="situations/adjustment-hook.js"></script><script src="situations.js">'));
edit('core.test.cjs',s=>s.replace('C.parseCollection(demo).length,31','C.parseCollection(demo).length,32'));
edit('app.test.cjs',s=>s.replaceAll("libraryCount.textContent,'31'","libraryCount.textContent,'32'").replace('h.cards().length,30','h.cards().length,31'));
fs.appendFileSync(path.join(root,'adjustments.test.cjs'),`
test('Hook mirrors the stack, turns L inward and keeps the wall open for I',()=>{
 const s=C.normalize(require('./situations/adjustment-hook.js')),a=s.adjustment,board=C.compose(s.frames[0],18);
 assert.deepEqual(board.slice(16).map(r=>r.map(c=>c==='.'?'.':'S').join('')),['.SSSSSSS..','.SSSSSSS..']);assert.equal(a.adjusted.type,'L');assert.equal(a.next.type,'I');assert.deepEqual(s.frames[0].motif.cells,[[7,16],[7,17]]);
 assert(fits(board,a.default));assert(!fits(C.compose({board,active:a.default},18),a.next));assert(fits(C.compose({board,active:a.adjusted},18),a.next));
 for(const f of s.frames.filter(f=>f.animate)){const stack=C.compose({...f,active:undefined},18);for(let t=0;t<=f.ticks;t++)assert(fits(stack,C.frameAt(f,t).active));}
 for(const f of global.TetrisCourse.clean(s).frames)if(f.active)assert(fits(C.compose({...f,active:undefined},18),f.active));
 assert.deepEqual(C.normalize(C.compact(s)),s);const attempt=new Attempt(s);attempt.active=C.clone(a.adjusted);attempt.lock();assert(!attempt.done);attempt.advance(2*1000/C.HZ);assert.equal(attempt.active.type,'I');attempt.active=C.clone(a.next);attempt.lock();assert(attempt.done&&attempt.correct);
});
`);
