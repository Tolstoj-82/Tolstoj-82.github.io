const fs=require('fs'),r='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio';
let p=r+'/playable.js',s=fs.readFileSync(p,'utf8');
const classes=`
function boardMask(board){return board.map(row=>Array.from(row,c=>c==='.'?'.':'#').join('')).join('/');}
class OpenerAttempt extends Attempt{
 constructor(s,accepted,gravity){super(s,gravity);this.accepted=accepted;}
 lock(){const intended=this.goal;this.goal=C.clone(this.active);super.lock();this.goal=this.pendingPiece?this.goals[this.pieceIndex]:intended;if(this.done)this.correct=this.accepted.has(boardMask(this.board));}
}
class OpenerPractice{
 constructor(situations,random=Math.random){this.random=random;this.score=0;this.rounds=0;this.previous=-1;const groups=new Map();for(const s of situations){const key=s.adjustment.adjusted.type+s.adjustment.next.type;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(s);}this.groups=[...groups.values()];}
 next(gravity){if(!this.groups.length)throw Error('No openers available.');const count=this.groups.length;let n=Math.floor(this.random()*(count-(this.previous>=0&&count>1?1:0)));if(count>1&&this.previous>=0&&n>=this.previous)n++;this.previous=n;const group=this.groups[n];this.situation=group[0];this.attempt=new OpenerAttempt(this.situation,new Set(group.map(s=>boardMask(C.compose(s.frames.at(-1),s.height)))),gravity);this.recorded=false;return this.attempt;}
 record(){if(!this.attempt?.done||this.recorded)return;this.recorded=true;this.score+=this.attempt.correct?1:-1;this.rounds++;}
}
`;
s=s.replace('function init(bridge){',classes+'\nfunction init(bridge){');
s=s.replace('completedMs=0;','completedMs=0,practice=null;',1);
s=s.replace("const level=Number($('playGravity').value)||0,next=nextDistinctLevel(level);", "if(practice){const pair=practice.situation.adjustment;$('playAttemptStatus').textContent='Score: '+practice.score+' · '+practice.rounds+' completed · '+pair.adjusted.type+' → '+pair.next.type+' · '+(paused?'Paused':attempt.done?(attempt.correct?'+1 · Correct!':'−1 · Try the next one.'):'Place both pieces.');return;}const level=Number($('playGravity').value)||0,next=nextDistinctLevel(level);");
s=s.replace("document.body.classList.remove('live-play-mode');", "practice=null;document.body.classList.remove('live-play-mode','opener-practice-mode');bridge.practiceUrl?.(false);");
s=s.replace('attempt=new Attempt(bridge.situation(),gravityForLevel', 'attempt=practice?practice.next(gravityForLevel($(\'playGravity\').value)):new Attempt(bridge.situation(),gravityForLevel');
s=s.replace("function start(){if", "function start(){practice=null;document.body.classList.remove('opener-practice-mode');if");
s=s.replace("const wait=attempt.frame?.clear?", "practice?.record();const wait=practice?1200:attempt.frame?.clear?");
s=s.replace("if(attempt.correct)$('playGravity')", "if(!practice&&attempt.correct)$('playGravity')");
s=s.replace("$('restartAttempt').onclick=restart;", "$('restartAttempt').onclick=()=>{if(practice&&attempt&&!attempt.done){release();attempt=new OpenerAttempt(practice.situation,attempt.accepted,gravityForLevel($('playGravity').value));practice.attempt=attempt;clock=new InputClock(attempt,held);last=0;completedMs=0;paused=false;draw();}else restart();};");
s=s.replace('return {leave,isRunning:()=>running};', `function startOpeners(){practice=new OpenerPractice(bridge.openers());document.body.classList.add('live-play-mode','opener-practice-mode');$('playAttemptPanel').hidden=false;bridge.practiceUrl?.(true);restart();if(!running){running=true;const id=++generation;requestAnimationFrame(time=>tick(time,id));}$('board').focus?.();}return {leave,startOpeners,isRunning:()=>running};`);
s=s.replace('const api={Attempt,','const api={OpenerPractice,OpenerAttempt,Attempt,');fs.writeFileSync(p,s);
p=r+'/course.js';s=fs.readFileSync(p,'utf8').replace("const suggest=finished&&b.dataset.nextType!==s.adjustment?.next.type;", "const choices=Array.from($('adjustmentOptions').children),currentIndex=choices.findIndex(el=>el.dataset.nextType===s.adjustment?.next.type);const suggest=finished&&choices.indexOf(b)===currentIndex+1;");
s=s.replace("parent.append(section);}","if(chapter==='Openers'){const practice=document.createElement('button');practice.textContent='Practice openers';practice.className='course-lesson-link';practice.onclick=()=>{leaveIntro();bridge?.closeMenu();root.liveAttempt.startOpeners();};section.append(practice);}parent.append(section);}");fs.writeFileSync(p,s);
p=r+'/app.js';s=fs.readFileSync(p,'utf8');
s=s.replace("url.searchParams.delete('lesson');url.searchParams.set('situation'", "url.searchParams.delete('lesson');url.searchParams.delete('practice');url.searchParams.delete('next');url.searchParams.set('situation'");
s=s.replace('let lessonVariant=null;',`let lessonVariant=null;try{const next=new URL(location.href).searchParams.get('next');if(studies[selected].adjustment?.alternatives?.some(a=>a.type===next)){lessonVariant=readOnly(C.normalize(TetrisCourse.variant(studies[selected],next)));situationKeys.set(lessonVariant,situationKey(studies[selected]));}}catch{}`);
s=s.replace('TetrisPlayable.init({situation:',`TetrisPlayable.init({openers:()=>studies.filter(s=>s.chapter==='Openers'),practiceUrl:on=>{try{const u=new URL(location.href);if(on){u.searchParams.delete('lesson');u.searchParams.delete('next');u.searchParams.set('practice','openers');}else u.searchParams.delete('practice');history.replaceState(history.state,'',u.href);}catch{}},situation:`);
s=s.replace('index=0;elapsed=0;render(true);}});',`index=0;elapsed=0;try{const u=new URL(location.href);u.searchParams.set('next',type);history.replaceState(history.state,'',u.href);}catch{}render(true);}});`);
s+=`\ntry{if(new URL(location.href).searchParams.get('practice')==='openers'){TetrisCourse.leaveIntro();globalThis.liveAttempt.startOpeners();}}catch{}\n`;fs.writeFileSync(p,s);
fs.appendFileSync(r+'/studio.css', '\n.opener-practice-mode .spin-summary{visibility:hidden}\n');
