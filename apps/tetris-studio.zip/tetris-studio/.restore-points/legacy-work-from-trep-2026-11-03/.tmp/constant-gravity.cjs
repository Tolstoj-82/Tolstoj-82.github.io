const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
edit('app.js',s=>{const start=s.indexOf(' const initial=s.frames.find',s.indexOf('function cleanStudy')),end=s.indexOf('\n const result=',start);return s.slice(0,start)+`
 const initial=s.frames.find(f=>f.active),approach=s.frames.find(f=>f.animate),spin=s.frames.find(f=>f.reveal==='spin'),input=s.frames.find(f=>f.reveal==='input'),tuck=s.frames.find(f=>f.animate&&f!==approach),clear=s.frames.find(f=>f.clear);
 const frames=[];
 if(initial&&approach&&spin){
  let a=C.clone(initial.active),stage='approach',finished=false;
  const target=approach.active,turnAt=24,gravity=6;
  for(let t=0;t<600&&!finished;t++){
   let buttons=[];
   if(stage==='approach'){
    if(t===turnAt){a.rotation=target.rotation;buttons=approach.buttons;}
    if(t>turnAt&&a.x!==target.x){const dx=Math.sign(target.x-a.x);a.x+=dx;buttons=[dx>0?'Right':'Left'];}
    if(t>0&&t%gravity===0&&a.y<target.y)a.y++;
    if(a.y===target.y&&a.x===target.x&&a.rotation===target.rotation)stage='rotate';
   }else if(stage==='rotate'){
    a=C.clone(spin.active);buttons=input?.buttons||[];stage=tuck?'fall':'done';
   }else if(stage==='fall'){
    if(t%gravity===0){a.y++;if(a.y>=tuck.active.y)stage='tuck';}
   }else if(stage==='tuck'){
    const dx=Math.sign(tuck.active.x-a.x);a.x+=dx;buttons=[dx>0?'Right':'Left'];if(a.x===tuck.active.x)stage='done';
   }else finished=true;
   frames.push({...C.clone(initial),active:C.clone(a),ticks:1,buttons,highlight:false,blink:false,caption:'',reveal:undefined});
  }
  if(clear)frames.push({...C.clone(clear),highlight:false,caption:''});
 }else frames.push({...C.clone(s.frames[0]),ticks:24,highlight:false});
`+s.slice(end);});
for(const side of ['right','left']){
 const p=path.join(root,'situations/t-spuck-'+side+'.js'),s=structuredClone(require(p));s.frames[7].buttons=[];
 fs.writeFileSync(p,'(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})["t-spuck-'+side+'"]=situation;\n})(globalThis);\n');
}
edit('core.test.cjs',s=>s.replace("s.frames[7].buttons,[i===0?'Right':'Left']","s.frames[8].buttons,[i===0?'Right':'Left']"));
edit('app.test.cjs',s=>s.replace('assert.equal(s.frames.length,4);assert.equal(s.frames[0].ticks,24);assert(s.frames[1].animate);assert.equal(s.frames[2].ticks,8);assert(s.frames[3].clear);',"assert(s.frames.length>20);assert(s.frames.at(-1).clear);assert(s.frames.slice(0,-1).every(f=>f.ticks===1));" ).replace(" await test('Spins and Spucks",` await test('clean T-Spuck gravity stays constant and the tuck has one directional press',()=>{
  for(const side of ['right','left']){const h=boot(undefined,'file:///C:/tetris/index.html?situation=t-spuck-'+side);h.elements.cleanPlayback.checked=true;h.change('cleanPlayback',true);const s=h.exported(),key=side==='right'?'Right':'Left';
   assert.equal(s.frames.filter(f=>f.buttons.includes(key)).length,1);
   const falls=[];for(let i=1;i<s.frames.length;i++)if(s.frames[i].active.y>s.frames[i-1].active.y)falls.push(i);assert(falls.length>10);for(let i=1;i<falls.length;i++)assert.equal(falls[i]-falls[i-1],6);
   for(const f of s.frames){const stack=h.context.TetrisCore.compose({...f,active:undefined},18);for(const[x,y]of h.context.TetrisCore.cells('T',f.active.rotation))assert.equal(stack[f.active.y+y][f.active.x+x],'.');}
  }
 });
 await test('Spins and Spucks`));
