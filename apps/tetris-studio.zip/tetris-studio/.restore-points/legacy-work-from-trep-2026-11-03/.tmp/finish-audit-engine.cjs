const fs=require('fs'),r='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio';let p=r+'/core.js',s=fs.readFileSync(p,'utf8');
s=s.replace('if(raw.chapter!==undefined)',"if(raw.motionVerified===true)result.motionVerified=true;\n if(raw.chapter!==undefined)");
s=s.replace('const out={title:s.title};','const out={title:s.title};if(s.motionVerified)out.motionVerified=true;');fs.writeFileSync(p,s);
p=r+'/playable.js';s=fs.readFileSync(p,'utf8').replace('const f={board:this.board,active:this.active}', 'const f={board:this.board,active:this.active,tileOverrides:this.tileOverrides}');s=s.replace('this.frame={board:this.board,buttons:', 'this.tileOverrides=overrides;this.frame={board:this.board,buttons:');s=s.replace('if(this.pendingRows?.length)this.board=C.collapseRows(this.board,this.pendingRows);',"if(this.pendingRows?.length){this.tileOverrides=(this.tileOverrides||[]).filter(o=>!this.pendingRows.includes(o.y)).map(o=>({...o,y:o.y+this.pendingRows.filter(y=>y>o.y).length}));this.board=C.collapseRows(this.board,this.pendingRows);}");s=s.replace('return this.frame||{board:this.board,active:this.active,','return this.frame||{board:this.board,tileOverrides:this.tileOverrides,active:this.active,');fs.writeFileSync(p,s);
p=r+'/course.js';s=fs.readFileSync(p,'utf8');
const route=`
function legalPath(board,target,start={type:target.type,x:3,y:0,rotation:0}){
 const fits=a=>C.cells(a.type,a.rotation).every(([x,y])=>a.x+x>=0&&a.x+x<10&&a.y+y>=0&&a.y+y<board.length&&board[a.y+y][a.x+x]==='.'),key=a=>[a.x,a.y,a.rotation%(['I','S','Z'].includes(a.type)?2:a.type==='O'?1:4)].join(','),queue=[[start,[]]],seen=new Set();
 for(let i=0;i<queue.length;i++){const[a,path]=queue[i],k=key(a);if(seen.has(k))continue;seen.add(k);if(k===key(target))return path;for(const[action,dx,dy,dr]of [['left',-1,0,0],['right',1,0,0],['a',0,0,3],['b',0,0,1],['down',0,1,0]]){const next={...a,x:a.x+dx,y:a.y+dy,rotation:(a.rotation+dr)%4};if(fits(next))queue.push([next,[...path,action]]);}}throw Error('No legal route to '+JSON.stringify(target));
}
function cleanVerified(s){
 const P=root.TetrisPlayable||(typeof module!=='undefined'?require('./playable.js'):null),attempt=new P.Attempt(s,6*1000/C.HZ),frames=[],stages=[5,6];let stageIndex=-1,waypoints=[],route=[],expected=null,gap=false;
 for(let tick=0;tick<4000;tick++){
  let buttons=[];if(attempt.active&&!attempt.done){if(attempt.pieceIndex!==stageIndex){stageIndex=attempt.pieceIndex;waypoints=s.frames.filter(f=>f.lessonStage===stages[stageIndex]&&f.animate&&f.active).map(f=>f.active);route=[];expected=null;}
   const key=a=>a&&[a.x,a.y,a.rotation%(['I','S','Z'].includes(a.type)?2:a.type==='O'?1:4)].join(',');
   while(waypoints.length&&key(attempt.active)===key(waypoints[0])){waypoints.shift();route=[];expected=null;}
   if(waypoints.length){if(!route.length||expected&&key(expected)!==key(attempt.active))route=legalPath(attempt.board,waypoints[0],attempt.active);const action=route[0];if(action==='down'){expected={...attempt.active,y:attempt.active.y+1};}else if(!gap){if(attempt.input(action)){buttons=[{left:'Left',right:'Right',a:'A',b:'B'}[action]];route.shift();}gap=true;expected={...attempt.active};}else{gap=false;expected={...attempt.active};}}
  }
  const f=attempt.view();frames.push({...C.clone(f),board:attempt.board.map(row=>row.join('')),ticks:1,caption:'',highlight:false,buttons,next:s.adjustment.next.type,showNext:attempt.pieceIndex===0});
  const previous=attempt.active&&{...attempt.active};attempt.advance(1000/C.HZ);if(previous&&attempt.active&&attempt.active.y!==previous.y){if(route[0]==='down')route.shift();expected={...attempt.active};}
  if(attempt.done){if(!attempt.correct)throw Error(s.title+' clean playback missed the target');if(attempt.frame?.clear)frames.push({...C.clone(attempt.frame),ticks:C.LINE_CLEAR.ticks,caption:'',highlight:false});frames.push({board:(attempt.frame?.clear?C.clearAfterBoard(attempt.frame,s.height):attempt.board).map(row=>row.join('')),buttons:[],ticks:C.ENTRY_DELAY,caption:'',highlight:false});return {...s,frames};}
 }throw Error(s.title+' playback exceeded its duration');
}
`;
s=s.replace('function clean(s){',route+'\nfunction clean(s){\n if(s.motionVerified)return cleanVerified(s);');
s=s.replace('root.TetrisCourse={resources,','root.TetrisCourse={legalPath,resources,');fs.writeFileSync(p,s);
