const fs=require('fs');
const path=require('path');
const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
for(const variant of ['well','center']){
 const s=structuredClone(require(path.join(root,'situations',`z-spin-${variant}.js`)));
 s.title=`S-Spin (${variant})`;s.piece='S';
 s.stack=variant==='well'?['..SSSSSSSS','..SSSSSSSS',',,$sSSSSSS',',,,$SSSSSS',',,$sSSSSSS']:['SSS..SSSSS','SSS..SSSSS','SSS,,$sSSS','SSS,,,$SSS','SSS,,$sSSS'];
 for(const f of s.frames)if(f.caption)f.caption=f.caption.replaceAll('Z','S');
 s.frames[4].trigger.hole=[variant==='well'?3:6,16];
 s.frames[4].caption='3 · Align the pivot with the middle of the C-shaped motif, across the gap on its right.';
 s.frames[7].caption='6 · The completed bottom row clears.';
 const name=`s-spin-${variant}`;
 fs.writeFileSync(path.join(root,'situations',name+'.js'),'// S has two visual orientation states; either A or B toggles them.\n(function(root){\nconst situation = '+JSON.stringify(s,null,2)+';\nif(typeof module!=="undefined")module.exports=situation;\nelse (root.TetrisSituationFiles??={})['+JSON.stringify(name)+']=situation;\n})(globalThis);\n');
}
const manifest=path.join(root,'situations.js');fs.writeFileSync(manifest,fs.readFileSync(manifest,'utf8').replace('"z-spin-center"\n','"z-spin-center",\n  "s-spin-well",\n  "s-spin-center"\n'));
const html=path.join(root,'index.html');fs.writeFileSync(html,fs.readFileSync(html,'utf8').replace('<script src="situations.js">','<script src="situations/s-spin-well.js"></script><script src="situations/s-spin-center.js"></script><script src="situations.js">'));
const tests=path.join(root,'app.test.cjs');fs.writeFileSync(tests,fs.readFileSync(tests,'utf8').replaceAll("libraryCount.textContent,'05'","libraryCount.textContent,'07'").replace('situationList.children.length,4','situationList.children.length,6'));
