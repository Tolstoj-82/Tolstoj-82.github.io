from pathlib import Path
import hashlib
old=Path('C:/Users/marti/Desktop/Tetris (JUE) (V1.1) [!].gb').read_bytes();new=Path('C:/Users/marti/Desktop/Tetris_lfsr.gb').read_bytes()
print('SHA256',hashlib.sha256(new).hexdigest())
ranges=[]
for i,(a,b) in enumerate(zip(old,new)):
 if a!=b:
  if ranges and i<=ranges[-1][1]+5:ranges[-1][1]=i
  else:ranges.append([i,i])
print('ranges',[(hex(a),hex(b)) for a,b in ranges]);
for a,b in ranges:
 if a<0x4000: print(hex(a),new[max(0,a-5):b+6].hex())
