const fs=require('fs'),root='../tetris-studio',p=root+'/assets/css/studio.css';let css=fs.readFileSync(p,'utf8');const old='--desktop-board-width:clamp(144px,calc((100dvh - 300px)/2.03),288px)';if(!css.includes(old))throw Error('Desktop size rule missing');css=css.replace(old,'--desktop-board-width:clamp(144px,calc((100dvh - 300px)/2.03),432px)');css+=`\n/* Use the desktop height for the board; the sidebar must not impose the old 900px content cap. */
@media(min-width:1000px){
 .workspace,.page-heading{max-width:none}
}
/* On narrower desktops, stack the diagnostics instead of squeezing the playfield. */
@media(min-width:1000px) and (max-width:1399px){
 .free-play-mode{--free-score-width:96px;--free-quality-width:184px;--free-pieces-width:184px;--free-board-width:min(var(--desktop-board-width),calc(100vw - 680px))}
 .free-play-mode .board-player{grid-template-columns:var(--free-board-width) var(--free-score-width) var(--free-quality-width);grid-template-rows:auto auto;gap:12px;justify-content:center}
 .free-play-mode .player-column{grid-column:1;grid-row:1 / 3}
 .free-play-mode .free-play-info{grid-column:2;grid-row:1 / 3}
 .free-play-mode .free-metric-panel{grid-column:3;grid-row:1}
 .free-play-mode .free-piece-panel{grid-column:3;grid-row:2;margin-top:0}
}
`;fs.writeFileSync(p,css);const h=root+'/index.html';fs.writeFileSync(h,fs.readFileSync(h,'utf8').replace('studio.css?v=local-fonts-1','studio.css?v=desktop-board-size-2'));
