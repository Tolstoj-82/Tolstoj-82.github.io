const fs=require('fs'),path=require('path'),base=path.resolve('../tetris-studio');
const p=path.join(base,'tests/mistake-journal.test.cjs');let s=fs.readFileSync(p,'utf8').replace("'<use href=\"#mino'","'href=\"#mino'").replace('/<use href="([^"]+)"/g','/<use[^>]*href="([^"]+)"/g').replace("/<use href=\"#([^\"]+)\"/g","/<use[^>]*href=\"#([^\"]+)\"/g");fs.writeFileSync(p,s);
