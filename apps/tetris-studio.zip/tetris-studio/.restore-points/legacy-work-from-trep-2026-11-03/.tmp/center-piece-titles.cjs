const fs=require('fs'),root='C:/Users/marti/Documents/00_Programming_Stuff/02-Tolstoj_Website/apps/tetris-studio';
let html=fs.readFileSync(root+'/index.html','utf8');
const heading=html.match(/<div class="study-heading">[\s\S]*?<span id="heightBadge" hidden>18<\/span><\/div>/)?.[0];
if(!heading)throw Error('Heading missing');
html=html.replace(heading,'').replace('<div class="player-column"><div class="board-hardware">','<div class="player-column">'+heading+'<div class="board-hardware">');fs.writeFileSync(root+'/index.html',html);
let app=fs.readFileSync(root+'/app.js','utf8');
app=app.replace("$('studyTitle').textContent=s.title;",`$('studyTitle').textContent=s.title;if(s.chapter==='Openers'){const pair=s.title.match(/^([LJIOZST])( → )([LJIOZST])(.*)$/);if(pair){const colors=s.frames[0].placementColors||['#e04444','#35a35c'];const parts=[pair[1],pair[2],pair[3],pair[4]].map((value,n)=>{const span=document.createElement('span');span.textContent=value;if(n===0||n===2){span.className=n===0?'opener-first-piece':'opener-second-piece';span.style.color=colors[n===0?0:1];}return span;});$('studyTitle').replaceChildren(...parts);}}`);
fs.writeFileSync(root+'/app.js',app);
fs.appendFileSync(root+'/studio.css',`\n/* The lesson title belongs to the board column, so its center always matches. */
.player-column>.study-heading{display:block;width:100%;min-width:0;min-height:0;text-align:center;margin:0 0 4px;flex:0 0 auto}
.player-column>.study-heading h2{margin:0;font-size:18px;line-height:1.3;overflow-wrap:anywhere}
.player-column>.study-heading .opener-first-piece,.player-column>.study-heading .opener-second-piece{font-weight:750}
`);
console.log('Centered titles in board column; opener letters use the board placement colors.');
