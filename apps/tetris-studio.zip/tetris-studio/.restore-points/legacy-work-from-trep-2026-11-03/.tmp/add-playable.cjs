const fs=require('fs'),path=require('path');const root=String.raw`C:\Users\marti\Documents\00_Programming_Stuff\02-Tolstoj_Website\apps\tetris-studio`;
const edit=(name,fn)=>{const p=path.join(root,name);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
fs.copyFileSync(path.join(__dirname,'playable.js'),path.join(root,'playable.js'));
edit('index.html',s=>s.replace('<button id="openStackEditor"','<button id="startAttempt" class="try-situation">Play situation</button><button id="openStackEditor"').replace('<div class="transport">',`<section id="playAttemptPanel" class="play-attempt-panel" hidden aria-label="Play situation">
<div class="attempt-actions"><button id="restartAttempt">Restart</button><button id="pauseAttempt">Pause / resume</button><button id="leaveAttempt">Back to steps</button></div>
<p id="playAttemptStatus" role="status"></p><label>Gravity <select id="playGravity"><option value="800" selected>0.8 s / row</option><option value="400">0.4 s / row</option><option value="200">0.2 s / row</option><option value="100">0.1 s / row</option></select></label>
<details><summary>Keyboard controls</summary><p>Click a key, then press its replacement. Escape cancels. Changes last until reload.</p><div id="keyBindings"></div><p id="bindingStatus" role="status"></p><button id="resetBindings">Reset keys</button></details></section><div class="transport">`).replace('<script src="app.js">','<script src="playable.js"></script><script src="app.js">'));
edit('app.js',s=>s.replace("card.onclick=()=>{$('stackEditor')", "card.onclick=()=>{globalThis.liveAttempt?.leave();$('stackEditor')").replace("document.addEventListener('keydown',e=>{if(!$('stackEditor').hidden)","document.addEventListener('keydown',e=>{if(globalThis.liveAttempt?.isRunning())return;if(!$('stackEditor').hidden)").replace("function openStackEditor(){\n stop();","function openStackEditor(){\n globalThis.liveAttempt?.leave();stop();")+`\nglobalThis.liveAttempt=TetrisPlayable.init({situation:()=>studies[selected],stop,render:()=>render(),draw:drawGrid,inputs:showInputs,notice});\n`);
edit('studio.css',s=>s+`
.try-situation { float: right; margin: 0 0 8px 8px; border-color: #64748b; background: #e2e8f0; }
.play-attempt-panel { width: 100%; padding-top: 10px; font-size: 12px; }
.attempt-actions { display: flex; flex-wrap: wrap; gap: 5px; }
.attempt-actions button { min-height: 30px; padding: 5px 7px; font-size: 11px; }
.play-attempt-panel details { margin-top: 12px; }
#keyBindings { display: grid; gap: 6px; margin: 8px 0; }
#keyBindings label { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
#keyBindings button { min-width: 65px; padding: 5px 8px; min-height: 30px; }
#bindingStatus { color: #9b243a; }
.live-play-mode .player-column > .transport { display: none; }
.live-play-mode .spin-summary { opacity: .4; pointer-events: none; }
.live-play-mode #board { outline: 2px solid #8a4662; outline-offset: 2px; }
`);
