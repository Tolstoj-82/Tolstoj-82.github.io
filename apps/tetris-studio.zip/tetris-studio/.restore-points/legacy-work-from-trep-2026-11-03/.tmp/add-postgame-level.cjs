const fs=require('node:fs'),path=require('node:path'),base=path.resolve('../tetris-studio');const changes=[];
function edit(file,fn){const p=path.join(base,file);changes.push([p,fn(fs.readFileSync(p,'utf8'))]);}function swap(s,a,b){if(!s.includes(a))throw Error('Missing '+a.slice(0,80));return s.replace(a,b);}
edit('index.html',s=>swap(s,'<button id="resultRetry">Try again</button>','<button id="resultRetry">Try again</button><button id="resultChangeLevel" hidden>Change level</button>').replace('js/playable.js?v=autoplay-1','js/playable.js?v=postgame-level-1'));
edit('js/playable.js',s=>{
 s=swap(s,"$('resultSeeAgain').hidden=free;","$('resultSeeAgain').hidden=free;$('resultChangeLevel').hidden=!free||!!attempt.observed;");
 s=swap(s,'el.hidden=resultDismissed||!ready;','el.hidden=resultDismissed||!ready||!$(\'freeStartPicker\').hidden;');
 s=swap(s,"$('resultRetry').onclick=()=>{if(attempt?.done)restart(true);};","$('resultRetry').onclick=()=>{if(attempt?.done)restart(true);};\n $('resultChangeLevel').onclick=()=>{if(!attempt?.freePlay||attempt.observed||!attempt.done)return;startFree();result();$('freeStartLevels').querySelector?.('[aria-pressed=\"true\"]')?.focus?.();};");
 s=swap(s,"$('freeStartPicker').hidden=true;paused=freeWasPaused;};","$('freeStartPicker').hidden=true;paused=freeWasPaused;result();};");
 s=swap(s,'freeStartLevel=attempt?.freePlay?attempt.level:Number($(\'playGravity\').value)||0;','freeStartLevel=attempt?.freePlay?(attempt.done?attempt.startLevel:attempt.level):Number($(\'playGravity\').value)||0;');return s;
});
edit('tests/app.test.cjs',s=>s+`
test('Free play game over offers a level change before the next game, with cancel and immediate replay',()=>{
 const h=boot(undefined,'file:///C:/tetris/index.html?play=free',{deferFreeStart:true}),pad=h.elements.freeStartLevels;
 for(let n=0;n<13;n++)pad.children[9].children[1].children[1].onclick();
 h.click('beginFreePlay');let time=100;for(let n=0;n<800&&h.elements.attemptResultText.textContent!=='Game over';n++){h.animate(time);time+=100;}
 assert.equal(h.elements.attemptResultText.textContent,'Game over');assert.equal(h.elements.attemptResult.hidden,false);assert.equal(h.elements.resultChangeLevel.hidden,false);
 h.click('resultChangeLevel');assert.equal(h.elements.freeStartPicker.hidden,false);assert.equal(h.elements.attemptResult.hidden,true);assert.equal(pad.children[9].children[0].textContent,'M');
 h.animate(time);time+=100;assert.equal(h.elements.attemptResult.hidden,true,'result must stay behind the level picker');
 h.click('cancelFreeStart');assert.equal(h.elements.freeStartPicker.hidden,true);assert.equal(h.elements.attemptResult.hidden,false);assert.equal(h.elements.attemptResultText.textContent,'Game over');
 h.click('resultChangeLevel');pad.children[3].onclick();assert.equal(pad.children[3].attributes['aria-pressed'],'true');h.click('beginFreePlay');
 assert.equal(h.elements.freeStartPicker.hidden,true);assert.equal(h.elements.attemptResult.hidden,true);assert.equal(h.elements.freeLevel.textContent,'3');assert.equal(h.elements.freeScore.textContent,'0');assert.equal(h.elements.freeLines.textContent,'0');
 h.click('restartAttempt');assert.equal(h.elements.freeStartPicker.hidden,true);assert.equal(h.elements.freeLevel.textContent,'3');assert.equal(h.elements.resultChangeLevel.hidden,false);
 h.click('leaveAttempt');assert.equal(h.elements.resultChangeLevel.hidden,true);
});
`);
for(const [p,s]of changes)fs.writeFileSync(p,s);console.log('Added Change level to the Free play game-over screen.');
